#!/bin/bash
### /OpenNMT/tools/cleanup2.sh USAGE
### fldr='/Engines/Gen/ENFI'
### eid=13
### suffix=_ENFI
### nohup nice bash /OpenNMT/tools/cleanup2.sh "${fldr}" "${eid}" "${suffix}" > "${fldr}/cleanup.rpt" 2>&1 &
### nohup nice bash /OpenNMT/tools/cleanup2.sh "/Engines/Gen/ENDE" "13" "_ENES" > "${fldr}/cleanup.rpt" 2>&1 &

fldr=$1
eid=$2
suffix=$3
for f in "${fldr}/*.log"; do rm $f; done
for f in "${fldr}/*.txt"; do rm $f; done
rm "${fldr}"/*.trainall;rm "${fldr}"/*.trainall.tok
7z a -r "${fldr}/trans${suffix}_$(echo ${fldr:1} | sed -E 's,/,_,g').7z" "${fldr}/trans${suffix}"/*; rm -r "${fldr}/trans${suffix}"
cd ${fldr}/models${suffix}

for f in *.rpt; do cp $f "${fldr}"; done;

for f in *_epoch*_*.t7; do
  if [[ $f != *epoch${eid}_* ]]; then
    echo "Removing ${f}"
    rm ${f}
  fi;
done

7z a -r "${fldr}/models${suffix}_$(echo ${fldr:1} | sed -E 's,/,_,g').7z" "${fldr}/models${suffix}"/*; rm -r "${fldr}/models${suffix}"
7z a -r  "${fldr}/files${suffix}_$(echo ${fldr:1} | sed -E 's,/,_,g').7z" "${fldr}"/*.{bpe,defretok,tok}; 
rm "${fldr}"/*.{bpe,defretok,tok}

#// SPEED, how many trainings
#// Check the limits for BPE/trainings
# mailto Anna about samples to test if DEEN and ENDE AREE FIXED
# TF / FB MT / NEURAL MONKEY
# AUG MEETING - not confirmed
# Freeedays - AUG 6


