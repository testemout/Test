#!/bin/bash

### /OpenNMT/tools/cleanup.sh USAGE
### fldr='/Engines/Gen/ENDE'
### keep_epoch_id=23
### nohup nice bash /OpenNMT/tools/cleanup.sh "${fldr}" "${keep_epoch_id}" > "${fldr}/cleanup.rpt" 2>&1 &

fldr=$1 # fldr="/Engines/Sabre/ENDE"
keep_epoch_id=$2
for f in "${fldr}/*.log"; do rm $f; done
for f in "${fldr}/*.txt"; do rm $f; done
rm "${fldr}"/*.trainall;rm "${fldr}"/*.trainall.tok
7z a -r "${fldr}/trans_$(echo ${fldr:1} | sed -E 's,/,_,g').7z" "${fldr}/trans/*"; rm -r "${fldr}/trans"
cd ${fldr}/models
for f in *_epoch*_*.t7; do
  if [[ $f != *epoch${keep_epoch_id}_* ]]; then
    echo "Removing ${f}"
    rm ${f}
  fi;
done

7z a -r "${fldr}/models_$(echo ${fldr:1} | sed -E 's,/,_,g').7z" "${fldr}/models/*"; rm -r "${fldr}/models"
7z a -r  "${fldr}/files_$(echo ${fldr:1} | sed -E 's,/,_,g').7z" "${fldr}"/*.{bpe,defretok,tok}; 
rm "${fldr}"/*.{bpe,defretok,tok}

#// SPEED, how many trainings
#// Check the limits for BPE/trainings
# mailto Anna about samples to test if DEEN and ENDE AREE FIXED
# TF / FB MT / NEURAL MONKEY
# AUG MEETING - not confirmed
# Freeedays - AUG 6
