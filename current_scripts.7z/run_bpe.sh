#!/bin/bash
# Usage:
# nohup nice bash /OpenNMT/tools/run_bpe.sh sfile tfile fldr prefix > /bpe_log.rpt 2>&1 &
src_train="$1"
tgt_train="$2"
fldr="$3"
prefix="$4"
cd /OpenNMT09/OpenNMT
echo "$(date '+%Y-%m-%d'): Starting to generate BPE model file…";
cat "$fldr"/"${src_train}" "$fldr"/"${tgt_train}" > "${fldr}"/"${prefix}"_trainall;
th ./tools/tokenize.lua -mode aggressive -nparallel 6 < "${fldr}"/"${prefix}"_trainall > "${fldr}"/"${prefix}"_trainall.tok;
th ./tools/learn_bpe.lua -size 48000 -tok_segment_numbers -tok_segment_alphabet_change -tok_segment_alphabet {Han,Thai,Katakana,Hiragana} -tok_joiner_annotate -tok_case_feature -save_bpe "${fldr}"/"${prefix}"_trainall.tok.bpe < ${fldr}/${prefix}_trainall.tok;
echo "$(date '+%Y-%m-%d'): Finished."
