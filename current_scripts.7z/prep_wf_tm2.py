#!/usr/bin/python3

import io, datetime
import os, sys, re

########## HOW TO: #############################################################
# Written by Wiktor Stribizew, Feb 27, 2018
# USAGE:
# python /OpenNMT/tools/prep_wf_tm2.py /path/file.ENZH EN ZH 2 0 10000 "" 1
#
# If no dedping is necessary, set dedupe_modfe to 0:
# python /OpenNMT/tools/prep_wf_tm2.py /path/file.ENZH EN ZH 0 0 10000 "" 1
#
# lc(s), dedupe_mode, no protect tags (0), update after 10K, no pattern, check private
# Add datetime.datetime.strptime(s, '%Y%m%d~%H%M%S')
# Cleanup string test: http://rextester.com/GQA92528
##################################################################################

dc = [('&#x00009;', '&Tab;', '__ent_CHARACTER_TABULATION'),
('&#x0000A;', '&NewLine;', '__ent_LINE_FEED_LF'),
('&#x00021;', '&excl;', '__ent_EXCLAMATION_MARK'),
('&#x00022;', '&quot;', '__ent_QUOTATION_MARK'),
('&#x00023;', '&num;', '__ent_NUMBER_SIGN'),
('&#x00024;', '&dollar;', '__ent_DOLLAR_SIGN'),
('&#x00025;', '&percnt;', '__ent_PERCENT_SIGN'),
('&#x00026;', '&amp;', '__ent_AMPERSAND'),
('&#x00027;', '&apos;', '__ent_APOSTROPHE'),
('&#x00028;', '&lpar;', '__ent_LEFT_PARENTHESIS'),
('&#x00029;', '&rpar;', '__ent_RIGHT_PARENTHESIS'),
('&#x0002A;', '&ast;', '__ent_ASTERISK'),
('&#x0002B;', '&plus;', '__ent_PLUS_SIGN'),
('&#x0002C;', '&comma;', '__ent_COMMA'),
('&#x0002E;', '&period;', '__ent_FULL_STOP'),
('&#x0002F;', '&sol;', '__ent_SOLIDUS'),
('&#x0003A;', '&colon;', '__ent_COLON'),
('&#x0003B;', '&semi;', '__ent_SEMICOLON'),
('&#x0003C;', '&lt;', '__ent_LESS_THAN_SIGN'),
('&#x0003D;', '&equals;', '__ent_EQUALS_SIGN'),
('&#x0003E;', '&gt;', '__ent_GREATER_THAN_SIGN'),
('&#x0003F;', '&quest;', '__ent_QUESTION_MARK'),
('&#x00040;', '&commat;', '__ent_COMMERCIAL_AT'),
('&#x0005B;', '&lsqb;', '__ent_LEFT_SQUARE_BRACKET'),
('&#x0005C;', '&bsol;', '__ent_REVERSE_SOLIDUS'),
('&#x0005D;', '&rsqb;', '__ent_RIGHT_SQUARE_BRACKET'),
('&#x0005E;', '&Hat;', '__ent_CIRCUMFLEX_ACCENT'),
('&#x0005F;', '&lowbar;', '__ent_LOW_LINE'),
('&#x00060;', '&grave;', '__ent_GRAVE_ACCENT'),
('&#x0007B;', '&lcub;', '__ent_LEFT_CURLY_BRACKET'),
('&#x0007C;', '&verbar;', '__ent_VERTICAL_LINE'),
('&#x0007D;', '&rcub;', '__ent_RIGHT_CURLY_BRACKET'),
('&#x000A0;', '&nbsp;', '__ent_NO_BREAK_SPACE'),
('&#x000A1;', '&iexcl;', '__ent_INVERTED_EXCLAMATION_MARK'),
('&#x000A2;', '&cent;', '__ent_CENT_SIGN'),
('&#x000A3;', '&pound;', '__ent_POUND_SIGN'),
('&#x000A4;', '&curren;', '__ent_CURRENCY_SIGN'),
('&#x000A5;', '&yen;', '__ent_YEN_SIGN'),
('&#x000A6;', '&brvbar;', '__ent_BROKEN_BAR'),
('&#x000A7;', '&sect;', '__ent_SECTION_SIGN'),
('&#x000A8;', '&Dot;', '__ent_DIAERESIS'),
('&#x000A9;', '&copy;', '__ent_COPYRIGHT_SIGN'),
('&#x000AA;', '&ordf;', '__ent_FEMININE_ORDINAL_INDICATOR'),
('&#x000AB;', '&laquo;', '__ent_LEFT_POINTING_DOUBLE_ANGLE_QUOTATION_MARK'),
('&#x000AC;', '&not;', '__ent_NOT_SIGN'),
('&#x000AD;', '&shy;', '__ent_SOFT_HYPHEN'),
('&#x000AE;', '&reg;', '__ent_REGISTERED_SIGN'),
('&#x000AF;', '&macr;', '__ent_MACRON'),
('&#x000B0;', '&deg;', '__ent_DEGREE_SIGN'),
('&#x000B1;', '&plusmn;', '__ent_PLUS_MINUS_SIGN'),
('&#x000B2;', '&sup2;', '__ent_SUPERSCRIPT_TWO'),
('&#x000B3;', '&sup3;', '__ent_SUPERSCRIPT_THREE'),
('&#x000B4;', '&acute;', '__ent_ACUTE_ACCENT'),
('&#x000B5;', '&micro;', '__ent_MICRO_SIGN'),
('&#x000B6;', '&para;', '__ent_PILCROW_SIGN'),
('&#x000B7;', '&middot;', '__ent_MIDDLE_DOT'),
('&#x000B8;', '&cedil;', '__ent_CEDILLA'),
('&#x000B9;', '&sup1;', '__ent_SUPERSCRIPT_ONE'),
('&#x000BA;', '&ordm;', '__ent_MASCULINE_ORDINAL_INDICATOR'),
('&#x000BB;', '&raquo;', '__ent_RIGHT_POINTING_DOUBLE_ANGLE_QUOTATION_MARK'),
('&#x000BC;', '&frac14;', '__ent_VULGAR_FRACTION_ONE_QUARTER'),
('&#x000BD;', '&frac12;', '__ent_VULGAR_FRACTION_ONE_HALF'),
('&#x000BE;', '&frac34;', '__ent_VULGAR_FRACTION_THREE_QUARTERS'),
('&#x000BF;', '&iquest;', '__ent_INVERTED_QUESTION_MARK'),
('&#x000C0;', '&Agrave;', '__ent_LATIN_CAPITAL_LETTER_A_WITH_GRAVE'),
('&#x000C1;', '&Aacute;', '__ent_LATIN_CAPITAL_LETTER_A_WITH_ACUTE'),
('&#x000C2;', '&Acirc;', '__ent_LATIN_CAPITAL_LETTER_A_WITH_CIRCUMFLEX'),
('&#x000C3;', '&Atilde;', '__ent_LATIN_CAPITAL_LETTER_A_WITH_TILDE'),
('&#x000C4;', '&Auml;', '__ent_LATIN_CAPITAL_LETTER_A_WITH_DIAERESIS'),
('&#x000C5;', '&Aring;', '__ent_LATIN_CAPITAL_LETTER_A_WITH_RING_ABOVE'),
('&#x000C6;', '&AElig;', '__ent_LATIN_CAPITAL_LETTER_AE'),
('&#x000C7;', '&Ccedil;', '__ent_LATIN_CAPITAL_LETTER_C_WITH_CEDILLA'),
('&#x000C8;', '&Egrave;', '__ent_LATIN_CAPITAL_LETTER_E_WITH_GRAVE'),
('&#x000C9;', '&Eacute;', '__ent_LATIN_CAPITAL_LETTER_E_WITH_ACUTE'),
('&#x000CA;', '&Ecirc;', '__ent_LATIN_CAPITAL_LETTER_E_WITH_CIRCUMFLEX'),
('&#x000CB;', '&Euml;', '__ent_LATIN_CAPITAL_LETTER_E_WITH_DIAERESIS'),
('&#x000CC;', '&Igrave;', '__ent_LATIN_CAPITAL_LETTER_I_WITH_GRAVE'),
('&#x000CD;', '&Iacute;', '__ent_LATIN_CAPITAL_LETTER_I_WITH_ACUTE'),
('&#x000CE;', '&Icirc;', '__ent_LATIN_CAPITAL_LETTER_I_WITH_CIRCUMFLEX'),
('&#x000CF;', '&Iuml;', '__ent_LATIN_CAPITAL_LETTER_I_WITH_DIAERESIS'),
('&#x000D0;', '&ETH;', '__ent_LATIN_CAPITAL_LETTER_ETH'),
('&#x000D1;', '&Ntilde;', '__ent_LATIN_CAPITAL_LETTER_N_WITH_TILDE'),
('&#x000D2;', '&Ograve;', '__ent_LATIN_CAPITAL_LETTER_O_WITH_GRAVE'),
('&#x000D3;', '&Oacute;', '__ent_LATIN_CAPITAL_LETTER_O_WITH_ACUTE'),
('&#x000D4;', '&Ocirc;', '__ent_LATIN_CAPITAL_LETTER_O_WITH_CIRCUMFLEX'),
('&#x000D5;', '&Otilde;', '__ent_LATIN_CAPITAL_LETTER_O_WITH_TILDE'),
('&#x000D6;', '&Ouml;', '__ent_LATIN_CAPITAL_LETTER_O_WITH_DIAERESIS'),
('&#x000D7;', '&times;', '__ent_MULTIPLICATION_SIGN'),
('&#x000D8;', '&Oslash;', '__ent_LATIN_CAPITAL_LETTER_O_WITH_STROKE'),
('&#x000D9;', '&Ugrave;', '__ent_LATIN_CAPITAL_LETTER_U_WITH_GRAVE'),
('&#x000DA;', '&Uacute;', '__ent_LATIN_CAPITAL_LETTER_U_WITH_ACUTE'),
('&#x000DB;', '&Ucirc;', '__ent_LATIN_CAPITAL_LETTER_U_WITH_CIRCUMFLEX'),
('&#x000DC;', '&Uuml;', '__ent_LATIN_CAPITAL_LETTER_U_WITH_DIAERESIS'),
('&#x000DD;', '&Yacute;', '__ent_LATIN_CAPITAL_LETTER_Y_WITH_ACUTE'),
('&#x000DE;', '&THORN;', '__ent_LATIN_CAPITAL_LETTER_THORN'),
('&#x000DF;', '&szlig;', '__ent_LATIN_SMALL_LETTER_SHARP_S'),
('&#x000E0;', '&agrave;', '__ent_LATIN_SMALL_LETTER_A_WITH_GRAVE'),
('&#x000E1;', '&aacute;', '__ent_LATIN_SMALL_LETTER_A_WITH_ACUTE'),
('&#x000E2;', '&acirc;', '__ent_LATIN_SMALL_LETTER_A_WITH_CIRCUMFLEX'),
('&#x000E3;', '&atilde;', '__ent_LATIN_SMALL_LETTER_A_WITH_TILDE'),
('&#x000E4;', '&auml;', '__ent_LATIN_SMALL_LETTER_A_WITH_DIAERESIS'),
('&#x000E5;', '&aring;', '__ent_LATIN_SMALL_LETTER_A_WITH_RING_ABOVE'),
('&#x000E6;', '&aelig;', '__ent_LATIN_SMALL_LETTER_AE'),
('&#x000E7;', '&ccedil;', '__ent_LATIN_SMALL_LETTER_C_WITH_CEDILLA'),
('&#x000E8;', '&egrave;', '__ent_LATIN_SMALL_LETTER_E_WITH_GRAVE'),
('&#x000E9;', '&eacute;', '__ent_LATIN_SMALL_LETTER_E_WITH_ACUTE'),
('&#x000EA;', '&ecirc;', '__ent_LATIN_SMALL_LETTER_E_WITH_CIRCUMFLEX'),
('&#x000EB;', '&euml;', '__ent_LATIN_SMALL_LETTER_E_WITH_DIAERESIS'),
('&#x000EC;', '&igrave;', '__ent_LATIN_SMALL_LETTER_I_WITH_GRAVE'),
('&#x000ED;', '&iacute;', '__ent_LATIN_SMALL_LETTER_I_WITH_ACUTE'),
('&#x000EE;', '&icirc;', '__ent_LATIN_SMALL_LETTER_I_WITH_CIRCUMFLEX'),
('&#x000EF;', '&iuml;', '__ent_LATIN_SMALL_LETTER_I_WITH_DIAERESIS'),
('&#x000F0;', '&eth;', '__ent_LATIN_SMALL_LETTER_ETH'),
('&#x000F1;', '&ntilde;', '__ent_LATIN_SMALL_LETTER_N_WITH_TILDE'),
('&#x000F2;', '&ograve;', '__ent_LATIN_SMALL_LETTER_O_WITH_GRAVE'),
('&#x000F3;', '&oacute;', '__ent_LATIN_SMALL_LETTER_O_WITH_ACUTE'),
('&#x000F4;', '&ocirc;', '__ent_LATIN_SMALL_LETTER_O_WITH_CIRCUMFLEX'),
('&#x000F5;', '&otilde;', '__ent_LATIN_SMALL_LETTER_O_WITH_TILDE'),
('&#x000F6;', '&ouml;', '__ent_LATIN_SMALL_LETTER_O_WITH_DIAERESIS'),
('&#x000F7;', '&divide;', '__ent_DIVISION_SIGN'),
('&#x000F8;', '&oslash;', '__ent_LATIN_SMALL_LETTER_O_WITH_STROKE'),
('&#x000F9;', '&ugrave;', '__ent_LATIN_SMALL_LETTER_U_WITH_GRAVE'),
('&#x000FA;', '&uacute;', '__ent_LATIN_SMALL_LETTER_U_WITH_ACUTE'),
('&#x000FB;', '&ucirc;', '__ent_LATIN_SMALL_LETTER_U_WITH_CIRCUMFLEX'),
('&#x000FC;', '&uuml;', '__ent_LATIN_SMALL_LETTER_U_WITH_DIAERESIS'),
('&#x000FD;', '&yacute;', '__ent_LATIN_SMALL_LETTER_Y_WITH_ACUTE'),
('&#x000FE;', '&thorn;', '__ent_LATIN_SMALL_LETTER_THORN'),
('&#x000FF;', '&yuml;', '__ent_LATIN_SMALL_LETTER_Y_WITH_DIAERESIS'),
('&#x00100;', '&Amacr;', '__ent_LATIN_CAPITAL_LETTER_A_WITH_MACRON'),
('&#x00101;', '&amacr;', '__ent_LATIN_SMALL_LETTER_A_WITH_MACRON'),
('&#x00102;', '&Abreve;', '__ent_LATIN_CAPITAL_LETTER_A_WITH_BREVE'),
('&#x00103;', '&abreve;', '__ent_LATIN_SMALL_LETTER_A_WITH_BREVE'),
('&#x00104;', '&Aogon;', '__ent_LATIN_CAPITAL_LETTER_A_WITH_OGONEK'),
('&#x00105;', '&aogon;', '__ent_LATIN_SMALL_LETTER_A_WITH_OGONEK'),
('&#x00106;', '&Cacute;', '__ent_LATIN_CAPITAL_LETTER_C_WITH_ACUTE'),
('&#x00107;', '&cacute;', '__ent_LATIN_SMALL_LETTER_C_WITH_ACUTE'),
('&#x00108;', '&Ccirc;', '__ent_LATIN_CAPITAL_LETTER_C_WITH_CIRCUMFLEX'),
('&#x00109;', '&ccirc;', '__ent_LATIN_SMALL_LETTER_C_WITH_CIRCUMFLEX'),
('&#x0010A;', '&Cdot;', '__ent_LATIN_CAPITAL_LETTER_C_WITH_DOT_ABOVE'),
('&#x0010B;', '&cdot;', '__ent_LATIN_SMALL_LETTER_C_WITH_DOT_ABOVE'),
('&#x0010C;', '&Ccaron;', '__ent_LATIN_CAPITAL_LETTER_C_WITH_CARON'),
('&#x0010D;', '&ccaron;', '__ent_LATIN_SMALL_LETTER_C_WITH_CARON'),
('&#x0010E;', '&Dcaron;', '__ent_LATIN_CAPITAL_LETTER_D_WITH_CARON'),
('&#x0010F;', '&dcaron;', '__ent_LATIN_SMALL_LETTER_D_WITH_CARON'),
('&#x00110;', '&Dstrok;', '__ent_LATIN_CAPITAL_LETTER_D_WITH_STROKE'),
('&#x00111;', '&dstrok;', '__ent_LATIN_SMALL_LETTER_D_WITH_STROKE'),
('&#x00112;', '&Emacr;', '__ent_LATIN_CAPITAL_LETTER_E_WITH_MACRON'),
('&#x00113;', '&emacr;', '__ent_LATIN_SMALL_LETTER_E_WITH_MACRON'),
('&#x00116;', '&Edot;', '__ent_LATIN_CAPITAL_LETTER_E_WITH_DOT_ABOVE'),
('&#x00117;', '&edot;', '__ent_LATIN_SMALL_LETTER_E_WITH_DOT_ABOVE'),
('&#x00118;', '&Eogon;', '__ent_LATIN_CAPITAL_LETTER_E_WITH_OGONEK'),
('&#x00119;', '&eogon;', '__ent_LATIN_SMALL_LETTER_E_WITH_OGONEK'),
('&#x0011A;', '&Ecaron;', '__ent_LATIN_CAPITAL_LETTER_E_WITH_CARON'),
('&#x0011B;', '&ecaron;', '__ent_LATIN_SMALL_LETTER_E_WITH_CARON'),
('&#x0011C;', '&Gcirc;', '__ent_LATIN_CAPITAL_LETTER_G_WITH_CIRCUMFLEX'),
('&#x0011D;', '&gcirc;', '__ent_LATIN_SMALL_LETTER_G_WITH_CIRCUMFLEX'),
('&#x0011E;', '&Gbreve;', '__ent_LATIN_CAPITAL_LETTER_G_WITH_BREVE'),
('&#x0011F;', '&gbreve;', '__ent_LATIN_SMALL_LETTER_G_WITH_BREVE'),
('&#x00120;', '&Gdot;', '__ent_LATIN_CAPITAL_LETTER_G_WITH_DOT_ABOVE'),
('&#x00121;', '&gdot;', '__ent_LATIN_SMALL_LETTER_G_WITH_DOT_ABOVE'),
('&#x00122;', '&Gcedil;', '__ent_LATIN_CAPITAL_LETTER_G_WITH_CEDILLA'),
('&#x00124;', '&Hcirc;', '__ent_LATIN_CAPITAL_LETTER_H_WITH_CIRCUMFLEX'),
('&#x00125;', '&hcirc;', '__ent_LATIN_SMALL_LETTER_H_WITH_CIRCUMFLEX'),
('&#x00126;', '&Hstrok;', '__ent_LATIN_CAPITAL_LETTER_H_WITH_STROKE'),
('&#x00127;', '&hstrok;', '__ent_LATIN_SMALL_LETTER_H_WITH_STROKE'),
('&#x00128;', '&Itilde;', '__ent_LATIN_CAPITAL_LETTER_I_WITH_TILDE'),
('&#x00129;', '&itilde;', '__ent_LATIN_SMALL_LETTER_I_WITH_TILDE'),
('&#x0012A;', '&Imacr;', '__ent_LATIN_CAPITAL_LETTER_I_WITH_MACRON'),
('&#x0012B;', '&imacr;', '__ent_LATIN_SMALL_LETTER_I_WITH_MACRON'),
('&#x0012E;', '&Iogon;', '__ent_LATIN_CAPITAL_LETTER_I_WITH_OGONEK'),
('&#x0012F;', '&iogon;', '__ent_LATIN_SMALL_LETTER_I_WITH_OGONEK'),
('&#x00130;', '&Idot;', '__ent_LATIN_CAPITAL_LETTER_I_WITH_DOT_ABOVE'),
('&#x00131;', '&imath;', '__ent_LATIN_SMALL_LETTER_DOTLESS_I'),
('&#x00132;', '&IJlig;', '__ent_LATIN_CAPITAL_LIGATURE_IJ'),
('&#x00133;', '&ijlig;', '__ent_LATIN_SMALL_LIGATURE_IJ'),
('&#x00134;', '&Jcirc;', '__ent_LATIN_CAPITAL_LETTER_J_WITH_CIRCUMFLEX'),
('&#x00135;', '&jcirc;', '__ent_LATIN_SMALL_LETTER_J_WITH_CIRCUMFLEX'),
('&#x00136;', '&Kcedil;', '__ent_LATIN_CAPITAL_LETTER_K_WITH_CEDILLA'),
('&#x00137;', '&kcedil;', '__ent_LATIN_SMALL_LETTER_K_WITH_CEDILLA'),
('&#x00138;', '&kgreen;', '__ent_LATIN_SMALL_LETTER_KRA'),
('&#x00139;', '&Lacute;', '__ent_LATIN_CAPITAL_LETTER_L_WITH_ACUTE'),
('&#x0013A;', '&lacute;', '__ent_LATIN_SMALL_LETTER_L_WITH_ACUTE'),
('&#x0013B;', '&Lcedil;', '__ent_LATIN_CAPITAL_LETTER_L_WITH_CEDILLA'),
('&#x0013C;', '&lcedil;', '__ent_LATIN_SMALL_LETTER_L_WITH_CEDILLA'),
('&#x0013D;', '&Lcaron;', '__ent_LATIN_CAPITAL_LETTER_L_WITH_CARON'),
('&#x0013E;', '&lcaron;', '__ent_LATIN_SMALL_LETTER_L_WITH_CARON'),
('&#x0013F;', '&Lmidot;', '__ent_LATIN_CAPITAL_LETTER_L_WITH_MIDDLE_DOT'),
('&#x00140;', '&lmidot;', '__ent_LATIN_SMALL_LETTER_L_WITH_MIDDLE_DOT'),
('&#x00141;', '&Lstrok;', '__ent_LATIN_CAPITAL_LETTER_L_WITH_STROKE'),
('&#x00142;', '&lstrok;', '__ent_LATIN_SMALL_LETTER_L_WITH_STROKE'),
('&#x00143;', '&Nacute;', '__ent_LATIN_CAPITAL_LETTER_N_WITH_ACUTE'),
('&#x00144;', '&nacute;', '__ent_LATIN_SMALL_LETTER_N_WITH_ACUTE'),
('&#x00145;', '&Ncedil;', '__ent_LATIN_CAPITAL_LETTER_N_WITH_CEDILLA'),
('&#x00146;', '&ncedil;', '__ent_LATIN_SMALL_LETTER_N_WITH_CEDILLA'),
('&#x00147;', '&Ncaron;', '__ent_LATIN_CAPITAL_LETTER_N_WITH_CARON'),
('&#x00148;', '&ncaron;', '__ent_LATIN_SMALL_LETTER_N_WITH_CARON'),
('&#x00149;', '&napos;', '__ent_LATIN_SMALL_LETTER_N_PRECEDED_BY_APOSTROPHE'),
('&#x0014A;', '&ENG;', '__ent_LATIN_CAPITAL_LETTER_ENG'),
('&#x0014B;', '&eng;', '__ent_LATIN_SMALL_LETTER_ENG'),
('&#x0014C;', '&Omacr;', '__ent_LATIN_CAPITAL_LETTER_O_WITH_MACRON'),
('&#x0014D;', '&omacr;', '__ent_LATIN_SMALL_LETTER_O_WITH_MACRON'),
('&#x00150;', '&Odblac;', '__ent_LATIN_CAPITAL_LETTER_O_WITH_DOUBLE_ACUTE'),
('&#x00151;', '&odblac;', '__ent_LATIN_SMALL_LETTER_O_WITH_DOUBLE_ACUTE'),
('&#x00152;', '&OElig;', '__ent_LATIN_CAPITAL_LIGATURE_OE'),
('&#x00153;', '&oelig;', '__ent_LATIN_SMALL_LIGATURE_OE'),
('&#x00154;', '&Racute;', '__ent_LATIN_CAPITAL_LETTER_R_WITH_ACUTE'),
('&#x00155;', '&racute;', '__ent_LATIN_SMALL_LETTER_R_WITH_ACUTE'),
('&#x00156;', '&Rcedil;', '__ent_LATIN_CAPITAL_LETTER_R_WITH_CEDILLA'),
('&#x00157;', '&rcedil;', '__ent_LATIN_SMALL_LETTER_R_WITH_CEDILLA'),
('&#x00158;', '&Rcaron;', '__ent_LATIN_CAPITAL_LETTER_R_WITH_CARON'),
('&#x00159;', '&rcaron;', '__ent_LATIN_SMALL_LETTER_R_WITH_CARON'),
('&#x0015A;', '&Sacute;', '__ent_LATIN_CAPITAL_LETTER_S_WITH_ACUTE'),
('&#x0015B;', '&sacute;', '__ent_LATIN_SMALL_LETTER_S_WITH_ACUTE'),
('&#x0015C;', '&Scirc;', '__ent_LATIN_CAPITAL_LETTER_S_WITH_CIRCUMFLEX'),
('&#x0015D;', '&scirc;', '__ent_LATIN_SMALL_LETTER_S_WITH_CIRCUMFLEX'),
('&#x0015E;', '&Scedil;', '__ent_LATIN_CAPITAL_LETTER_S_WITH_CEDILLA'),
('&#x0015F;', '&scedil;', '__ent_LATIN_SMALL_LETTER_S_WITH_CEDILLA'),
('&#x00160;', '&Scaron;', '__ent_LATIN_CAPITAL_LETTER_S_WITH_CARON'),
('&#x00161;', '&scaron;', '__ent_LATIN_SMALL_LETTER_S_WITH_CARON'),
('&#x00162;', '&Tcedil;', '__ent_LATIN_CAPITAL_LETTER_T_WITH_CEDILLA'),
('&#x00163;', '&tcedil;', '__ent_LATIN_SMALL_LETTER_T_WITH_CEDILLA'),
('&#x00164;', '&Tcaron;', '__ent_LATIN_CAPITAL_LETTER_T_WITH_CARON'),
('&#x00165;', '&tcaron;', '__ent_LATIN_SMALL_LETTER_T_WITH_CARON'),
('&#x00166;', '&Tstrok;', '__ent_LATIN_CAPITAL_LETTER_T_WITH_STROKE'),
('&#x00167;', '&tstrok;', '__ent_LATIN_SMALL_LETTER_T_WITH_STROKE'),
('&#x00168;', '&Utilde;', '__ent_LATIN_CAPITAL_LETTER_U_WITH_TILDE'),
('&#x00169;', '&utilde;', '__ent_LATIN_SMALL_LETTER_U_WITH_TILDE'),
('&#x0016A;', '&Umacr;', '__ent_LATIN_CAPITAL_LETTER_U_WITH_MACRON'),
('&#x0016B;', '&umacr;', '__ent_LATIN_SMALL_LETTER_U_WITH_MACRON'),
('&#x0016C;', '&Ubreve;', '__ent_LATIN_CAPITAL_LETTER_U_WITH_BREVE'),
('&#x0016D;', '&ubreve;', '__ent_LATIN_SMALL_LETTER_U_WITH_BREVE'),
('&#x0016E;', '&Uring;', '__ent_LATIN_CAPITAL_LETTER_U_WITH_RING_ABOVE'),
('&#x0016F;', '&uring;', '__ent_LATIN_SMALL_LETTER_U_WITH_RING_ABOVE'),
('&#x00170;', '&Udblac;', '__ent_LATIN_CAPITAL_LETTER_U_WITH_DOUBLE_ACUTE'),
('&#x00171;', '&udblac;', '__ent_LATIN_SMALL_LETTER_U_WITH_DOUBLE_ACUTE'),
('&#x00172;', '&Uogon;', '__ent_LATIN_CAPITAL_LETTER_U_WITH_OGONEK'),
('&#x00173;', '&uogon;', '__ent_LATIN_SMALL_LETTER_U_WITH_OGONEK'),
('&#x00174;', '&Wcirc;', '__ent_LATIN_CAPITAL_LETTER_W_WITH_CIRCUMFLEX'),
('&#x00175;', '&wcirc;', '__ent_LATIN_SMALL_LETTER_W_WITH_CIRCUMFLEX'),
('&#x00176;', '&Ycirc;', '__ent_LATIN_CAPITAL_LETTER_Y_WITH_CIRCUMFLEX'),
('&#x00177;', '&ycirc;', '__ent_LATIN_SMALL_LETTER_Y_WITH_CIRCUMFLEX'),
('&#x00178;', '&Yuml;', '__ent_LATIN_CAPITAL_LETTER_Y_WITH_DIAERESIS'),
('&#x00179;', '&Zacute;', '__ent_LATIN_CAPITAL_LETTER_Z_WITH_ACUTE'),
('&#x0017A;', '&zacute;', '__ent_LATIN_SMALL_LETTER_Z_WITH_ACUTE'),
('&#x0017B;', '&Zdot;', '__ent_LATIN_CAPITAL_LETTER_Z_WITH_DOT_ABOVE'),
('&#x0017C;', '&zdot;', '__ent_LATIN_SMALL_LETTER_Z_WITH_DOT_ABOVE'),
('&#x0017D;', '&Zcaron;', '__ent_LATIN_CAPITAL_LETTER_Z_WITH_CARON'),
('&#x0017E;', '&zcaron;', '__ent_LATIN_SMALL_LETTER_Z_WITH_CARON'),
('&#x00192;', '&fnof;', '__ent_LATIN_SMALL_LETTER_F_WITH_HOOK'),
('&#x001B5;', '&imped;', '__ent_LATIN_CAPITAL_LETTER_Z_WITH_STROKE'),
('&#x001F5;', '&gacute;', '__ent_LATIN_SMALL_LETTER_G_WITH_ACUTE'),
('&#x00237;', '&jmath;', '__ent_LATIN_SMALL_LETTER_DOTLESS_J'),
('&#x002C6;', '&circ;', '__ent_MODIFIER_LETTER_CIRCUMFLEX_ACCENT'),
('&#x002C7;', '&caron;', '__ent_CARON'),
('&#x002D8;', '&breve;', '__ent_BREVE'),
('&#x002D9;', '&dot;', '__ent_DOT_ABOVE'),
('&#x002DA;', '&ring;', '__ent_RING_ABOVE'),
('&#x002DB;', '&ogon;', '__ent_OGONEK'),
('&#x002DC;', '&tilde;', '__ent_SMALL_TILDE'),
('&#x002DD;', '&dblac;', '__ent_DOUBLE_ACUTE_ACCENT'),
('&#x00311;', '&DownBreve;', '__ent_COMBINING_INVERTED_BREVE'),
('&#x00332;', '&UnderBar;', '__ent_COMBINING_LOW_LINE'),
('&#x00391;', '&Alpha;', '__ent_GREEK_CAPITAL_LETTER_ALPHA'),
('&#x00392;', '&Beta;', '__ent_GREEK_CAPITAL_LETTER_BETA'),
('&#x00393;', '&Gamma;', '__ent_GREEK_CAPITAL_LETTER_GAMMA'),
('&#x00394;', '&Delta;', '__ent_GREEK_CAPITAL_LETTER_DELTA'),
('&#x00395;', '&Epsilon;', '__ent_GREEK_CAPITAL_LETTER_EPSILON'),
('&#x00396;', '&Zeta;', '__ent_GREEK_CAPITAL_LETTER_ZETA'),
('&#x00397;', '&Eta;', '__ent_GREEK_CAPITAL_LETTER_ETA'),
('&#x00398;', '&Theta;', '__ent_GREEK_CAPITAL_LETTER_THETA'),
('&#x00399;', '&Iota;', '__ent_GREEK_CAPITAL_LETTER_IOTA'),
('&#x0039A;', '&Kappa;', '__ent_GREEK_CAPITAL_LETTER_KAPPA'),
('&#x0039B;', '&Lambda;', '__ent_GREEK_CAPITAL_LETTER_LAMDA'),
('&#x0039C;', '&Mu;', '__ent_GREEK_CAPITAL_LETTER_MU'),
('&#x0039D;', '&Nu;', '__ent_GREEK_CAPITAL_LETTER_NU'),
('&#x0039E;', '&Xi;', '__ent_GREEK_CAPITAL_LETTER_XI'),
('&#x0039F;', '&Omicron;', '__ent_GREEK_CAPITAL_LETTER_OMICRON'),
('&#x003A0;', '&Pi;', '__ent_GREEK_CAPITAL_LETTER_PI'),
('&#x003A1;', '&Rho;', '__ent_GREEK_CAPITAL_LETTER_RHO'),
('&#x003A3;', '&Sigma;', '__ent_GREEK_CAPITAL_LETTER_SIGMA'),
('&#x003A4;', '&Tau;', '__ent_GREEK_CAPITAL_LETTER_TAU'),
('&#x003A5;', '&Upsilon;', '__ent_GREEK_CAPITAL_LETTER_UPSILON'),
('&#x003A6;', '&Phi;', '__ent_GREEK_CAPITAL_LETTER_PHI'),
('&#x003A7;', '&Chi;', '__ent_GREEK_CAPITAL_LETTER_CHI'),
('&#x003A8;', '&Psi;', '__ent_GREEK_CAPITAL_LETTER_PSI'),
('&#x003A9;', '&Omega;', '__ent_GREEK_CAPITAL_LETTER_OMEGA'),
('&#x003B1;', '&alpha;', '__ent_GREEK_SMALL_LETTER_ALPHA'),
('&#x003B2;', '&beta;', '__ent_GREEK_SMALL_LETTER_BETA'),
('&#x003B3;', '&gamma;', '__ent_GREEK_SMALL_LETTER_GAMMA'),
('&#x003B4;', '&delta;', '__ent_GREEK_SMALL_LETTER_DELTA'),
('&#x003B5;', '&epsiv;', '__ent_GREEK_SMALL_LETTER_EPSILON'),
('&#x003B6;', '&zeta;', '__ent_GREEK_SMALL_LETTER_ZETA'),
('&#x003B7;', '&eta;', '__ent_GREEK_SMALL_LETTER_ETA'),
('&#x003B8;', '&theta;', '__ent_GREEK_SMALL_LETTER_THETA'),
('&#x003B9;', '&iota;', '__ent_GREEK_SMALL_LETTER_IOTA'),
('&#x003BA;', '&kappa;', '__ent_GREEK_SMALL_LETTER_KAPPA'),
('&#x003BB;', '&lambda;', '__ent_GREEK_SMALL_LETTER_LAMDA'),
('&#x003BC;', '&mu;', '__ent_GREEK_SMALL_LETTER_MU'),
('&#x003BD;', '&nu;', '__ent_GREEK_SMALL_LETTER_NU'),
('&#x003BE;', '&xi;', '__ent_GREEK_SMALL_LETTER_XI'),
('&#x003BF;', '&omicron;', '__ent_GREEK_SMALL_LETTER_OMICRON'),
('&#x003C0;', '&pi;', '__ent_GREEK_SMALL_LETTER_PI'),
('&#x003C1;', '&rho;', '__ent_GREEK_SMALL_LETTER_RHO'),
('&#x003C2;', '&sigmav;', '__ent_GREEK_SMALL_LETTER_FINAL_SIGMA'),
('&#x003C3;', '&sigma;', '__ent_GREEK_SMALL_LETTER_SIGMA'),
('&#x003C4;', '&tau;', '__ent_GREEK_SMALL_LETTER_TAU'),
('&#x003C5;', '&upsi;', '__ent_GREEK_SMALL_LETTER_UPSILON'),
('&#x003C6;', '&phi;', '__ent_GREEK_SMALL_LETTER_PHI'),
('&#x003C7;', '&chi;', '__ent_GREEK_SMALL_LETTER_CHI'),
('&#x003C8;', '&psi;', '__ent_GREEK_SMALL_LETTER_PSI'),
('&#x003C9;', '&omega;', '__ent_GREEK_SMALL_LETTER_OMEGA'),
('&#x003D1;', '&thetav;', '__ent_GREEK_THETA_SYMBOL'),
('&#x003D2;', '&Upsi;', '__ent_GREEK_UPSILON_WITH_HOOK_SYMBOL'),
('&#x003D5;', '&straightphi;', '__ent_GREEK_PHI_SYMBOL'),
('&#x003D6;', '&piv;', '__ent_GREEK_PI_SYMBOL'),
('&#x003DC;', '&Gammad;', '__ent_GREEK_LETTER_DIGAMMA'),
('&#x003DD;', '&gammad;', '__ent_GREEK_SMALL_LETTER_DIGAMMA'),
('&#x003F0;', '&kappav;', '__ent_GREEK_KAPPA_SYMBOL'),
('&#x003F1;', '&rhov;', '__ent_GREEK_RHO_SYMBOL'),
('&#x003F5;', '&epsi;', '__ent_GREEK_LUNATE_EPSILON_SYMBOL'),
('&#x003F6;', '&bepsi;', '__ent_GREEK_REVERSED_LUNATE_EPSILON_SYMBOL'),
('&#x00401;', '&IOcy;', '__ent_CYRILLIC_CAPITAL_LETTER_IO'),
('&#x00402;', '&DJcy;', '__ent_CYRILLIC_CAPITAL_LETTER_DJE'),
('&#x00403;', '&GJcy;', '__ent_CYRILLIC_CAPITAL_LETTER_GJE'),
('&#x00404;', '&Jukcy;', '__ent_CYRILLIC_CAPITAL_LETTER_UKRAINIAN_IE'),
('&#x00405;', '&DScy;', '__ent_CYRILLIC_CAPITAL_LETTER_DZE'),
('&#x00406;', '&Iukcy;', '__ent_CYRILLIC_CAPITAL_LETTER_BYELORUSSIAN_UKRAINIAN_I'),
('&#x00407;', '&YIcy;', '__ent_CYRILLIC_CAPITAL_LETTER_YI'),
('&#x00408;', '&Jsercy;', '__ent_CYRILLIC_CAPITAL_LETTER_JE'),
('&#x00409;', '&LJcy;', '__ent_CYRILLIC_CAPITAL_LETTER_LJE'),
('&#x0040A;', '&NJcy;', '__ent_CYRILLIC_CAPITAL_LETTER_NJE'),
('&#x0040B;', '&TSHcy;', '__ent_CYRILLIC_CAPITAL_LETTER_TSHE'),
('&#x0040C;', '&KJcy;', '__ent_CYRILLIC_CAPITAL_LETTER_KJE'),
('&#x0040E;', '&Ubrcy;', '__ent_CYRILLIC_CAPITAL_LETTER_SHORT_U'),
('&#x0040F;', '&DZcy;', '__ent_CYRILLIC_CAPITAL_LETTER_DZHE'),
('&#x00410;', '&Acy;', '__ent_CYRILLIC_CAPITAL_LETTER_A'),
('&#x00411;', '&Bcy;', '__ent_CYRILLIC_CAPITAL_LETTER_BE'),
('&#x00412;', '&Vcy;', '__ent_CYRILLIC_CAPITAL_LETTER_VE'),
('&#x00413;', '&Gcy;', '__ent_CYRILLIC_CAPITAL_LETTER_GHE'),
('&#x00414;', '&Dcy;', '__ent_CYRILLIC_CAPITAL_LETTER_DE'),
('&#x00415;', '&IEcy;', '__ent_CYRILLIC_CAPITAL_LETTER_IE'),
('&#x00416;', '&ZHcy;', '__ent_CYRILLIC_CAPITAL_LETTER_ZHE'),
('&#x00417;', '&Zcy;', '__ent_CYRILLIC_CAPITAL_LETTER_ZE'),
('&#x00418;', '&Icy;', '__ent_CYRILLIC_CAPITAL_LETTER_I'),
('&#x00419;', '&Jcy;', '__ent_CYRILLIC_CAPITAL_LETTER_SHORT_I'),
('&#x0041A;', '&Kcy;', '__ent_CYRILLIC_CAPITAL_LETTER_KA'),
('&#x0041B;', '&Lcy;', '__ent_CYRILLIC_CAPITAL_LETTER_EL'),
('&#x0041C;', '&Mcy;', '__ent_CYRILLIC_CAPITAL_LETTER_EM'),
('&#x0041D;', '&Ncy;', '__ent_CYRILLIC_CAPITAL_LETTER_EN'),
('&#x0041E;', '&Ocy;', '__ent_CYRILLIC_CAPITAL_LETTER_O'),
('&#x0041F;', '&Pcy;', '__ent_CYRILLIC_CAPITAL_LETTER_PE'),
('&#x00420;', '&Rcy;', '__ent_CYRILLIC_CAPITAL_LETTER_ER'),
('&#x00421;', '&Scy;', '__ent_CYRILLIC_CAPITAL_LETTER_ES'),
('&#x00422;', '&Tcy;', '__ent_CYRILLIC_CAPITAL_LETTER_TE'),
('&#x00423;', '&Ucy;', '__ent_CYRILLIC_CAPITAL_LETTER_U'),
('&#x00424;', '&Fcy;', '__ent_CYRILLIC_CAPITAL_LETTER_EF'),
('&#x00425;', '&KHcy;', '__ent_CYRILLIC_CAPITAL_LETTER_HA'),
('&#x00426;', '&TScy;', '__ent_CYRILLIC_CAPITAL_LETTER_TSE'),
('&#x00427;', '&CHcy;', '__ent_CYRILLIC_CAPITAL_LETTER_CHE'),
('&#x00428;', '&SHcy;', '__ent_CYRILLIC_CAPITAL_LETTER_SHA'),
('&#x00429;', '&SHCHcy;', '__ent_CYRILLIC_CAPITAL_LETTER_SHCHA'),
('&#x0042A;', '&HARDcy;', '__ent_CYRILLIC_CAPITAL_LETTER_HARD_SIGN'),
('&#x0042B;', '&Ycy;', '__ent_CYRILLIC_CAPITAL_LETTER_YERU'),
('&#x0042C;', '&SOFTcy;', '__ent_CYRILLIC_CAPITAL_LETTER_SOFT_SIGN'),
('&#x0042D;', '&Ecy;', '__ent_CYRILLIC_CAPITAL_LETTER_E'),
('&#x0042E;', '&YUcy;', '__ent_CYRILLIC_CAPITAL_LETTER_YU'),
('&#x0042F;', '&YAcy;', '__ent_CYRILLIC_CAPITAL_LETTER_YA'),
('&#x00430;', '&acy;', '__ent_CYRILLIC_SMALL_LETTER_A'),
('&#x00431;', '&bcy;', '__ent_CYRILLIC_SMALL_LETTER_BE'),
('&#x00432;', '&vcy;', '__ent_CYRILLIC_SMALL_LETTER_VE'),
('&#x00433;', '&gcy;', '__ent_CYRILLIC_SMALL_LETTER_GHE'),
('&#x00434;', '&dcy;', '__ent_CYRILLIC_SMALL_LETTER_DE'),
('&#x00435;', '&iecy;', '__ent_CYRILLIC_SMALL_LETTER_IE'),
('&#x00436;', '&zhcy;', '__ent_CYRILLIC_SMALL_LETTER_ZHE'),
('&#x00437;', '&zcy;', '__ent_CYRILLIC_SMALL_LETTER_ZE'),
('&#x00438;', '&icy;', '__ent_CYRILLIC_SMALL_LETTER_I'),
('&#x00439;', '&jcy;', '__ent_CYRILLIC_SMALL_LETTER_SHORT_I'),
('&#x0043A;', '&kcy;', '__ent_CYRILLIC_SMALL_LETTER_KA'),
('&#x0043B;', '&lcy;', '__ent_CYRILLIC_SMALL_LETTER_EL'),
('&#x0043C;', '&mcy;', '__ent_CYRILLIC_SMALL_LETTER_EM'),
('&#x0043D;', '&ncy;', '__ent_CYRILLIC_SMALL_LETTER_EN'),
('&#x0043E;', '&ocy;', '__ent_CYRILLIC_SMALL_LETTER_O'),
('&#x0043F;', '&pcy;', '__ent_CYRILLIC_SMALL_LETTER_PE'),
('&#x00440;', '&rcy;', '__ent_CYRILLIC_SMALL_LETTER_ER'),
('&#x00441;', '&scy;', '__ent_CYRILLIC_SMALL_LETTER_ES'),
('&#x00442;', '&tcy;', '__ent_CYRILLIC_SMALL_LETTER_TE'),
('&#x00443;', '&ucy;', '__ent_CYRILLIC_SMALL_LETTER_U'),
('&#x00444;', '&fcy;', '__ent_CYRILLIC_SMALL_LETTER_EF'),
('&#x00445;', '&khcy;', '__ent_CYRILLIC_SMALL_LETTER_HA'),
('&#x00446;', '&tscy;', '__ent_CYRILLIC_SMALL_LETTER_TSE'),
('&#x00447;', '&chcy;', '__ent_CYRILLIC_SMALL_LETTER_CHE'),
('&#x00448;', '&shcy;', '__ent_CYRILLIC_SMALL_LETTER_SHA'),
('&#x00449;', '&shchcy;', '__ent_CYRILLIC_SMALL_LETTER_SHCHA'),
('&#x0044A;', '&hardcy;', '__ent_CYRILLIC_SMALL_LETTER_HARD_SIGN'),
('&#x0044B;', '&ycy;', '__ent_CYRILLIC_SMALL_LETTER_YERU'),
('&#x0044C;', '&softcy;', '__ent_CYRILLIC_SMALL_LETTER_SOFT_SIGN'),
('&#x0044D;', '&ecy;', '__ent_CYRILLIC_SMALL_LETTER_E'),
('&#x0044E;', '&yucy;', '__ent_CYRILLIC_SMALL_LETTER_YU'),
('&#x0044F;', '&yacy;', '__ent_CYRILLIC_SMALL_LETTER_YA'),
('&#x00451;', '&iocy;', '__ent_CYRILLIC_SMALL_LETTER_IO'),
('&#x00452;', '&djcy;', '__ent_CYRILLIC_SMALL_LETTER_DJE'),
('&#x00453;', '&gjcy;', '__ent_CYRILLIC_SMALL_LETTER_GJE'),
('&#x00454;', '&jukcy;', '__ent_CYRILLIC_SMALL_LETTER_UKRAINIAN_IE'),
('&#x00455;', '&dscy;', '__ent_CYRILLIC_SMALL_LETTER_DZE'),
('&#x00456;', '&iukcy;', '__ent_CYRILLIC_SMALL_LETTER_BYELORUSSIAN_UKRAINIAN_I'),
('&#x00457;', '&yicy;', '__ent_CYRILLIC_SMALL_LETTER_YI'),
('&#x00458;', '&jsercy;', '__ent_CYRILLIC_SMALL_LETTER_JE'),
('&#x00459;', '&ljcy;', '__ent_CYRILLIC_SMALL_LETTER_LJE'),
('&#x0045A;', '&njcy;', '__ent_CYRILLIC_SMALL_LETTER_NJE'),
('&#x0045B;', '&tshcy;', '__ent_CYRILLIC_SMALL_LETTER_TSHE'),
('&#x0045C;', '&kjcy;', '__ent_CYRILLIC_SMALL_LETTER_KJE'),
('&#x0045E;', '&ubrcy;', '__ent_CYRILLIC_SMALL_LETTER_SHORT_U'),
('&#x0045F;', '&dzcy;', '__ent_CYRILLIC_SMALL_LETTER_DZHE'),
('&#x02002;', '&ensp;', '__ent_EN_SPACE'),
('&#x02003;', '&emsp;', '__ent_EM_SPACE'),
('&#x02004;', '&emsp13;', '__ent_THREE_PER_EM_SPACE'),
('&#x02005;', '&emsp14;', '__ent_FOUR_PER_EM_SPACE'),
('&#x02007;', '&numsp;', '__ent_FIGURE_SPACE'),
('&#x02008;', '&puncsp;', '__ent_PUNCTUATION_SPACE'),
('&#x02009;', '&thinsp;', '__ent_THIN_SPACE'),
('&#x0200A;', '&hairsp;', '__ent_HAIR_SPACE'),
('&#x0200B;', '&ZeroWidthSpace;', '__ent_ZERO_WIDTH_SPACE'),
('&#x0200C;', '&zwnj;', '__ent_ZERO_WIDTH_NON_JOINER'),
('&#x0200D;', '&zwj;', '__ent_ZERO_WIDTH_JOINER'),
('&#x0200E;', '&lrm;', '__ent_LEFT_TO_RIGHT_MARK'),
('&#x0200F;', '&rlm;', '__ent_RIGHT_TO_LEFT_MARK'),
('&#x02010;', '&hyphen;', '__ent_HYPHEN'),
('&#x02013;', '&ndash;', '__ent_EN_DASH'),
('&#x02014;', '&mdash;', '__ent_EM_DASH'),
('&#x02015;', '&horbar;', '__ent_HORIZONTAL_BAR'),
('&#x02016;', '&Verbar;', '__ent_DOUBLE_VERTICAL_LINE'),
('&#x02018;', '&lsquo;', '__ent_LEFT_SINGLE_QUOTATION_MARK'),
('&#x02019;', '&rsquo;', '__ent_RIGHT_SINGLE_QUOTATION_MARK'),
('&#x0201A;', '&lsquor;', '__ent_SINGLE_LOW_9_QUOTATION_MARK'),
('&#x0201C;', '&ldquo;', '__ent_LEFT_DOUBLE_QUOTATION_MARK'),
('&#x0201D;', '&rdquo;', '__ent_RIGHT_DOUBLE_QUOTATION_MARK'),
('&#x0201E;', '&ldquor;', '__ent_DOUBLE_LOW_9_QUOTATION_MARK'),
('&#x02020;', '&dagger;', '__ent_DAGGER'),
('&#x02021;', '&Dagger;', '__ent_DOUBLE_DAGGER'),
('&#x02022;', '&bull;', '__ent_BULLET'),
('&#x02025;', '&nldr;', '__ent_TWO_DOT_LEADER'),
('&#x02026;', '&hellip;', '__ent_HORIZONTAL_ELLIPSIS'),
('&#x02030;', '&permil;', '__ent_PER_MILLE_SIGN'),
('&#x02031;', '&pertenk;', '__ent_PER_TEN_THOUSAND_SIGN'),
('&#x02032;', '&prime;', '__ent_PRIME'),
('&#x02033;', '&Prime;', '__ent_DOUBLE_PRIME'),
('&#x02034;', '&tprime;', '__ent_TRIPLE_PRIME'),
('&#x02035;', '&bprime;', '__ent_REVERSED_PRIME'),
('&#x02039;', '&lsaquo;', '__ent_SINGLE_LEFT_POINTING_ANGLE_QUOTATION_MARK'),
('&#x0203A;', '&rsaquo;', '__ent_SINGLE_RIGHT_POINTING_ANGLE_QUOTATION_MARK'),
('&#x0203E;', '&oline;', '__ent_OVERLINE'),
('&#x02041;', '&caret;', '__ent_CARET_INSERTION_POINT'),
('&#x02043;', '&hybull;', '__ent_HYPHEN_BULLET'),
('&#x02044;', '&frasl;', '__ent_FRACTION_SLASH'),
('&#x0204F;', '&bsemi;', '__ent_REVERSED_SEMICOLON'),
('&#x02057;', '&qprime;', '__ent_QUADRUPLE_PRIME'),
('&#x0205F;', '&MediumSpace;', '__ent_MEDIUM_MATHEMATICAL_SPACE'),
('&#x02060;', '&NoBreak;', '__ent_WORD_JOINER'),
('&#x02061;', '&ApplyFunction;', '__ent_FUNCTION_APPLICATION'),
('&#x02062;', '&InvisibleTimes;', '__ent_INVISIBLE_TIMES'),
('&#x02063;', '&InvisibleComma;', '__ent_INVISIBLE_SEPARATOR'),
('&#x020AC;', '&euro;', '__ent_EURO_SIGN'),
('&#x020DB;', '&tdot;', '__ent_COMBINING_THREE_DOTS_ABOVE'),
('&#x020DC;', '&DotDot;', '__ent_COMBINING_FOUR_DOTS_ABOVE'),
('&#x02102;', '&Copf;', '__ent_DOUBLE_STRUCK_CAPITAL_C'),
('&#x02105;', '&incare;', '__ent_CARE_OF'),
('&#x0210A;', '&gscr;', '__ent_SCRIPT_SMALL_G'),
('&#x0210B;', '&hamilt;', '__ent_SCRIPT_CAPITAL_H'),
('&#x0210C;', '&Hfr;', '__ent_BLACK_LETTER_CAPITAL_H'),
('&#x0210D;', '&quaternions;', '__ent_DOUBLE_STRUCK_CAPITAL_H'),
('&#x0210E;', '&planckh;', '__ent_PLANCK_CONSTANT'),
('&#x0210F;', '&planck;', '__ent_PLANCK_CONSTANT_OVER_TWO_PI'),
('&#x02110;', '&Iscr;', '__ent_SCRIPT_CAPITAL_I'),
('&#x02111;', '&image;', '__ent_BLACK_LETTER_CAPITAL_I'),
('&#x02112;', '&Lscr;', '__ent_SCRIPT_CAPITAL_L'),
('&#x02113;', '&ell;', '__ent_SCRIPT_SMALL_L'),
('&#x02115;', '&Nopf;', '__ent_DOUBLE_STRUCK_CAPITAL_N'),
('&#x02116;', '&numero;', '__ent_NUMERO_SIGN'),
('&#x02117;', '&copysr;', '__ent_SOUND_RECORDING_COPYRIGHT'),
('&#x02118;', '&weierp;', '__ent_SCRIPT_CAPITAL_P'),
('&#x02119;', '&Popf;', '__ent_DOUBLE_STRUCK_CAPITAL_P'),
('&#x0211A;', '&rationals;', '__ent_DOUBLE_STRUCK_CAPITAL_Q'),
('&#x0211B;', '&Rscr;', '__ent_SCRIPT_CAPITAL_R'),
('&#x0211C;', '&real;', '__ent_BLACK_LETTER_CAPITAL_R'),
('&#x0211D;', '&reals;', '__ent_DOUBLE_STRUCK_CAPITAL_R'),
('&#x0211E;', '&rx;', '__ent_PRESCRIPTION_TAKE'),
('&#x02122;', '&trade;', '__ent_TRADE_MARK_SIGN'),
('&#x02124;', '&integers;', '__ent_DOUBLE_STRUCK_CAPITAL_Z'),
('&#x02126;', '&ohm;', '__ent_OHM_SIGN'),
('&#x02127;', '&mho;', '__ent_INVERTED_OHM_SIGN'),
('&#x02128;', '&Zfr;', '__ent_BLACK_LETTER_CAPITAL_Z'),
('&#x02129;', '&iiota;', '__ent_TURNED_GREEK_SMALL_LETTER_IOTA'),
('&#x0212B;', '&angst;', '__ent_ANGSTROM_SIGN'),
('&#x0212C;', '&bernou;', '__ent_SCRIPT_CAPITAL_B'),
('&#x0212D;', '&Cfr;', '__ent_BLACK_LETTER_CAPITAL_C'),
('&#x0212F;', '&escr;', '__ent_SCRIPT_SMALL_E'),
('&#x02130;', '&Escr;', '__ent_SCRIPT_CAPITAL_E'),
('&#x02131;', '&Fscr;', '__ent_SCRIPT_CAPITAL_F'),
('&#x02133;', '&phmmat;', '__ent_SCRIPT_CAPITAL_M'),
('&#x02134;', '&order;', '__ent_SCRIPT_SMALL_O'),
('&#x02135;', '&alefsym;', '__ent_ALEF_SYMBOL'),
('&#x02136;', '&beth;', '__ent_BET_SYMBOL'),
('&#x02137;', '&gimel;', '__ent_GIMEL_SYMBOL'),
('&#x02138;', '&daleth;', '__ent_DALET_SYMBOL'),
('&#x02145;', '&CapitalDifferentialD;', '__ent_DOUBLE_STRUCK_ITALIC_CAPITAL_D'),
('&#x02146;', '&DifferentialD;', '__ent_DOUBLE_STRUCK_ITALIC_SMALL_D'),
('&#x02147;', '&ExponentialE;', '__ent_DOUBLE_STRUCK_ITALIC_SMALL_E'),
('&#x02148;', '&ImaginaryI;', '__ent_DOUBLE_STRUCK_ITALIC_SMALL_I'),
('&#x02153;', '&frac13;', '__ent_VULGAR_FRACTION_ONE_THIRD'),
('&#x02154;', '&frac23;', '__ent_VULGAR_FRACTION_TWO_THIRDS'),
('&#x02155;', '&frac15;', '__ent_VULGAR_FRACTION_ONE_FIFTH'),
('&#x02156;', '&frac25;', '__ent_VULGAR_FRACTION_TWO_FIFTHS'),
('&#x02157;', '&frac35;', '__ent_VULGAR_FRACTION_THREE_FIFTHS'),
('&#x02158;', '&frac45;', '__ent_VULGAR_FRACTION_FOUR_FIFTHS'),
('&#x02159;', '&frac16;', '__ent_VULGAR_FRACTION_ONE_SIXTH'),
('&#x0215A;', '&frac56;', '__ent_VULGAR_FRACTION_FIVE_SIXTHS'),
('&#x0215B;', '&frac18;', '__ent_VULGAR_FRACTION_ONE_EIGHTH'),
('&#x0215C;', '&frac38;', '__ent_VULGAR_FRACTION_THREE_EIGHTHS'),
('&#x0215D;', '&frac58;', '__ent_VULGAR_FRACTION_FIVE_EIGHTHS'),
('&#x0215E;', '&frac78;', '__ent_VULGAR_FRACTION_SEVEN_EIGHTHS'),
('&#x02190;', '&larr;', '__ent_LEFTWARDS_ARROW'),
('&#x02191;', '&uarr;', '__ent_UPWARDS_ARROW'),
('&#x02192;', '&rarr;', '__ent_RIGHTWARDS_ARROW'),
('&#x02193;', '&darr;', '__ent_DOWNWARDS_ARROW'),
('&#x02194;', '&harr;', '__ent_LEFT_RIGHT_ARROW'),
('&#x02195;', '&varr;', '__ent_UP_DOWN_ARROW'),
('&#x02196;', '&nwarr;', '__ent_NORTH_WEST_ARROW'),
('&#x02197;', '&nearr;', '__ent_NORTH_EAST_ARROW'),
('&#x02198;', '&searr;', '__ent_SOUTH_EAST_ARROW'),
('&#x02199;', '&swarr;', '__ent_SOUTH_WEST_ARROW'),
('&#x0219A;', '&nlarr;', '__ent_LEFTWARDS_ARROW_WITH_STROKE'),
('&#x0219B;', '&nrarr;', '__ent_RIGHTWARDS_ARROW_WITH_STROKE'),
('&#x0219D;', '&rarrw;', '__ent_RIGHTWARDS_WAVE_ARROW'),
('&#x0219E;', '&Larr;', '__ent_LEFTWARDS_TWO_HEADED_ARROW'),
('&#x0219F;', '&Uarr;', '__ent_UPWARDS_TWO_HEADED_ARROW'),
('&#x021A0;', '&Rarr;', '__ent_RIGHTWARDS_TWO_HEADED_ARROW'),
('&#x021A1;', '&Darr;', '__ent_DOWNWARDS_TWO_HEADED_ARROW'),
('&#x021A2;', '&larrtl;', '__ent_LEFTWARDS_ARROW_WITH_TAIL'),
('&#x021A3;', '&rarrtl;', '__ent_RIGHTWARDS_ARROW_WITH_TAIL'),
('&#x021A4;', '&LeftTeeArrow;', '__ent_LEFTWARDS_ARROW_FROM_BAR'),
('&#x021A5;', '&UpTeeArrow;', '__ent_UPWARDS_ARROW_FROM_BAR'),
('&#x021A6;', '&map;', '__ent_RIGHTWARDS_ARROW_FROM_BAR'),
('&#x021A7;', '&DownTeeArrow;', '__ent_DOWNWARDS_ARROW_FROM_BAR'),
('&#x021A9;', '&larrhk;', '__ent_LEFTWARDS_ARROW_WITH_HOOK'),
('&#x021AA;', '&rarrhk;', '__ent_RIGHTWARDS_ARROW_WITH_HOOK'),
('&#x021AB;', '&larrlp;', '__ent_LEFTWARDS_ARROW_WITH_LOOP'),
('&#x021AC;', '&rarrlp;', '__ent_RIGHTWARDS_ARROW_WITH_LOOP'),
('&#x021AD;', '&harrw;', '__ent_LEFT_RIGHT_WAVE_ARROW'),
('&#x021AE;', '&nharr;', '__ent_LEFT_RIGHT_ARROW_WITH_STROKE'),
('&#x021B0;', '&lsh;', '__ent_UPWARDS_ARROW_WITH_TIP_LEFTWARDS'),
('&#x021B1;', '&rsh;', '__ent_UPWARDS_ARROW_WITH_TIP_RIGHTWARDS'),
('&#x021B2;', '&ldsh;', '__ent_DOWNWARDS_ARROW_WITH_TIP_LEFTWARDS'),
('&#x021B3;', '&rdsh;', '__ent_DOWNWARDS_ARROW_WITH_TIP_RIGHTWARDS'),
('&#x021B5;', '&crarr;', '__ent_DOWNWARDS_ARROW_WITH_CORNER_LEFTWARDS'),
('&#x021B6;', '&cularr;', '__ent_ANTICLOCKWISE_TOP_SEMICIRCLE_ARROW'),
('&#x021B7;', '&curarr;', '__ent_CLOCKWISE_TOP_SEMICIRCLE_ARROW'),
('&#x021BA;', '&olarr;', '__ent_ANTICLOCKWISE_OPEN_CIRCLE_ARROW'),
('&#x021BB;', '&orarr;', '__ent_CLOCKWISE_OPEN_CIRCLE_ARROW'),
('&#x021BC;', '&lharu;', '__ent_LEFTWARDS_HARPOON_WITH_BARB_UPWARDS'),
('&#x021BD;', '&lhard;', '__ent_LEFTWARDS_HARPOON_WITH_BARB_DOWNWARDS'),
('&#x021BE;', '&uharr;', '__ent_UPWARDS_HARPOON_WITH_BARB_RIGHTWARDS'),
('&#x021BF;', '&uharl;', '__ent_UPWARDS_HARPOON_WITH_BARB_LEFTWARDS'),
('&#x021C0;', '&rharu;', '__ent_RIGHTWARDS_HARPOON_WITH_BARB_UPWARDS'),
('&#x021C1;', '&rhard;', '__ent_RIGHTWARDS_HARPOON_WITH_BARB_DOWNWARDS'),
('&#x021C2;', '&dharr;', '__ent_DOWNWARDS_HARPOON_WITH_BARB_RIGHTWARDS'),
('&#x021C3;', '&dharl;', '__ent_DOWNWARDS_HARPOON_WITH_BARB_LEFTWARDS'),
('&#x021C4;', '&rlarr;', '__ent_RIGHTWARDS_ARROW_OVER_LEFTWARDS_ARROW'),
('&#x021C5;', '&udarr;', '__ent_UPWARDS_ARROW_LEFTWARDS_OF_DOWNWARDS_ARROW'),
('&#x021C6;', '&lrarr;', '__ent_LEFTWARDS_ARROW_OVER_RIGHTWARDS_ARROW'),
('&#x021C7;', '&llarr;', '__ent_LEFTWARDS_PAIRED_ARROWS'),
('&#x021C8;', '&uuarr;', '__ent_UPWARDS_PAIRED_ARROWS'),
('&#x021C9;', '&rrarr;', '__ent_RIGHTWARDS_PAIRED_ARROWS'),
('&#x021CA;', '&ddarr;', '__ent_DOWNWARDS_PAIRED_ARROWS'),
('&#x021CB;', '&lrhar;', '__ent_LEFTWARDS_HARPOON_OVER_RIGHTWARDS_HARPOON'),
('&#x021CC;', '&rlhar;', '__ent_RIGHTWARDS_HARPOON_OVER_LEFTWARDS_HARPOON'),
('&#x021CD;', '&nlArr;', '__ent_LEFTWARDS_DOUBLE_ARROW_WITH_STROKE'),
('&#x021CE;', '&nhArr;', '__ent_LEFT_RIGHT_DOUBLE_ARROW_WITH_STROKE'),
('&#x021CF;', '&nrArr;', '__ent_RIGHTWARDS_DOUBLE_ARROW_WITH_STROKE'),
('&#x021D0;', '&lArr;', '__ent_LEFTWARDS_DOUBLE_ARROW'),
('&#x021D1;', '&uArr;', '__ent_UPWARDS_DOUBLE_ARROW'),
('&#x021D2;', '&rArr;', '__ent_RIGHTWARDS_DOUBLE_ARROW'),
('&#x021D3;', '&dArr;', '__ent_DOWNWARDS_DOUBLE_ARROW'),
('&#x021D4;', '&hArr;', '__ent_LEFT_RIGHT_DOUBLE_ARROW'),
('&#x021D5;', '&vArr;', '__ent_UP_DOWN_DOUBLE_ARROW'),
('&#x021D6;', '&nwArr;', '__ent_NORTH_WEST_DOUBLE_ARROW'),
('&#x021D7;', '&neArr;', '__ent_NORTH_EAST_DOUBLE_ARROW'),
('&#x021D8;', '&seArr;', '__ent_SOUTH_EAST_DOUBLE_ARROW'),
('&#x021D9;', '&swArr;', '__ent_SOUTH_WEST_DOUBLE_ARROW'),
('&#x021DA;', '&lAarr;', '__ent_LEFTWARDS_TRIPLE_ARROW'),
('&#x021DB;', '&rAarr;', '__ent_RIGHTWARDS_TRIPLE_ARROW'),
('&#x021DD;', '&zigrarr;', '__ent_RIGHTWARDS_SQUIGGLE_ARROW'),
('&#x021E4;', '&larrb;', '__ent_LEFTWARDS_ARROW_TO_BAR'),
('&#x021E5;', '&rarrb;', '__ent_RIGHTWARDS_ARROW_TO_BAR'),
('&#x021F5;', '&duarr;', '__ent_DOWNWARDS_ARROW_LEFTWARDS_OF_UPWARDS_ARROW'),
('&#x021FD;', '&loarr;', '__ent_LEFTWARDS_OPEN_HEADED_ARROW'),
('&#x021FE;', '&roarr;', '__ent_RIGHTWARDS_OPEN_HEADED_ARROW'),
('&#x021FF;', '&hoarr;', '__ent_LEFT_RIGHT_OPEN_HEADED_ARROW'),
('&#x02200;', '&forall;', '__ent_FOR_ALL'),
('&#x02201;', '&comp;', '__ent_COMPLEMENT'),
('&#x02202;', '&part;', '__ent_PARTIAL_DIFFERENTIAL'),
('&#x02203;', '&exist;', '__ent_THERE_EXISTS'),
('&#x02204;', '&nexist;', '__ent_THERE_DOES_NOT_EXIST'),
('&#x02205;', '&empty;', '__ent_EMPTY_SET'),
('&#x02207;', '&nabla;', '__ent_NABLA'),
('&#x02208;', '&isin;', '__ent_ELEMENT_OF'),
('&#x02209;', '&notin;', '__ent_NOT_AN_ELEMENT_OF'),
('&#x0220B;', '&niv;', '__ent_CONTAINS_AS_MEMBER'),
('&#x0220C;', '&notni;', '__ent_DOES_NOT_CONTAIN_AS_MEMBER'),
('&#x0220F;', '&prod;', '__ent_N_ARY_PRODUCT'),
('&#x02210;', '&coprod;', '__ent_N_ARY_COPRODUCT'),
('&#x02211;', '&sum;', '__ent_N_ARY_SUMMATION'),
('&#x02212;', '&minus;', '__ent_MINUS_SIGN'),
('&#x02213;', '&mnplus;', '__ent_MINUS_OR_PLUS_SIGN'),
('&#x02214;', '&plusdo;', '__ent_DOT_PLUS'),
('&#x02216;', '&setmn;', '__ent_SET_MINUS'),
('&#x02217;', '&lowast;', '__ent_ASTERISK_OPERATOR'),
('&#x02218;', '&compfn;', '__ent_RING_OPERATOR'),
('&#x0221A;', '&radic;', '__ent_SQUARE_ROOT'),
('&#x0221D;', '&prop;', '__ent_PROPORTIONAL_TO'),
('&#x0221E;', '&infin;', '__ent_INFINITY'),
('&#x0221F;', '&angrt;', '__ent_RIGHT_ANGLE'),
('&#x02220;', '&ang;', '__ent_ANGLE'),
('&#x02221;', '&angmsd;', '__ent_MEASURED_ANGLE'),
('&#x02222;', '&angsph;', '__ent_SPHERICAL_ANGLE'),
('&#x02223;', '&mid;', '__ent_DIVIDES'),
('&#x02224;', '&nmid;', '__ent_DOES_NOT_DIVIDE'),
('&#x02225;', '&par;', '__ent_PARALLEL_TO'),
('&#x02226;', '&npar;', '__ent_NOT_PARALLEL_TO'),
('&#x02227;', '&and;', '__ent_LOGICAL_AND'),
('&#x02228;', '&or;', '__ent_LOGICAL_OR'),
('&#x02229;', '&cap;', '__ent_INTERSECTION'),
('&#x0222A;', '&cup;', '__ent_UNION'),
('&#x0222B;', '&int;', '__ent_INTEGRAL'),
('&#x0222C;', '&Int;', '__ent_DOUBLE_INTEGRAL'),
('&#x0222D;', '&tint;', '__ent_TRIPLE_INTEGRAL'),
('&#x0222E;', '&conint;', '__ent_CONTOUR_INTEGRAL'),
('&#x0222F;', '&Conint;', '__ent_SURFACE_INTEGRAL'),
('&#x02230;', '&Cconint;', '__ent_VOLUME_INTEGRAL'),
('&#x02231;', '&cwint;', '__ent_CLOCKWISE_INTEGRAL'),
('&#x02232;', '&cwconint;', '__ent_CLOCKWISE_CONTOUR_INTEGRAL'),
('&#x02233;', '&awconint;', '__ent_ANTICLOCKWISE_CONTOUR_INTEGRAL'),
('&#x02234;', '&there4;', '__ent_THEREFORE'),
('&#x02235;', '&becaus;', '__ent_BECAUSE'),
('&#x02236;', '&ratio;', '__ent_RATIO'),
('&#x02237;', '&Colon;', '__ent_PROPORTION'),
('&#x02238;', '&minusd;', '__ent_DOT_MINUS'),
('&#x0223A;', '&mDDot;', '__ent_GEOMETRIC_PROPORTION'),
('&#x0223B;', '&homtht;', '__ent_HOMOTHETIC'),
('&#x0223C;', '&sim;', '__ent_TILDE_OPERATOR'),
('&#x0223D;', '&bsim;', '__ent_REVERSED_TILDE'),
('&#x0223E;', '&ac;', '__ent_INVERTED_LAZY_S'),
('&#x0223F;', '&acd;', '__ent_SINE_WAVE'),
('&#x02240;', '&wreath;', '__ent_WREATH_PRODUCT'),
('&#x02241;', '&nsim;', '__ent_NOT_TILDE'),
('&#x02242;', '&esim;', '__ent_MINUS_TILDE'),
('&#x02243;', '&sime;', '__ent_ASYMPTOTICALLY_EQUAL_TO'),
('&#x02244;', '&nsime;', '__ent_NOT_ASYMPTOTICALLY_EQUAL_TO'),
('&#x02245;', '&cong;', '__ent_APPROXIMATELY_EQUAL_TO'),
('&#x02246;', '&simne;', '__ent_APPROXIMATELY_BUT_NOT_ACTUALLY_EQUAL_TO'),
('&#x02247;', '&ncong;', '__ent_NEITHER_APPROXIMATELY_NOR_ACTUALLY_EQUAL_TO'),
('&#x02248;', '&asymp;', '__ent_ALMOST_EQUAL_TO'),
('&#x02249;', '&nap;', '__ent_NOT_ALMOST_EQUAL_TO'),
('&#x0224A;', '&ape;', '__ent_ALMOST_EQUAL_OR_EQUAL_TO'),
('&#x0224B;', '&apid;', '__ent_TRIPLE_TILDE'),
('&#x0224C;', '&bcong;', '__ent_ALL_EQUAL_TO'),
('&#x0224D;', '&asympeq;', '__ent_EQUIVALENT_TO'),
('&#x0224E;', '&bump;', '__ent_GEOMETRICALLY_EQUIVALENT_TO'),
('&#x0224F;', '&bumpe;', '__ent_DIFFERENCE_BETWEEN'),
('&#x02250;', '&esdot;', '__ent_APPROACHES_THE_LIMIT'),
('&#x02251;', '&eDot;', '__ent_GEOMETRICALLY_EQUAL_TO'),
('&#x02252;', '&efDot;', '__ent_APPROXIMATELY_EQUAL_TO_OR_THE_IMAGE_OF'),
('&#x02253;', '&erDot;', '__ent_IMAGE_OF_OR_APPROXIMATELY_EQUAL_TO'),
('&#x02254;', '&colone;', '__ent_COLON_EQUALS'),
('&#x02255;', '&ecolon;', '__ent_EQUALS_COLON'),
('&#x02256;', '&ecir;', '__ent_RING_IN_EQUAL_TO'),
('&#x02257;', '&cire;', '__ent_RING_EQUAL_TO'),
('&#x02259;', '&wedgeq;', '__ent_ESTIMATES'),
('&#x0225A;', '&veeeq;', '__ent_EQUIANGULAR_TO'),
('&#x0225C;', '&trie;', '__ent_DELTA_EQUAL_TO'),
('&#x0225F;', '&equest;', '__ent_QUESTIONED_EQUAL_TO'),
('&#x02260;', '&ne;', '__ent_NOT_EQUAL_TO'),
('&#x02261;', '&equiv;', '__ent_IDENTICAL_TO'),
('&#x02262;', '&nequiv;', '__ent_NOT_IDENTICAL_TO'),
('&#x02264;', '&le;', '__ent_LESS_THAN_OR_EQUAL_TO'),
('&#x02265;', '&ge;', '__ent_GREATER_THAN_OR_EQUAL_TO'),
('&#x02266;', '&lE;', '__ent_LESS_THAN_OVER_EQUAL_TO'),
('&#x02267;', '&gE;', '__ent_GREATER_THAN_OVER_EQUAL_TO'),
('&#x02268;', '&lnE;', '__ent_LESS_THAN_BUT_NOT_EQUAL_TO'),
('&#x02269;', '&gnE;', '__ent_GREATER_THAN_BUT_NOT_EQUAL_TO'),
('&#x0226A;', '&Lt;', '__ent_MUCH_LESS_THAN'),
('&#x0226B;', '&Gt;', '__ent_MUCH_GREATER_THAN'),
('&#x0226C;', '&twixt;', '__ent_BETWEEN'),
('&#x0226D;', '&NotCupCap;', '__ent_NOT_EQUIVALENT_TO'),
('&#x0226E;', '&nlt;', '__ent_NOT_LESS_THAN'),
('&#x0226F;', '&ngt;', '__ent_NOT_GREATER_THAN'),
('&#x02270;', '&nle;', '__ent_NEITHER_LESS_THAN_NOR_EQUAL_TO'),
('&#x02271;', '&nge;', '__ent_NEITHER_GREATER_THAN_NOR_EQUAL_TO'),
('&#x02272;', '&lsim;', '__ent_LESS_THAN_OR_EQUIVALENT_TO'),
('&#x02273;', '&gsim;', '__ent_GREATER_THAN_OR_EQUIVALENT_TO'),
('&#x02274;', '&nlsim;', '__ent_NEITHER_LESS_THAN_NOR_EQUIVALENT_TO'),
('&#x02275;', '&ngsim;', '__ent_NEITHER_GREATER_THAN_NOR_EQUIVALENT_TO'),
('&#x02276;', '&lg;', '__ent_LESS_THAN_OR_GREATER_THAN'),
('&#x02277;', '&gl;', '__ent_GREATER_THAN_OR_LESS_THAN'),
('&#x02278;', '&ntlg;', '__ent_NEITHER_LESS_THAN_NOR_GREATER_THAN'),
('&#x02279;', '&ntgl;', '__ent_NEITHER_GREATER_THAN_NOR_LESS_THAN'),
('&#x0227A;', '&pr;', '__ent_PRECEDES'),
('&#x0227B;', '&sc;', '__ent_SUCCEEDS'),
('&#x0227C;', '&prcue;', '__ent_PRECEDES_OR_EQUAL_TO'),
('&#x0227D;', '&sccue;', '__ent_SUCCEEDS_OR_EQUAL_TO'),
('&#x0227E;', '&prsim;', '__ent_PRECEDES_OR_EQUIVALENT_TO'),
('&#x0227F;', '&scsim;', '__ent_SUCCEEDS_OR_EQUIVALENT_TO'),
('&#x02280;', '&npr;', '__ent_DOES_NOT_PRECEDE'),
('&#x02281;', '&nsc;', '__ent_DOES_NOT_SUCCEED'),
('&#x02282;', '&sub;', '__ent_SUBSET_OF'),
('&#x02283;', '&sup;', '__ent_SUPERSET_OF'),
('&#x02284;', '&nsub;', '__ent_NOT_A_SUBSET_OF'),
('&#x02285;', '&nsup;', '__ent_NOT_A_SUPERSET_OF'),
('&#x02286;', '&sube;', '__ent_SUBSET_OF_OR_EQUAL_TO'),
('&#x02287;', '&supe;', '__ent_SUPERSET_OF_OR_EQUAL_TO'),
('&#x02288;', '&nsube;', '__ent_NEITHER_A_SUBSET_OF_NOR_EQUAL_TO'),
('&#x02289;', '&nsupe;', '__ent_NEITHER_A_SUPERSET_OF_NOR_EQUAL_TO'),
('&#x0228A;', '&subne;', '__ent_SUBSET_OF_WITH_NOT_EQUAL_TO'),
('&#x0228B;', '&supne;', '__ent_SUPERSET_OF_WITH_NOT_EQUAL_TO'),
('&#x0228D;', '&cupdot;', '__ent_MULTISET_MULTIPLICATION'),
('&#x0228E;', '&uplus;', '__ent_MULTISET_UNION'),
('&#x0228F;', '&sqsub;', '__ent_SQUARE_IMAGE_OF'),
('&#x02290;', '&sqsup;', '__ent_SQUARE_ORIGINAL_OF'),
('&#x02291;', '&sqsube;', '__ent_SQUARE_IMAGE_OF_OR_EQUAL_TO'),
('&#x02292;', '&sqsupe;', '__ent_SQUARE_ORIGINAL_OF_OR_EQUAL_TO'),
('&#x02293;', '&sqcap;', '__ent_SQUARE_CAP'),
('&#x02294;', '&sqcup;', '__ent_SQUARE_CUP'),
('&#x02295;', '&oplus;', '__ent_CIRCLED_PLUS'),
('&#x02296;', '&ominus;', '__ent_CIRCLED_MINUS'),
('&#x02297;', '&otimes;', '__ent_CIRCLED_TIMES'),
('&#x02298;', '&osol;', '__ent_CIRCLED_DIVISION_SLASH'),
('&#x02299;', '&odot;', '__ent_CIRCLED_DOT_OPERATOR'),
('&#x0229A;', '&ocir;', '__ent_CIRCLED_RING_OPERATOR'),
('&#x0229B;', '&oast;', '__ent_CIRCLED_ASTERISK_OPERATOR'),
('&#x0229D;', '&odash;', '__ent_CIRCLED_DASH'),
('&#x0229E;', '&plusb;', '__ent_SQUARED_PLUS'),
('&#x0229F;', '&minusb;', '__ent_SQUARED_MINUS'),
('&#x022A0;', '&timesb;', '__ent_SQUARED_TIMES'),
('&#x022A1;', '&sdotb;', '__ent_SQUARED_DOT_OPERATOR'),
('&#x022A2;', '&vdash;', '__ent_RIGHT_TACK'),
('&#x022A3;', '&dashv;', '__ent_LEFT_TACK'),
('&#x022A4;', '&top;', '__ent_DOWN_TACK'),
('&#x022A5;', '&bottom;', '__ent_UP_TACK'),
('&#x022A7;', '&models;', '__ent_MODELS'),
('&#x022A8;', '&vDash;', '__ent_TRUE'),
('&#x022A9;', '&Vdash;', '__ent_FORCES'),
('&#x022AA;', '&Vvdash;', '__ent_TRIPLE_VERTICAL_BAR_RIGHT_TURNSTILE'),
('&#x022AB;', '&VDash;', '__ent_DOUBLE_VERTICAL_BAR_DOUBLE_RIGHT_TURNSTILE'),
('&#x022AC;', '&nvdash;', '__ent_DOES_NOT_PROVE'),
('&#x022AD;', '&nvDash;', '__ent_NOT_TRUE'),
('&#x022AE;', '&nVdash;', '__ent_DOES_NOT_FORCE'),
('&#x022AF;', '&nVDash;', '__ent_NEGATED_DOUBLE_VERTICAL_BAR_DOUBLE_RIGHT_TURNSTILE'),
('&#x022B0;', '&prurel;', '__ent_PRECEDES_UNDER_RELATION'),
('&#x022B2;', '&vltri;', '__ent_NORMAL_SUBGROUP_OF'),
('&#x022B3;', '&vrtri;', '__ent_CONTAINS_AS_NORMAL_SUBGROUP'),
('&#x022B4;', '&ltrie;', '__ent_NORMAL_SUBGROUP_OF_OR_EQUAL_TO'),
('&#x022B5;', '&rtrie;', '__ent_CONTAINS_AS_NORMAL_SUBGROUP_OR_EQUAL_TO'),
('&#x022B6;', '&origof;', '__ent_ORIGINAL_OF'),
('&#x022B7;', '&imof;', '__ent_IMAGE_OF'),
('&#x022B8;', '&mumap;', '__ent_MULTIMAP'),
('&#x022B9;', '&hercon;', '__ent_HERMITIAN_CONJUGATE_MATRIX'),
('&#x022BA;', '&intcal;', '__ent_INTERCALATE'),
('&#x022BB;', '&veebar;', '__ent_XOR'),
('&#x022BD;', '&barvee;', '__ent_NOR'),
('&#x022BE;', '&angrtvb;', '__ent_RIGHT_ANGLE_WITH_ARC'),
('&#x022BF;', '&lrtri;', '__ent_RIGHT_TRIANGLE'),
('&#x022C0;', '&xwedge;', '__ent_N_ARY_LOGICAL_AND'),
('&#x022C1;', '&xvee;', '__ent_N_ARY_LOGICAL_OR'),
('&#x022C2;', '&xcap;', '__ent_N_ARY_INTERSECTION'),
('&#x022C3;', '&xcup;', '__ent_N_ARY_UNION'),
('&#x022C4;', '&diam;', '__ent_DIAMOND_OPERATOR'),
('&#x022C5;', '&sdot;', '__ent_DOT_OPERATOR'),
('&#x022C6;', '&sstarf;', '__ent_STAR_OPERATOR'),
('&#x022C7;', '&divonx;', '__ent_DIVISION_TIMES'),
('&#x022C8;', '&bowtie;', '__ent_BOWTIE'),
('&#x022C9;', '&ltimes;', '__ent_LEFT_NORMAL_FACTOR_SEMIDIRECT_PRODUCT'),
('&#x022CA;', '&rtimes;', '__ent_RIGHT_NORMAL_FACTOR_SEMIDIRECT_PRODUCT'),
('&#x022CB;', '&lthree;', '__ent_LEFT_SEMIDIRECT_PRODUCT'),
('&#x022CC;', '&rthree;', '__ent_RIGHT_SEMIDIRECT_PRODUCT'),
('&#x022CD;', '&bsime;', '__ent_REVERSED_TILDE_EQUALS'),
('&#x022CE;', '&cuvee;', '__ent_CURLY_LOGICAL_OR'),
('&#x022CF;', '&cuwed;', '__ent_CURLY_LOGICAL_AND'),
('&#x022D0;', '&Sub;', '__ent_DOUBLE_SUBSET'),
('&#x022D1;', '&Sup;', '__ent_DOUBLE_SUPERSET'),
('&#x022D2;', '&Cap;', '__ent_DOUBLE_INTERSECTION'),
('&#x022D3;', '&Cup;', '__ent_DOUBLE_UNION'),
('&#x022D4;', '&fork;', '__ent_PITCHFORK'),
('&#x022D5;', '&epar;', '__ent_EQUAL_AND_PARALLEL_TO'),
('&#x022D6;', '&ltdot;', '__ent_LESS_THAN_WITH_DOT'),
('&#x022D7;', '&gtdot;', '__ent_GREATER_THAN_WITH_DOT'),
('&#x022D8;', '&Ll;', '__ent_VERY_MUCH_LESS_THAN'),
('&#x022D9;', '&Gg;', '__ent_VERY_MUCH_GREATER_THAN'),
('&#x022DA;', '&leg;', '__ent_LESS_THAN_EQUAL_TO_OR_GREATER_THAN'),
('&#x022DB;', '&gel;', '__ent_GREATER_THAN_EQUAL_TO_OR_LESS_THAN'),
('&#x022DE;', '&cuepr;', '__ent_EQUAL_TO_OR_PRECEDES'),
('&#x022DF;', '&cuesc;', '__ent_EQUAL_TO_OR_SUCCEEDS'),
('&#x022E0;', '&nprcue;', '__ent_DOES_NOT_PRECEDE_OR_EQUAL'),
('&#x022E1;', '&nsccue;', '__ent_DOES_NOT_SUCCEED_OR_EQUAL'),
('&#x022E2;', '&nsqsube;', '__ent_NOT_SQUARE_IMAGE_OF_OR_EQUAL_TO'),
('&#x022E3;', '&nsqsupe;', '__ent_NOT_SQUARE_ORIGINAL_OF_OR_EQUAL_TO'),
('&#x022E6;', '&lnsim;', '__ent_LESS_THAN_BUT_NOT_EQUIVALENT_TO'),
('&#x022E7;', '&gnsim;', '__ent_GREATER_THAN_BUT_NOT_EQUIVALENT_TO'),
('&#x022E8;', '&prnsim;', '__ent_PRECEDES_BUT_NOT_EQUIVALENT_TO'),
('&#x022E9;', '&scnsim;', '__ent_SUCCEEDS_BUT_NOT_EQUIVALENT_TO'),
('&#x022EA;', '&nltri;', '__ent_NOT_NORMAL_SUBGROUP_OF'),
('&#x022EB;', '&nrtri;', '__ent_DOES_NOT_CONTAIN_AS_NORMAL_SUBGROUP'),
('&#x022EC;', '&nltrie;', '__ent_NOT_NORMAL_SUBGROUP_OF_OR_EQUAL_TO'),
('&#x022ED;', '&nrtrie;', '__ent_DOES_NOT_CONTAIN_AS_NORMAL_SUBGROUP_OR_EQUAL'),
('&#x022EE;', '&vellip;', '__ent_VERTICAL_ELLIPSIS'),
('&#x022EF;', '&ctdot;', '__ent_MIDLINE_HORIZONTAL_ELLIPSIS'),
('&#x022F0;', '&utdot;', '__ent_UP_RIGHT_DIAGONAL_ELLIPSIS'),
('&#x022F1;', '&dtdot;', '__ent_DOWN_RIGHT_DIAGONAL_ELLIPSIS'),
('&#x022F2;', '&disin;', '__ent_ELEMENT_OF_WITH_LONG_HORIZONTAL_STROKE'),
('&#x022F3;', '&isinsv;', '__ent_ELEMENT_OF_WITH_VERTICAL_BAR_AT_END_OF_HORIZONTAL_STROKE'),
('&#x022F4;', '&isins;', '__ent_SMALL_ELEMENT_OF_WITH_VERTICAL_BAR_AT_END_OF_HORIZONTAL_STROKE'),
('&#x022F5;', '&isindot;', '__ent_ELEMENT_OF_WITH_DOT_ABOVE'),
('&#x022F6;', '&notinvc;', '__ent_ELEMENT_OF_WITH_OVERBAR'),
('&#x022F7;', '&notinvb;', '__ent_SMALL_ELEMENT_OF_WITH_OVERBAR'),
('&#x022F9;', '&isinE;', '__ent_ELEMENT_OF_WITH_TWO_HORIZONTAL_STROKES'),
('&#x022FA;', '&nisd;', '__ent_CONTAINS_WITH_LONG_HORIZONTAL_STROKE'),
('&#x022FB;', '&xnis;', '__ent_CONTAINS_WITH_VERTICAL_BAR_AT_END_OF_HORIZONTAL_STROKE'),
('&#x022FC;', '&nis;', '__ent_SMALL_CONTAINS_WITH_VERTICAL_BAR_AT_END_OF_HORIZONTAL_STROKE'),
('&#x022FD;', '&notnivc;', '__ent_CONTAINS_WITH_OVERBAR'),
('&#x022FE;', '&notnivb;', '__ent_SMALL_CONTAINS_WITH_OVERBAR'),
('&#x02305;', '&barwed;', '__ent_PROJECTIVE'),
('&#x02306;', '&Barwed;', '__ent_PERSPECTIVE'),
('&#x02308;', '&lceil;', '__ent_LEFT_CEILING'),
('&#x02309;', '&rceil;', '__ent_RIGHT_CEILING'),
('&#x0230A;', '&lfloor;', '__ent_LEFT_FLOOR'),
('&#x0230B;', '&rfloor;', '__ent_RIGHT_FLOOR'),
('&#x0230C;', '&drcrop;', '__ent_BOTTOM_RIGHT_CROP'),
('&#x0230D;', '&dlcrop;', '__ent_BOTTOM_LEFT_CROP'),
('&#x0230E;', '&urcrop;', '__ent_TOP_RIGHT_CROP'),
('&#x0230F;', '&ulcrop;', '__ent_TOP_LEFT_CROP'),
('&#x02310;', '&bnot;', '__ent_REVERSED_NOT_SIGN'),
('&#x02312;', '&profline;', '__ent_ARC'),
('&#x02313;', '&profsurf;', '__ent_SEGMENT'),
('&#x02315;', '&telrec;', '__ent_TELEPHONE_RECORDER'),
('&#x02316;', '&target;', '__ent_POSITION_INDICATOR'),
('&#x0231C;', '&ulcorn;', '__ent_TOP_LEFT_CORNER'),
('&#x0231D;', '&urcorn;', '__ent_TOP_RIGHT_CORNER'),
('&#x0231E;', '&dlcorn;', '__ent_BOTTOM_LEFT_CORNER'),
('&#x0231F;', '&drcorn;', '__ent_BOTTOM_RIGHT_CORNER'),
('&#x02322;', '&frown;', '__ent_FROWN'),
('&#x02323;', '&smile;', '__ent_SMILE'),
('&#x0232D;', '&cylcty;', '__ent_CYLINDRICITY'),
('&#x0232E;', '&profalar;', '__ent_ALL_AROUND_PROFILE'),
('&#x02336;', '&topbot;', '__ent_APL_FUNCTIONAL_SYMBOL_I_BEAM'),
('&#x0233D;', '&ovbar;', '__ent_APL_FUNCTIONAL_SYMBOL_CIRCLE_STILE'),
('&#x0233F;', '&solbar;', '__ent_APL_FUNCTIONAL_SYMBOL_SLASH_BAR'),
('&#x0237C;', '&angzarr;', '__ent_RIGHT_ANGLE_WITH_DOWNWARDS_ZIGZAG_ARROW'),
('&#x023B0;', '&lmoust;', '__ent_UPPER_LEFT_OR_LOWER_RIGHT_CURLY_BRACKET_SECTION'),
('&#x023B1;', '&rmoust;', '__ent_UPPER_RIGHT_OR_LOWER_LEFT_CURLY_BRACKET_SECTION'),
('&#x023B4;', '&tbrk;', '__ent_TOP_SQUARE_BRACKET'),
('&#x023B5;', '&bbrk;', '__ent_BOTTOM_SQUARE_BRACKET'),
('&#x023B6;', '&bbrktbrk;', '__ent_BOTTOM_SQUARE_BRACKET_OVER_TOP_SQUARE_BRACKET'),
('&#x023DC;', '&OverParenthesis;', '__ent_TOP_PARENTHESIS'),
('&#x023DD;', '&UnderParenthesis;', '__ent_BOTTOM_PARENTHESIS'),
('&#x023DE;', '&OverBrace;', '__ent_TOP_CURLY_BRACKET'),
('&#x023DF;', '&UnderBrace;', '__ent_BOTTOM_CURLY_BRACKET'),
('&#x023E2;', '&trpezium;', '__ent_WHITE_TRAPEZIUM'),
('&#x023E7;', '&elinters;', '__ent_ELECTRICAL_INTERSECTION'),
('&#x02423;', '&blank;', '__ent_OPEN_BOX'),
('&#x024C8;', '&oS;', '__ent_CIRCLED_LATIN_CAPITAL_LETTER_S'),
('&#x02500;', '&boxh;', '__ent_BOX_DRAWINGS_LIGHT_HORIZONTAL'),
('&#x02502;', '&boxv;', '__ent_BOX_DRAWINGS_LIGHT_VERTICAL'),
('&#x0250C;', '&boxdr;', '__ent_BOX_DRAWINGS_LIGHT_DOWN_AND_RIGHT'),
('&#x02510;', '&boxdl;', '__ent_BOX_DRAWINGS_LIGHT_DOWN_AND_LEFT'),
('&#x02514;', '&boxur;', '__ent_BOX_DRAWINGS_LIGHT_UP_AND_RIGHT'),
('&#x02518;', '&boxul;', '__ent_BOX_DRAWINGS_LIGHT_UP_AND_LEFT'),
('&#x0251C;', '&boxvr;', '__ent_BOX_DRAWINGS_LIGHT_VERTICAL_AND_RIGHT'),
('&#x02524;', '&boxvl;', '__ent_BOX_DRAWINGS_LIGHT_VERTICAL_AND_LEFT'),
('&#x0252C;', '&boxhd;', '__ent_BOX_DRAWINGS_LIGHT_DOWN_AND_HORIZONTAL'),
('&#x02534;', '&boxhu;', '__ent_BOX_DRAWINGS_LIGHT_UP_AND_HORIZONTAL'),
('&#x0253C;', '&boxvh;', '__ent_BOX_DRAWINGS_LIGHT_VERTICAL_AND_HORIZONTAL'),
('&#x02550;', '&boxH;', '__ent_BOX_DRAWINGS_DOUBLE_HORIZONTAL'),
('&#x02551;', '&boxV;', '__ent_BOX_DRAWINGS_DOUBLE_VERTICAL'),
('&#x02552;', '&boxdR;', '__ent_BOX_DRAWINGS_DOWN_SINGLE_AND_RIGHT_DOUBLE'),
('&#x02553;', '&boxDr;', '__ent_BOX_DRAWINGS_DOWN_DOUBLE_AND_RIGHT_SINGLE'),
('&#x02554;', '&boxDR;', '__ent_BOX_DRAWINGS_DOUBLE_DOWN_AND_RIGHT'),
('&#x02555;', '&boxdL;', '__ent_BOX_DRAWINGS_DOWN_SINGLE_AND_LEFT_DOUBLE'),
('&#x02556;', '&boxDl;', '__ent_BOX_DRAWINGS_DOWN_DOUBLE_AND_LEFT_SINGLE'),
('&#x02557;', '&boxDL;', '__ent_BOX_DRAWINGS_DOUBLE_DOWN_AND_LEFT'),
('&#x02558;', '&boxuR;', '__ent_BOX_DRAWINGS_UP_SINGLE_AND_RIGHT_DOUBLE'),
('&#x02559;', '&boxUr;', '__ent_BOX_DRAWINGS_UP_DOUBLE_AND_RIGHT_SINGLE'),
('&#x0255A;', '&boxUR;', '__ent_BOX_DRAWINGS_DOUBLE_UP_AND_RIGHT'),
('&#x0255B;', '&boxuL;', '__ent_BOX_DRAWINGS_UP_SINGLE_AND_LEFT_DOUBLE'),
('&#x0255C;', '&boxUl;', '__ent_BOX_DRAWINGS_UP_DOUBLE_AND_LEFT_SINGLE'),
('&#x0255D;', '&boxUL;', '__ent_BOX_DRAWINGS_DOUBLE_UP_AND_LEFT'),
('&#x0255E;', '&boxvR;', '__ent_BOX_DRAWINGS_VERTICAL_SINGLE_AND_RIGHT_DOUBLE'),
('&#x0255F;', '&boxVr;', '__ent_BOX_DRAWINGS_VERTICAL_DOUBLE_AND_RIGHT_SINGLE'),
('&#x02560;', '&boxVR;', '__ent_BOX_DRAWINGS_DOUBLE_VERTICAL_AND_RIGHT'),
('&#x02561;', '&boxvL;', '__ent_BOX_DRAWINGS_VERTICAL_SINGLE_AND_LEFT_DOUBLE'),
('&#x02562;', '&boxVl;', '__ent_BOX_DRAWINGS_VERTICAL_DOUBLE_AND_LEFT_SINGLE'),
('&#x02563;', '&boxVL;', '__ent_BOX_DRAWINGS_DOUBLE_VERTICAL_AND_LEFT'),
('&#x02564;', '&boxHd;', '__ent_BOX_DRAWINGS_DOWN_SINGLE_AND_HORIZONTAL_DOUBLE'),
('&#x02565;', '&boxhD;', '__ent_BOX_DRAWINGS_DOWN_DOUBLE_AND_HORIZONTAL_SINGLE'),
('&#x02566;', '&boxHD;', '__ent_BOX_DRAWINGS_DOUBLE_DOWN_AND_HORIZONTAL'),
('&#x02567;', '&boxHu;', '__ent_BOX_DRAWINGS_UP_SINGLE_AND_HORIZONTAL_DOUBLE'),
('&#x02568;', '&boxhU;', '__ent_BOX_DRAWINGS_UP_DOUBLE_AND_HORIZONTAL_SINGLE'),
('&#x02569;', '&boxHU;', '__ent_BOX_DRAWINGS_DOUBLE_UP_AND_HORIZONTAL'),
('&#x0256A;', '&boxvH;', '__ent_BOX_DRAWINGS_VERTICAL_SINGLE_AND_HORIZONTAL_DOUBLE'),
('&#x0256B;', '&boxVh;', '__ent_BOX_DRAWINGS_VERTICAL_DOUBLE_AND_HORIZONTAL_SINGLE'),
('&#x0256C;', '&boxVH;', '__ent_BOX_DRAWINGS_DOUBLE_VERTICAL_AND_HORIZONTAL'),
('&#x02580;', '&uhblk;', '__ent_UPPER_HALF_BLOCK'),
('&#x02584;', '&lhblk;', '__ent_LOWER_HALF_BLOCK'),
('&#x02588;', '&block;', '__ent_FULL_BLOCK'),
('&#x02591;', '&blk14;', '__ent_LIGHT_SHADE'),
('&#x02592;', '&blk12;', '__ent_MEDIUM_SHADE'),
('&#x02593;', '&blk34;', '__ent_DARK_SHADE'),
('&#x025A1;', '&squ;', '__ent_WHITE_SQUARE'),
('&#x025AA;', '&squf;', '__ent_BLACK_SMALL_SQUARE'),
('&#x025AB;', '&EmptyVerySmallSquare;', '__ent_WHITE_SMALL_SQUARE'),
('&#x025AD;', '&rect;', '__ent_WHITE_RECTANGLE'),
('&#x025AE;', '&marker;', '__ent_BLACK_VERTICAL_RECTANGLE'),
('&#x025B1;', '&fltns;', '__ent_WHITE_PARALLELOGRAM'),
('&#x025B3;', '&xutri;', '__ent_WHITE_UP_POINTING_TRIANGLE'),
('&#x025B4;', '&utrif;', '__ent_BLACK_UP_POINTING_SMALL_TRIANGLE'),
('&#x025B5;', '&utri;', '__ent_WHITE_UP_POINTING_SMALL_TRIANGLE'),
('&#x025B8;', '&rtrif;', '__ent_BLACK_RIGHT_POINTING_SMALL_TRIANGLE'),
('&#x025B9;', '&rtri;', '__ent_WHITE_RIGHT_POINTING_SMALL_TRIANGLE'),
('&#x025BD;', '&xdtri;', '__ent_WHITE_DOWN_POINTING_TRIANGLE'),
('&#x025BE;', '&dtrif;', '__ent_BLACK_DOWN_POINTING_SMALL_TRIANGLE'),
('&#x025BF;', '&dtri;', '__ent_WHITE_DOWN_POINTING_SMALL_TRIANGLE'),
('&#x025C2;', '&ltrif;', '__ent_BLACK_LEFT_POINTING_SMALL_TRIANGLE'),
('&#x025C3;', '&ltri;', '__ent_WHITE_LEFT_POINTING_SMALL_TRIANGLE'),
('&#x025CA;', '&loz;', '__ent_LOZENGE'),
('&#x025CB;', '&cir;', '__ent_WHITE_CIRCLE'),
('&#x025EC;', '&tridot;', '__ent_WHITE_UP_POINTING_TRIANGLE_WITH_DOT'),
('&#x025EF;', '&xcirc;', '__ent_LARGE_CIRCLE'),
('&#x025F8;', '&ultri;', '__ent_UPPER_LEFT_TRIANGLE'),
('&#x025F9;', '&urtri;', '__ent_UPPER_RIGHT_TRIANGLE'),
('&#x025FA;', '&lltri;', '__ent_LOWER_LEFT_TRIANGLE'),
('&#x025FB;', '&EmptySmallSquare;', '__ent_WHITE_MEDIUM_SQUARE'),
('&#x025FC;', '&FilledSmallSquare;', '__ent_BLACK_MEDIUM_SQUARE'),
('&#x02605;', '&starf;', '__ent_BLACK_STAR'),
('&#x02606;', '&star;', '__ent_WHITE_STAR'),
('&#x0260E;', '&phone;', '__ent_BLACK_TELEPHONE'),
('&#x02640;', '&female;', '__ent_FEMALE_SIGN'),
('&#x02642;', '&male;', '__ent_MALE_SIGN'),
('&#x02660;', '&spades;', '__ent_BLACK_SPADE_SUIT'),
('&#x02663;', '&clubs;', '__ent_BLACK_CLUB_SUIT'),
('&#x02665;', '&hearts;', '__ent_BLACK_HEART_SUIT'),
('&#x02666;', '&diams;', '__ent_BLACK_DIAMOND_SUIT'),
('&#x0266A;', '&sung;', '__ent_EIGHTH_NOTE'),
('&#x0266D;', '&flat;', '__ent_MUSIC_FLAT_SIGN'),
('&#x0266E;', '&natur;', '__ent_MUSIC_NATURAL_SIGN'),
('&#x0266F;', '&sharp;', '__ent_MUSIC_SHARP_SIGN'),
('&#x02713;', '&check;', '__ent_CHECK_MARK'),
('&#x02717;', '&cross;', '__ent_BALLOT_X'),
('&#x02720;', '&malt;', '__ent_MALTESE_CROSS'),
('&#x02736;', '&sext;', '__ent_SIX_POINTED_BLACK_STAR'),
('&#x02758;', '&VerticalSeparator;', '__ent_LIGHT_VERTICAL_BAR'),
('&#x02772;', '&lbbrk;', '__ent_LIGHT_LEFT_TORTOISE_SHELL_BRACKET_ORNAMENT'),
('&#x02773;', '&rbbrk;', '__ent_LIGHT_RIGHT_TORTOISE_SHELL_BRACKET_ORNAMENT'),
('&#x027E6;', '&lobrk;', '__ent_MATHEMATICAL_LEFT_WHITE_SQUARE_BRACKET'),
('&#x027E7;', '&robrk;', '__ent_MATHEMATICAL_RIGHT_WHITE_SQUARE_BRACKET'),
('&#x027E8;', '&lang;', '__ent_MATHEMATICAL_LEFT_ANGLE_BRACKET'),
('&#x027E9;', '&rang;', '__ent_MATHEMATICAL_RIGHT_ANGLE_BRACKET'),
('&#x027EA;', '&Lang;', '__ent_MATHEMATICAL_LEFT_DOUBLE_ANGLE_BRACKET'),
('&#x027EB;', '&Rang;', '__ent_MATHEMATICAL_RIGHT_DOUBLE_ANGLE_BRACKET'),
('&#x027EC;', '&loang;', '__ent_MATHEMATICAL_LEFT_WHITE_TORTOISE_SHELL_BRACKET'),
('&#x027ED;', '&roang;', '__ent_MATHEMATICAL_RIGHT_WHITE_TORTOISE_SHELL_BRACKET'),
('&#x027F5;', '&xlarr;', '__ent_LONG_LEFTWARDS_ARROW'),
('&#x027F6;', '&xrarr;', '__ent_LONG_RIGHTWARDS_ARROW'),
('&#x027F7;', '&xharr;', '__ent_LONG_LEFT_RIGHT_ARROW'),
('&#x027F8;', '&xlArr;', '__ent_LONG_LEFTWARDS_DOUBLE_ARROW'),
('&#x027F9;', '&xrArr;', '__ent_LONG_RIGHTWARDS_DOUBLE_ARROW'),
('&#x027FA;', '&xhArr;', '__ent_LONG_LEFT_RIGHT_DOUBLE_ARROW'),
('&#x027FC;', '&xmap;', '__ent_LONG_RIGHTWARDS_ARROW_FROM_BAR'),
('&#x027FF;', '&dzigrarr;', '__ent_LONG_RIGHTWARDS_SQUIGGLE_ARROW'),
('&#x02902;', '&nvlArr;', '__ent_LEFTWARDS_DOUBLE_ARROW_WITH_VERTICAL_STROKE'),
('&#x02903;', '&nvrArr;', '__ent_RIGHTWARDS_DOUBLE_ARROW_WITH_VERTICAL_STROKE'),
('&#x02904;', '&nvHarr;', '__ent_LEFT_RIGHT_DOUBLE_ARROW_WITH_VERTICAL_STROKE'),
('&#x02905;', '&Map;', '__ent_RIGHTWARDS_TWO_HEADED_ARROW_FROM_BAR'),
('&#x0290C;', '&lbarr;', '__ent_LEFTWARDS_DOUBLE_DASH_ARROW'),
('&#x0290D;', '&rbarr;', '__ent_RIGHTWARDS_DOUBLE_DASH_ARROW'),
('&#x0290E;', '&lBarr;', '__ent_LEFTWARDS_TRIPLE_DASH_ARROW'),
('&#x0290F;', '&rBarr;', '__ent_RIGHTWARDS_TRIPLE_DASH_ARROW'),
('&#x02910;', '&RBarr;', '__ent_RIGHTWARDS_TWO_HEADED_TRIPLE_DASH_ARROW'),
('&#x02911;', '&DDotrahd;', '__ent_RIGHTWARDS_ARROW_WITH_DOTTED_STEM'),
('&#x02912;', '&UpArrowBar;', '__ent_UPWARDS_ARROW_TO_BAR'),
('&#x02913;', '&DownArrowBar;', '__ent_DOWNWARDS_ARROW_TO_BAR'),
('&#x02916;', '&Rarrtl;', '__ent_RIGHTWARDS_TWO_HEADED_ARROW_WITH_TAIL'),
('&#x02919;', '&latail;', '__ent_LEFTWARDS_ARROW_TAIL'),
('&#x0291A;', '&ratail;', '__ent_RIGHTWARDS_ARROW_TAIL'),
('&#x0291B;', '&lAtail;', '__ent_LEFTWARDS_DOUBLE_ARROW_TAIL'),
('&#x0291C;', '&rAtail;', '__ent_RIGHTWARDS_DOUBLE_ARROW_TAIL'),
('&#x0291D;', '&larrfs;', '__ent_LEFTWARDS_ARROW_TO_BLACK_DIAMOND'),
('&#x0291E;', '&rarrfs;', '__ent_RIGHTWARDS_ARROW_TO_BLACK_DIAMOND'),
('&#x0291F;', '&larrbfs;', '__ent_LEFTWARDS_ARROW_FROM_BAR_TO_BLACK_DIAMOND'),
('&#x02920;', '&rarrbfs;', '__ent_RIGHTWARDS_ARROW_FROM_BAR_TO_BLACK_DIAMOND'),
('&#x02923;', '&nwarhk;', '__ent_NORTH_WEST_ARROW_WITH_HOOK'),
('&#x02924;', '&nearhk;', '__ent_NORTH_EAST_ARROW_WITH_HOOK'),
('&#x02925;', '&searhk;', '__ent_SOUTH_EAST_ARROW_WITH_HOOK'),
('&#x02926;', '&swarhk;', '__ent_SOUTH_WEST_ARROW_WITH_HOOK'),
('&#x02927;', '&nwnear;', '__ent_NORTH_WEST_ARROW_AND_NORTH_EAST_ARROW'),
('&#x02928;', '&nesear;', '__ent_NORTH_EAST_ARROW_AND_SOUTH_EAST_ARROW'),
('&#x02929;', '&seswar;', '__ent_SOUTH_EAST_ARROW_AND_SOUTH_WEST_ARROW'),
('&#x0292A;', '&swnwar;', '__ent_SOUTH_WEST_ARROW_AND_NORTH_WEST_ARROW'),
('&#x02933;', '&rarrc;', '__ent_WAVE_ARROW_POINTING_DIRECTLY_RIGHT'),
('&#x02935;', '&cudarrr;', '__ent_ARROW_POINTING_RIGHTWARDS_THEN_CURVING_DOWNWARDS'),
('&#x02936;', '&ldca;', '__ent_ARROW_POINTING_DOWNWARDS_THEN_CURVING_LEFTWARDS'),
('&#x02937;', '&rdca;', '__ent_ARROW_POINTING_DOWNWARDS_THEN_CURVING_RIGHTWARDS'),
('&#x02938;', '&cudarrl;', '__ent_RIGHT_SIDE_ARC_CLOCKWISE_ARROW'),
('&#x02939;', '&larrpl;', '__ent_LEFT_SIDE_ARC_ANTICLOCKWISE_ARROW'),
('&#x0293C;', '&curarrm;', '__ent_TOP_ARC_CLOCKWISE_ARROW_WITH_MINUS'),
('&#x0293D;', '&cularrp;', '__ent_TOP_ARC_ANTICLOCKWISE_ARROW_WITH_PLUS'),
('&#x02945;', '&rarrpl;', '__ent_RIGHTWARDS_ARROW_WITH_PLUS_BELOW'),
('&#x02948;', '&harrcir;', '__ent_LEFT_RIGHT_ARROW_THROUGH_SMALL_CIRCLE'),
('&#x02949;', '&Uarrocir;', '__ent_UPWARDS_TWO_HEADED_ARROW_FROM_SMALL_CIRCLE'),
('&#x0294A;', '&lurdshar;', '__ent_LEFT_BARB_UP_RIGHT_BARB_DOWN_HARPOON'),
('&#x0294B;', '&ldrushar;', '__ent_LEFT_BARB_DOWN_RIGHT_BARB_UP_HARPOON'),
('&#x0294E;', '&LeftRightVector;', '__ent_LEFT_BARB_UP_RIGHT_BARB_UP_HARPOON'),
('&#x0294F;', '&RightUpDownVector;', '__ent_UP_BARB_RIGHT_DOWN_BARB_RIGHT_HARPOON'),
('&#x02950;', '&DownLeftRightVector;', '__ent_LEFT_BARB_DOWN_RIGHT_BARB_DOWN_HARPOON'),
('&#x02951;', '&LeftUpDownVector;', '__ent_UP_BARB_LEFT_DOWN_BARB_LEFT_HARPOON'),
('&#x02952;', '&LeftVectorBar;', '__ent_LEFTWARDS_HARPOON_WITH_BARB_UP_TO_BAR'),
('&#x02953;', '&RightVectorBar;', '__ent_RIGHTWARDS_HARPOON_WITH_BARB_UP_TO_BAR'),
('&#x02954;', '&RightUpVectorBar;', '__ent_UPWARDS_HARPOON_WITH_BARB_RIGHT_TO_BAR'),
('&#x02955;', '&RightDownVectorBar;', '__ent_DOWNWARDS_HARPOON_WITH_BARB_RIGHT_TO_BAR'),
('&#x02956;', '&DownLeftVectorBar;', '__ent_LEFTWARDS_HARPOON_WITH_BARB_DOWN_TO_BAR'),
('&#x02957;', '&DownRightVectorBar;', '__ent_RIGHTWARDS_HARPOON_WITH_BARB_DOWN_TO_BAR'),
('&#x02958;', '&LeftUpVectorBar;', '__ent_UPWARDS_HARPOON_WITH_BARB_LEFT_TO_BAR'),
('&#x02959;', '&LeftDownVectorBar;', '__ent_DOWNWARDS_HARPOON_WITH_BARB_LEFT_TO_BAR'),
('&#x0295A;', '&LeftTeeVector;', '__ent_LEFTWARDS_HARPOON_WITH_BARB_UP_FROM_BAR'),
('&#x0295B;', '&RightTeeVector;', '__ent_RIGHTWARDS_HARPOON_WITH_BARB_UP_FROM_BAR'),
('&#x0295C;', '&RightUpTeeVector;', '__ent_UPWARDS_HARPOON_WITH_BARB_RIGHT_FROM_BAR'),
('&#x0295D;', '&RightDownTeeVector;', '__ent_DOWNWARDS_HARPOON_WITH_BARB_RIGHT_FROM_BAR'),
('&#x0295E;', '&DownLeftTeeVector;', '__ent_LEFTWARDS_HARPOON_WITH_BARB_DOWN_FROM_BAR'),
('&#x0295F;', '&DownRightTeeVector;', '__ent_RIGHTWARDS_HARPOON_WITH_BARB_DOWN_FROM_BAR'),
('&#x02960;', '&LeftUpTeeVector;', '__ent_UPWARDS_HARPOON_WITH_BARB_LEFT_FROM_BAR'),
('&#x02961;', '&LeftDownTeeVector;', '__ent_DOWNWARDS_HARPOON_WITH_BARB_LEFT_FROM_BAR'),
('&#x02962;', '&lHar;', '__ent_LEFTWARDS_HARPOON_WITH_BARB_UP_ABOVE_LEFTWARDS_HARPOON_WITH_BARB_DOWN'),
('&#x02963;', '&uHar;', '__ent_UPWARDS_HARPOON_WITH_BARB_LEFT_BESIDE_UPWARDS_HARPOON_WITH_BARB_RIGHT'),
('&#x02964;', '&rHar;', '__ent_RIGHTWARDS_HARPOON_WITH_BARB_UP_ABOVE_RIGHTWARDS_HARPOON_WITH_BARB_DOWN'),
('&#x02965;', '&dHar;', '__ent_DOWNWARDS_HARPOON_WITH_BARB_LEFT_BESIDE_DOWNWARDS_HARPOON_WITH_BARB_RIGHT'),
('&#x02966;', '&luruhar;', '__ent_LEFTWARDS_HARPOON_WITH_BARB_UP_ABOVE_RIGHTWARDS_HARPOON_WITH_BARB_UP'),
('&#x02967;', '&ldrdhar;', '__ent_LEFTWARDS_HARPOON_WITH_BARB_DOWN_ABOVE_RIGHTWARDS_HARPOON_WITH_BARB_DOWN'),
('&#x02968;', '&ruluhar;', '__ent_RIGHTWARDS_HARPOON_WITH_BARB_UP_ABOVE_LEFTWARDS_HARPOON_WITH_BARB_UP'),
('&#x02969;', '&rdldhar;', '__ent_RIGHTWARDS_HARPOON_WITH_BARB_DOWN_ABOVE_LEFTWARDS_HARPOON_WITH_BARB_DOWN'),
('&#x0296A;', '&lharul;', '__ent_LEFTWARDS_HARPOON_WITH_BARB_UP_ABOVE_LONG_DASH'),
('&#x0296B;', '&llhard;', '__ent_LEFTWARDS_HARPOON_WITH_BARB_DOWN_BELOW_LONG_DASH'),
('&#x0296C;', '&rharul;', '__ent_RIGHTWARDS_HARPOON_WITH_BARB_UP_ABOVE_LONG_DASH'),
('&#x0296D;', '&lrhard;', '__ent_RIGHTWARDS_HARPOON_WITH_BARB_DOWN_BELOW_LONG_DASH'),
('&#x0296E;', '&udhar;', '__ent_UPWARDS_HARPOON_WITH_BARB_LEFT_BESIDE_DOWNWARDS_HARPOON_WITH_BARB_RIGHT'),
('&#x0296F;', '&duhar;', '__ent_DOWNWARDS_HARPOON_WITH_BARB_LEFT_BESIDE_UPWARDS_HARPOON_WITH_BARB_RIGHT'),
('&#x02970;', '&RoundImplies;', '__ent_RIGHT_DOUBLE_ARROW_WITH_ROUNDED_HEAD'),
('&#x02971;', '&erarr;', '__ent_EQUALS_SIGN_ABOVE_RIGHTWARDS_ARROW'),
('&#x02972;', '&simrarr;', '__ent_TILDE_OPERATOR_ABOVE_RIGHTWARDS_ARROW'),
('&#x02973;', '&larrsim;', '__ent_LEFTWARDS_ARROW_ABOVE_TILDE_OPERATOR'),
('&#x02974;', '&rarrsim;', '__ent_RIGHTWARDS_ARROW_ABOVE_TILDE_OPERATOR'),
('&#x02975;', '&rarrap;', '__ent_RIGHTWARDS_ARROW_ABOVE_ALMOST_EQUAL_TO'),
('&#x02976;', '&ltlarr;', '__ent_LESS_THAN_ABOVE_LEFTWARDS_ARROW'),
('&#x02978;', '&gtrarr;', '__ent_GREATER_THAN_ABOVE_RIGHTWARDS_ARROW'),
('&#x02979;', '&subrarr;', '__ent_SUBSET_ABOVE_RIGHTWARDS_ARROW'),
('&#x0297B;', '&suplarr;', '__ent_SUPERSET_ABOVE_LEFTWARDS_ARROW'),
('&#x0297C;', '&lfisht;', '__ent_LEFT_FISH_TAIL'),
('&#x0297D;', '&rfisht;', '__ent_RIGHT_FISH_TAIL'),
('&#x0297E;', '&ufisht;', '__ent_UP_FISH_TAIL'),
('&#x0297F;', '&dfisht;', '__ent_DOWN_FISH_TAIL'),
('&#x02985;', '&lopar;', '__ent_LEFT_WHITE_PARENTHESIS'),
('&#x02986;', '&ropar;', '__ent_RIGHT_WHITE_PARENTHESIS'),
('&#x0298B;', '&lbrke;', '__ent_LEFT_SQUARE_BRACKET_WITH_UNDERBAR'),
('&#x0298C;', '&rbrke;', '__ent_RIGHT_SQUARE_BRACKET_WITH_UNDERBAR'),
('&#x0298D;', '&lbrkslu;', '__ent_LEFT_SQUARE_BRACKET_WITH_TICK_IN_TOP_CORNER'),
('&#x0298E;', '&rbrksld;', '__ent_RIGHT_SQUARE_BRACKET_WITH_TICK_IN_BOTTOM_CORNER'),
('&#x0298F;', '&lbrksld;', '__ent_LEFT_SQUARE_BRACKET_WITH_TICK_IN_BOTTOM_CORNER'),
('&#x02990;', '&rbrkslu;', '__ent_RIGHT_SQUARE_BRACKET_WITH_TICK_IN_TOP_CORNER'),
('&#x02991;', '&langd;', '__ent_LEFT_ANGLE_BRACKET_WITH_DOT'),
('&#x02992;', '&rangd;', '__ent_RIGHT_ANGLE_BRACKET_WITH_DOT'),
('&#x02993;', '&lparlt;', '__ent_LEFT_ARC_LESS_THAN_BRACKET'),
('&#x02994;', '&rpargt;', '__ent_RIGHT_ARC_GREATER_THAN_BRACKET'),
('&#x02995;', '&gtlPar;', '__ent_DOUBLE_LEFT_ARC_GREATER_THAN_BRACKET'),
('&#x02996;', '&ltrPar;', '__ent_DOUBLE_RIGHT_ARC_LESS_THAN_BRACKET'),
('&#x0299A;', '&vzigzag;', '__ent_VERTICAL_ZIGZAG_LINE'),
('&#x0299C;', '&vangrt;', '__ent_RIGHT_ANGLE_VARIANT_WITH_SQUARE'),
('&#x0299D;', '&angrtvbd;', '__ent_MEASURED_RIGHT_ANGLE_WITH_DOT'),
('&#x029A4;', '&ange;', '__ent_ANGLE_WITH_UNDERBAR'),
('&#x029A5;', '&range;', '__ent_REVERSED_ANGLE_WITH_UNDERBAR'),
('&#x029A6;', '&dwangle;', '__ent_OBLIQUE_ANGLE_OPENING_UP'),
('&#x029A7;', '&uwangle;', '__ent_OBLIQUE_ANGLE_OPENING_DOWN'),
('&#x029A8;', '&angmsdaa;', '__ent_MEASURED_ANGLE_WITH_OPEN_ARM_ENDING_IN_ARROW_POINTING_UP_AND_RIGHT'),
('&#x029A9;', '&angmsdab;', '__ent_MEASURED_ANGLE_WITH_OPEN_ARM_ENDING_IN_ARROW_POINTING_UP_AND_LEFT'),
('&#x029AA;', '&angmsdac;', '__ent_MEASURED_ANGLE_WITH_OPEN_ARM_ENDING_IN_ARROW_POINTING_DOWN_AND_RIGHT'),
('&#x029AB;', '&angmsdad;', '__ent_MEASURED_ANGLE_WITH_OPEN_ARM_ENDING_IN_ARROW_POINTING_DOWN_AND_LEFT'),
('&#x029AC;', '&angmsdae;', '__ent_MEASURED_ANGLE_WITH_OPEN_ARM_ENDING_IN_ARROW_POINTING_RIGHT_AND_UP'),
('&#x029AD;', '&angmsdaf;', '__ent_MEASURED_ANGLE_WITH_OPEN_ARM_ENDING_IN_ARROW_POINTING_LEFT_AND_UP'),
('&#x029AE;', '&angmsdag;', '__ent_MEASURED_ANGLE_WITH_OPEN_ARM_ENDING_IN_ARROW_POINTING_RIGHT_AND_DOWN'),
('&#x029AF;', '&angmsdah;', '__ent_MEASURED_ANGLE_WITH_OPEN_ARM_ENDING_IN_ARROW_POINTING_LEFT_AND_DOWN'),
('&#x029B0;', '&bemptyv;', '__ent_REVERSED_EMPTY_SET'),
('&#x029B1;', '&demptyv;', '__ent_EMPTY_SET_WITH_OVERBAR'),
('&#x029B2;', '&cemptyv;', '__ent_EMPTY_SET_WITH_SMALL_CIRCLE_ABOVE'),
('&#x029B3;', '&raemptyv;', '__ent_EMPTY_SET_WITH_RIGHT_ARROW_ABOVE'),
('&#x029B4;', '&laemptyv;', '__ent_EMPTY_SET_WITH_LEFT_ARROW_ABOVE'),
('&#x029B5;', '&ohbar;', '__ent_CIRCLE_WITH_HORIZONTAL_BAR'),
('&#x029B6;', '&omid;', '__ent_CIRCLED_VERTICAL_BAR'),
('&#x029B7;', '&opar;', '__ent_CIRCLED_PARALLEL'),
('&#x029B9;', '&operp;', '__ent_CIRCLED_PERPENDICULAR'),
('&#x029BB;', '&olcross;', '__ent_CIRCLE_WITH_SUPERIMPOSED_X'),
('&#x029BC;', '&odsold;', '__ent_CIRCLED_ANTICLOCKWISE_ROTATED_DIVISION_SIGN'),
('&#x029BE;', '&olcir;', '__ent_CIRCLED_WHITE_BULLET'),
('&#x029BF;', '&ofcir;', '__ent_CIRCLED_BULLET'),
('&#x029C0;', '&olt;', '__ent_CIRCLED_LESS_THAN'),
('&#x029C1;', '&ogt;', '__ent_CIRCLED_GREATER_THAN'),
('&#x029C2;', '&cirscir;', '__ent_CIRCLE_WITH_SMALL_CIRCLE_TO_THE_RIGHT'),
('&#x029C3;', '&cirE;', '__ent_CIRCLE_WITH_TWO_HORIZONTAL_STROKES_TO_THE_RIGHT'),
('&#x029C4;', '&solb;', '__ent_SQUARED_RISING_DIAGONAL_SLASH'),
('&#x029C5;', '&bsolb;', '__ent_SQUARED_FALLING_DIAGONAL_SLASH'),
('&#x029C9;', '&boxbox;', '__ent_TWO_JOINED_SQUARES'),
('&#x029CD;', '&trisb;', '__ent_TRIANGLE_WITH_SERIFS_AT_BOTTOM'),
('&#x029CE;', '&rtriltri;', '__ent_RIGHT_TRIANGLE_ABOVE_LEFT_TRIANGLE'),
('&#x029CF;', '&LeftTriangleBar;', '__ent_LEFT_TRIANGLE_BESIDE_VERTICAL_BAR'),
('&#x029D0;', '&RightTriangleBar;', '__ent_VERTICAL_BAR_BESIDE_RIGHT_TRIANGLE'),
('&#x029DA;', '&race;', '__ent_LEFT_DOUBLE_WIGGLY_FENCE'),
('&#x029DC;', '&iinfin;', '__ent_INCOMPLETE_INFINITY'),
('&#x029DD;', '&infintie;', '__ent_TIE_OVER_INFINITY'),
('&#x029DE;', '&nvinfin;', '__ent_INFINITY_NEGATED_WITH_VERTICAL_BAR'),
('&#x029E3;', '&eparsl;', '__ent_EQUALS_SIGN_AND_SLANTED_PARALLEL'),
('&#x029E4;', '&smeparsl;', '__ent_EQUALS_SIGN_AND_SLANTED_PARALLEL_WITH_TILDE_ABOVE'),
('&#x029E5;', '&eqvparsl;', '__ent_IDENTICAL_TO_AND_SLANTED_PARALLEL'),
('&#x029EB;', '&lozf;', '__ent_BLACK_LOZENGE'),
('&#x029F4;', '&RuleDelayed;', '__ent_RULE_DELAYED'),
('&#x029F6;', '&dsol;', '__ent_SOLIDUS_WITH_OVERBAR'),
('&#x02A00;', '&xodot;', '__ent_N_ARY_CIRCLED_DOT_OPERATOR'),
('&#x02A01;', '&xoplus;', '__ent_N_ARY_CIRCLED_PLUS_OPERATOR'),
('&#x02A02;', '&xotime;', '__ent_N_ARY_CIRCLED_TIMES_OPERATOR'),
('&#x02A04;', '&xuplus;', '__ent_N_ARY_UNION_OPERATOR_WITH_PLUS'),
('&#x02A06;', '&xsqcup;', '__ent_N_ARY_SQUARE_UNION_OPERATOR'),
('&#x02A0C;', '&qint;', '__ent_QUADRUPLE_INTEGRAL_OPERATOR'),
('&#x02A0D;', '&fpartint;', '__ent_FINITE_PART_INTEGRAL'),
('&#x02A10;', '&cirfnint;', '__ent_CIRCULATION_FUNCTION'),
('&#x02A11;', '&awint;', '__ent_ANTICLOCKWISE_INTEGRATION'),
('&#x02A12;', '&rppolint;', '__ent_LINE_INTEGRATION_WITH_RECTANGULAR_PATH_AROUND_POLE'),
('&#x02A13;', '&scpolint;', '__ent_LINE_INTEGRATION_WITH_SEMICIRCULAR_PATH_AROUND_POLE'),
('&#x02A14;', '&npolint;', '__ent_LINE_INTEGRATION_NOT_INCLUDING_THE_POLE'),
('&#x02A15;', '&pointint;', '__ent_INTEGRAL_AROUND_A_POINT_OPERATOR'),
('&#x02A16;', '&quatint;', '__ent_QUATERNION_INTEGRAL_OPERATOR'),
('&#x02A17;', '&intlarhk;', '__ent_INTEGRAL_WITH_LEFTWARDS_ARROW_WITH_HOOK'),
('&#x02A22;', '&pluscir;', '__ent_PLUS_SIGN_WITH_SMALL_CIRCLE_ABOVE'),
('&#x02A23;', '&plusacir;', '__ent_PLUS_SIGN_WITH_CIRCUMFLEX_ACCENT_ABOVE'),
('&#x02A24;', '&simplus;', '__ent_PLUS_SIGN_WITH_TILDE_ABOVE'),
('&#x02A25;', '&plusdu;', '__ent_PLUS_SIGN_WITH_DOT_BELOW'),
('&#x02A26;', '&plussim;', '__ent_PLUS_SIGN_WITH_TILDE_BELOW'),
('&#x02A27;', '&plustwo;', '__ent_PLUS_SIGN_WITH_SUBSCRIPT_TWO'),
('&#x02A29;', '&mcomma;', '__ent_MINUS_SIGN_WITH_COMMA_ABOVE'),
('&#x02A2A;', '&minusdu;', '__ent_MINUS_SIGN_WITH_DOT_BELOW'),
('&#x02A2D;', '&loplus;', '__ent_PLUS_SIGN_IN_LEFT_HALF_CIRCLE'),
('&#x02A2E;', '&roplus;', '__ent_PLUS_SIGN_IN_RIGHT_HALF_CIRCLE'),
('&#x02A2F;', '&Cross;', '__ent_VECTOR_OR_CROSS_PRODUCT'),
('&#x02A30;', '&timesd;', '__ent_MULTIPLICATION_SIGN_WITH_DOT_ABOVE'),
('&#x02A31;', '&timesbar;', '__ent_MULTIPLICATION_SIGN_WITH_UNDERBAR'),
('&#x02A33;', '&smashp;', '__ent_SMASH_PRODUCT'),
('&#x02A34;', '&lotimes;', '__ent_MULTIPLICATION_SIGN_IN_LEFT_HALF_CIRCLE'),
('&#x02A35;', '&rotimes;', '__ent_MULTIPLICATION_SIGN_IN_RIGHT_HALF_CIRCLE'),
('&#x02A36;', '&otimesas;', '__ent_CIRCLED_MULTIPLICATION_SIGN_WITH_CIRCUMFLEX_ACCENT'),
('&#x02A37;', '&Otimes;', '__ent_MULTIPLICATION_SIGN_IN_DOUBLE_CIRCLE'),
('&#x02A38;', '&odiv;', '__ent_CIRCLED_DIVISION_SIGN'),
('&#x02A39;', '&triplus;', '__ent_PLUS_SIGN_IN_TRIANGLE'),
('&#x02A3A;', '&triminus;', '__ent_MINUS_SIGN_IN_TRIANGLE'),
('&#x02A3B;', '&tritime;', '__ent_MULTIPLICATION_SIGN_IN_TRIANGLE'),
('&#x02A3C;', '&iprod;', '__ent_INTERIOR_PRODUCT'),
('&#x02A3F;', '&amalg;', '__ent_AMALGAMATION_OR_COPRODUCT'),
('&#x02A40;', '&capdot;', '__ent_INTERSECTION_WITH_DOT'),
('&#x02A42;', '&ncup;', '__ent_UNION_WITH_OVERBAR'),
('&#x02A43;', '&ncap;', '__ent_INTERSECTION_WITH_OVERBAR'),
('&#x02A44;', '&capand;', '__ent_INTERSECTION_WITH_LOGICAL_AND'),
('&#x02A45;', '&cupor;', '__ent_UNION_WITH_LOGICAL_OR'),
('&#x02A46;', '&cupcap;', '__ent_UNION_ABOVE_INTERSECTION'),
('&#x02A47;', '&capcup;', '__ent_INTERSECTION_ABOVE_UNION'),
('&#x02A48;', '&cupbrcap;', '__ent_UNION_ABOVE_BAR_ABOVE_INTERSECTION'),
('&#x02A49;', '&capbrcup;', '__ent_INTERSECTION_ABOVE_BAR_ABOVE_UNION'),
('&#x02A4A;', '&cupcup;', '__ent_UNION_BESIDE_AND_JOINED_WITH_UNION'),
('&#x02A4B;', '&capcap;', '__ent_INTERSECTION_BESIDE_AND_JOINED_WITH_INTERSECTION'),
('&#x02A4C;', '&ccups;', '__ent_CLOSED_UNION_WITH_SERIFS'),
('&#x02A4D;', '&ccaps;', '__ent_CLOSED_INTERSECTION_WITH_SERIFS'),
('&#x02A50;', '&ccupssm;', '__ent_CLOSED_UNION_WITH_SERIFS_AND_SMASH_PRODUCT'),
('&#x02A53;', '&And;', '__ent_DOUBLE_LOGICAL_AND'),
('&#x02A54;', '&Or;', '__ent_DOUBLE_LOGICAL_OR'),
('&#x02A55;', '&andand;', '__ent_TWO_INTERSECTING_LOGICAL_AND'),
('&#x02A56;', '&oror;', '__ent_TWO_INTERSECTING_LOGICAL_OR'),
('&#x02A57;', '&orslope;', '__ent_SLOPING_LARGE_OR'),
('&#x02A58;', '&andslope;', '__ent_SLOPING_LARGE_AND'),
('&#x02A5A;', '&andv;', '__ent_LOGICAL_AND_WITH_MIDDLE_STEM'),
('&#x02A5B;', '&orv;', '__ent_LOGICAL_OR_WITH_MIDDLE_STEM'),
('&#x02A5C;', '&andd;', '__ent_LOGICAL_AND_WITH_HORIZONTAL_DASH'),
('&#x02A5D;', '&ord;', '__ent_LOGICAL_OR_WITH_HORIZONTAL_DASH'),
('&#x02A5F;', '&wedbar;', '__ent_LOGICAL_AND_WITH_UNDERBAR'),
('&#x02A66;', '&sdote;', '__ent_EQUALS_SIGN_WITH_DOT_BELOW'),
('&#x02A6A;', '&simdot;', '__ent_TILDE_OPERATOR_WITH_DOT_ABOVE'),
('&#x02A6D;', '&congdot;', '__ent_CONGRUENT_WITH_DOT_ABOVE'),
('&#x02A6E;', '&easter;', '__ent_EQUALS_WITH_ASTERISK'),
('&#x02A6F;', '&apacir;', '__ent_ALMOST_EQUAL_TO_WITH_CIRCUMFLEX_ACCENT'),
('&#x02A70;', '&apE;', '__ent_APPROXIMATELY_EQUAL_OR_EQUAL_TO'),
('&#x02A71;', '&eplus;', '__ent_EQUALS_SIGN_ABOVE_PLUS_SIGN'),
('&#x02A72;', '&pluse;', '__ent_PLUS_SIGN_ABOVE_EQUALS_SIGN'),
('&#x02A73;', '&Esim;', '__ent_EQUALS_SIGN_ABOVE_TILDE_OPERATOR'),
('&#x02A74;', '&Colone;', '__ent_DOUBLE_COLON_EQUAL'),
('&#x02A75;', '&Equal;', '__ent_TWO_CONSECUTIVE_EQUALS_SIGNS'),
('&#x02A77;', '&eDDot;', '__ent_EQUALS_SIGN_WITH_TWO_DOTS_ABOVE_AND_TWO_DOTS_BELOW'),
('&#x02A78;', '&equivDD;', '__ent_EQUIVALENT_WITH_FOUR_DOTS_ABOVE'),
('&#x02A79;', '&ltcir;', '__ent_LESS_THAN_WITH_CIRCLE_INSIDE'),
('&#x02A7A;', '&gtcir;', '__ent_GREATER_THAN_WITH_CIRCLE_INSIDE'),
('&#x02A7B;', '&ltquest;', '__ent_LESS_THAN_WITH_QUESTION_MARK_ABOVE'),
('&#x02A7C;', '&gtquest;', '__ent_GREATER_THAN_WITH_QUESTION_MARK_ABOVE'),
('&#x02A7D;', '&les;', '__ent_LESS_THAN_OR_SLANTED_EQUAL_TO'),
('&#x02A7E;', '&ges;', '__ent_GREATER_THAN_OR_SLANTED_EQUAL_TO'),
('&#x02A7F;', '&lesdot;', '__ent_LESS_THAN_OR_SLANTED_EQUAL_TO_WITH_DOT_INSIDE'),
('&#x02A80;', '&gesdot;', '__ent_GREATER_THAN_OR_SLANTED_EQUAL_TO_WITH_DOT_INSIDE'),
('&#x02A81;', '&lesdoto;', '__ent_LESS_THAN_OR_SLANTED_EQUAL_TO_WITH_DOT_ABOVE'),
('&#x02A82;', '&gesdoto;', '__ent_GREATER_THAN_OR_SLANTED_EQUAL_TO_WITH_DOT_ABOVE'),
('&#x02A83;', '&lesdotor;', '__ent_LESS_THAN_OR_SLANTED_EQUAL_TO_WITH_DOT_ABOVE_RIGHT'),
('&#x02A84;', '&gesdotol;', '__ent_GREATER_THAN_OR_SLANTED_EQUAL_TO_WITH_DOT_ABOVE_LEFT'),
('&#x02A85;', '&lap;', '__ent_LESS_THAN_OR_APPROXIMATE'),
('&#x02A86;', '&gap;', '__ent_GREATER_THAN_OR_APPROXIMATE'),
('&#x02A87;', '&lne;', '__ent_LESS_THAN_AND_SINGLE_LINE_NOT_EQUAL_TO'),
('&#x02A88;', '&gne;', '__ent_GREATER_THAN_AND_SINGLE_LINE_NOT_EQUAL_TO'),
('&#x02A89;', '&lnap;', '__ent_LESS_THAN_AND_NOT_APPROXIMATE'),
('&#x02A8A;', '&gnap;', '__ent_GREATER_THAN_AND_NOT_APPROXIMATE'),
('&#x02A8B;', '&lEg;', '__ent_LESS_THAN_ABOVE_DOUBLE_LINE_EQUAL_ABOVE_GREATER_THAN'),
('&#x02A8C;', '&gEl;', '__ent_GREATER_THAN_ABOVE_DOUBLE_LINE_EQUAL_ABOVE_LESS_THAN'),
('&#x02A8D;', '&lsime;', '__ent_LESS_THAN_ABOVE_SIMILAR_OR_EQUAL'),
('&#x02A8E;', '&gsime;', '__ent_GREATER_THAN_ABOVE_SIMILAR_OR_EQUAL'),
('&#x02A8F;', '&lsimg;', '__ent_LESS_THAN_ABOVE_SIMILAR_ABOVE_GREATER_THAN'),
('&#x02A90;', '&gsiml;', '__ent_GREATER_THAN_ABOVE_SIMILAR_ABOVE_LESS_THAN'),
('&#x02A91;', '&lgE;', '__ent_LESS_THAN_ABOVE_GREATER_THAN_ABOVE_DOUBLE_LINE_EQUAL'),
('&#x02A92;', '&glE;', '__ent_GREATER_THAN_ABOVE_LESS_THAN_ABOVE_DOUBLE_LINE_EQUAL'),
('&#x02A93;', '&lesges;', '__ent_LESS_THAN_ABOVE_SLANTED_EQUAL_ABOVE_GREATER_THAN_ABOVE_SLANTED_EQUAL'),
('&#x02A94;', '&gesles;', '__ent_GREATER_THAN_ABOVE_SLANTED_EQUAL_ABOVE_LESS_THAN_ABOVE_SLANTED_EQUAL'),
('&#x02A95;', '&els;', '__ent_SLANTED_EQUAL_TO_OR_LESS_THAN'),
('&#x02A96;', '&egs;', '__ent_SLANTED_EQUAL_TO_OR_GREATER_THAN'),
('&#x02A97;', '&elsdot;', '__ent_SLANTED_EQUAL_TO_OR_LESS_THAN_WITH_DOT_INSIDE'),
('&#x02A98;', '&egsdot;', '__ent_SLANTED_EQUAL_TO_OR_GREATER_THAN_WITH_DOT_INSIDE'),
('&#x02A99;', '&el;', '__ent_DOUBLE_LINE_EQUAL_TO_OR_LESS_THAN'),
('&#x02A9A;', '&eg;', '__ent_DOUBLE_LINE_EQUAL_TO_OR_GREATER_THAN'),
('&#x02A9D;', '&siml;', '__ent_SIMILAR_OR_LESS_THAN'),
('&#x02A9E;', '&simg;', '__ent_SIMILAR_OR_GREATER_THAN'),
('&#x02A9F;', '&simlE;', '__ent_SIMILAR_ABOVE_LESS_THAN_ABOVE_EQUALS_SIGN'),
('&#x02AA0;', '&simgE;', '__ent_SIMILAR_ABOVE_GREATER_THAN_ABOVE_EQUALS_SIGN'),
('&#x02AA1;', '&LessLess;', '__ent_DOUBLE_NESTED_LESS_THAN'),
('&#x02AA2;', '&GreaterGreater;', '__ent_DOUBLE_NESTED_GREATER_THAN'),
('&#x02AA4;', '&glj;', '__ent_GREATER_THAN_OVERLAPPING_LESS_THAN'),
('&#x02AA5;', '&gla;', '__ent_GREATER_THAN_BESIDE_LESS_THAN'),
('&#x02AA6;', '&ltcc;', '__ent_LESS_THAN_CLOSED_BY_CURVE'),
('&#x02AA7;', '&gtcc;', '__ent_GREATER_THAN_CLOSED_BY_CURVE'),
('&#x02AA8;', '&lescc;', '__ent_LESS_THAN_CLOSED_BY_CURVE_ABOVE_SLANTED_EQUAL'),
('&#x02AA9;', '&gescc;', '__ent_GREATER_THAN_CLOSED_BY_CURVE_ABOVE_SLANTED_EQUAL'),
('&#x02AAA;', '&smt;', '__ent_SMALLER_THAN'),
('&#x02AAB;', '&lat;', '__ent_LARGER_THAN'),
('&#x02AAC;', '&smte;', '__ent_SMALLER_THAN_OR_EQUAL_TO'),
('&#x02AAD;', '&late;', '__ent_LARGER_THAN_OR_EQUAL_TO'),
('&#x02AAE;', '&bumpE;', '__ent_EQUALS_SIGN_WITH_BUMPY_ABOVE'),
('&#x02AAF;', '&pre;', '__ent_PRECEDES_ABOVE_SINGLE_LINE_EQUALS_SIGN'),
('&#x02AB0;', '&sce;', '__ent_SUCCEEDS_ABOVE_SINGLE_LINE_EQUALS_SIGN'),
('&#x02AB3;', '&prE;', '__ent_PRECEDES_ABOVE_EQUALS_SIGN'),
('&#x02AB4;', '&scE;', '__ent_SUCCEEDS_ABOVE_EQUALS_SIGN'),
('&#x02AB5;', '&prnE;', '__ent_PRECEDES_ABOVE_NOT_EQUAL_TO'),
('&#x02AB6;', '&scnE;', '__ent_SUCCEEDS_ABOVE_NOT_EQUAL_TO'),
('&#x02AB7;', '&prap;', '__ent_PRECEDES_ABOVE_ALMOST_EQUAL_TO'),
('&#x02AB8;', '&scap;', '__ent_SUCCEEDS_ABOVE_ALMOST_EQUAL_TO'),
('&#x02AB9;', '&prnap;', '__ent_PRECEDES_ABOVE_NOT_ALMOST_EQUAL_TO'),
('&#x02ABA;', '&scnap;', '__ent_SUCCEEDS_ABOVE_NOT_ALMOST_EQUAL_TO'),
('&#x02ABB;', '&Pr;', '__ent_DOUBLE_PRECEDES'),
('&#x02ABC;', '&Sc;', '__ent_DOUBLE_SUCCEEDS'),
('&#x02ABD;', '&subdot;', '__ent_SUBSET_WITH_DOT'),
('&#x02ABE;', '&supdot;', '__ent_SUPERSET_WITH_DOT'),
('&#x02ABF;', '&subplus;', '__ent_SUBSET_WITH_PLUS_SIGN_BELOW'),
('&#x02AC0;', '&supplus;', '__ent_SUPERSET_WITH_PLUS_SIGN_BELOW'),
('&#x02AC1;', '&submult;', '__ent_SUBSET_WITH_MULTIPLICATION_SIGN_BELOW'),
('&#x02AC2;', '&supmult;', '__ent_SUPERSET_WITH_MULTIPLICATION_SIGN_BELOW'),
('&#x02AC3;', '&subedot;', '__ent_SUBSET_OF_OR_EQUAL_TO_WITH_DOT_ABOVE'),
('&#x02AC4;', '&supedot;', '__ent_SUPERSET_OF_OR_EQUAL_TO_WITH_DOT_ABOVE'),
('&#x02AC5;', '&subE;', '__ent_SUBSET_OF_ABOVE_EQUALS_SIGN'),
('&#x02AC6;', '&supE;', '__ent_SUPERSET_OF_ABOVE_EQUALS_SIGN'),
('&#x02AC7;', '&subsim;', '__ent_SUBSET_OF_ABOVE_TILDE_OPERATOR'),
('&#x02AC8;', '&supsim;', '__ent_SUPERSET_OF_ABOVE_TILDE_OPERATOR'),
('&#x02ACB;', '&subnE;', '__ent_SUBSET_OF_ABOVE_NOT_EQUAL_TO'),
('&#x02ACC;', '&supnE;', '__ent_SUPERSET_OF_ABOVE_NOT_EQUAL_TO'),
('&#x02ACF;', '&csub;', '__ent_CLOSED_SUBSET'),
('&#x02AD0;', '&csup;', '__ent_CLOSED_SUPERSET'),
('&#x02AD1;', '&csube;', '__ent_CLOSED_SUBSET_OR_EQUAL_TO'),
('&#x02AD2;', '&csupe;', '__ent_CLOSED_SUPERSET_OR_EQUAL_TO'),
('&#x02AD3;', '&subsup;', '__ent_SUBSET_ABOVE_SUPERSET'),
('&#x02AD4;', '&supsub;', '__ent_SUPERSET_ABOVE_SUBSET'),
('&#x02AD5;', '&subsub;', '__ent_SUBSET_ABOVE_SUBSET'),
('&#x02AD6;', '&supsup;', '__ent_SUPERSET_ABOVE_SUPERSET'),
('&#x02AD7;', '&suphsub;', '__ent_SUPERSET_BESIDE_SUBSET'),
('&#x02AD8;', '&supdsub;', '__ent_SUPERSET_BESIDE_AND_JOINED_BY_DASH_WITH_SUBSET'),
('&#x02AD9;', '&forkv;', '__ent_ELEMENT_OF_OPENING_DOWNWARDS'),
('&#x02ADA;', '&topfork;', '__ent_PITCHFORK_WITH_TEE_TOP'),
('&#x02ADB;', '&mlcp;', '__ent_TRANSVERSAL_INTERSECTION'),
('&#x02AE4;', '&Dashv;', '__ent_VERTICAL_BAR_DOUBLE_LEFT_TURNSTILE'),
('&#x02AE6;', '&Vdashl;', '__ent_LONG_DASH_FROM_LEFT_MEMBER_OF_DOUBLE_VERTICAL'),
('&#x02AE7;', '&Barv;', '__ent_SHORT_DOWN_TACK_WITH_OVERBAR'),
('&#x02AE8;', '&vBar;', '__ent_SHORT_UP_TACK_WITH_UNDERBAR'),
('&#x02AE9;', '&vBarv;', '__ent_SHORT_UP_TACK_ABOVE_SHORT_DOWN_TACK'),
('&#x02AEB;', '&Vbar;', '__ent_DOUBLE_UP_TACK'),
('&#x02AEC;', '&Not;', '__ent_DOUBLE_STROKE_NOT_SIGN'),
('&#x02AED;', '&bNot;', '__ent_REVERSED_DOUBLE_STROKE_NOT_SIGN'),
('&#x02AEE;', '&rnmid;', '__ent_DOES_NOT_DIVIDE_WITH_REVERSED_NEGATION_SLASH'),
('&#x02AEF;', '&cirmid;', '__ent_VERTICAL_LINE_WITH_CIRCLE_ABOVE'),
('&#x02AF0;', '&midcir;', '__ent_VERTICAL_LINE_WITH_CIRCLE_BELOW'),
('&#x02AF1;', '&topcir;', '__ent_DOWN_TACK_WITH_CIRCLE_BELOW'),
('&#x02AF2;', '&nhpar;', '__ent_PARALLEL_WITH_HORIZONTAL_STROKE'),
('&#x02AF3;', '&parsim;', '__ent_PARALLEL_WITH_TILDE_OPERATOR'),
('&#x02AFD;', '&parsl;', '__ent_DOUBLE_SOLIDUS_OPERATOR'),
('&#x0FB00;', '&fflig;', '__ent_LATIN_SMALL_LIGATURE_FF'),
('&#x0FB01;', '&filig;', '__ent_LATIN_SMALL_LIGATURE_FI'),
('&#x0FB02;', '&fllig;', '__ent_LATIN_SMALL_LIGATURE_FL'),
('&#x0FB03;', '&ffilig;', '__ent_LATIN_SMALL_LIGATURE_FFI'),
('&#x0FB04;', '&ffllig;', '__ent_LATIN_SMALL_LIGATURE_FFL'),
('&#x1D49C;', '&Ascr;', '__ent_MATHEMATICAL_SCRIPT_CAPITAL_A'),
('&#x1D49E;', '&Cscr;', '__ent_MATHEMATICAL_SCRIPT_CAPITAL_C'),
('&#x1D49F;', '&Dscr;', '__ent_MATHEMATICAL_SCRIPT_CAPITAL_D'),
('&#x1D4A2;', '&Gscr;', '__ent_MATHEMATICAL_SCRIPT_CAPITAL_G'),
('&#x1D4A5;', '&Jscr;', '__ent_MATHEMATICAL_SCRIPT_CAPITAL_J'),
('&#x1D4A6;', '&Kscr;', '__ent_MATHEMATICAL_SCRIPT_CAPITAL_K'),
('&#x1D4A9;', '&Nscr;', '__ent_MATHEMATICAL_SCRIPT_CAPITAL_N'),
('&#x1D4AA;', '&Oscr;', '__ent_MATHEMATICAL_SCRIPT_CAPITAL_O'),
('&#x1D4AB;', '&Pscr;', '__ent_MATHEMATICAL_SCRIPT_CAPITAL_P'),
('&#x1D4AC;', '&Qscr;', '__ent_MATHEMATICAL_SCRIPT_CAPITAL_Q'),
('&#x1D4AE;', '&Sscr;', '__ent_MATHEMATICAL_SCRIPT_CAPITAL_S'),
('&#x1D4AF;', '&Tscr;', '__ent_MATHEMATICAL_SCRIPT_CAPITAL_T'),
('&#x1D4B0;', '&Uscr;', '__ent_MATHEMATICAL_SCRIPT_CAPITAL_U'),
('&#x1D4B1;', '&Vscr;', '__ent_MATHEMATICAL_SCRIPT_CAPITAL_V'),
('&#x1D4B2;', '&Wscr;', '__ent_MATHEMATICAL_SCRIPT_CAPITAL_W'),
('&#x1D4B3;', '&Xscr;', '__ent_MATHEMATICAL_SCRIPT_CAPITAL_X'),
('&#x1D4B4;', '&Yscr;', '__ent_MATHEMATICAL_SCRIPT_CAPITAL_Y'),
('&#x1D4B5;', '&Zscr;', '__ent_MATHEMATICAL_SCRIPT_CAPITAL_Z'),
('&#x1D4B6;', '&ascr;', '__ent_MATHEMATICAL_SCRIPT_SMALL_A'),
('&#x1D4B7;', '&bscr;', '__ent_MATHEMATICAL_SCRIPT_SMALL_B'),
('&#x1D4B8;', '&cscr;', '__ent_MATHEMATICAL_SCRIPT_SMALL_C'),
('&#x1D4B9;', '&dscr;', '__ent_MATHEMATICAL_SCRIPT_SMALL_D'),
('&#x1D4BB;', '&fscr;', '__ent_MATHEMATICAL_SCRIPT_SMALL_F'),
('&#x1D4BD;', '&hscr;', '__ent_MATHEMATICAL_SCRIPT_SMALL_H'),
('&#x1D4BE;', '&iscr;', '__ent_MATHEMATICAL_SCRIPT_SMALL_I'),
('&#x1D4BF;', '&jscr;', '__ent_MATHEMATICAL_SCRIPT_SMALL_J'),
('&#x1D4C0;', '&kscr;', '__ent_MATHEMATICAL_SCRIPT_SMALL_K'),
('&#x1D4C1;', '&lscr;', '__ent_MATHEMATICAL_SCRIPT_SMALL_L'),
('&#x1D4C2;', '&mscr;', '__ent_MATHEMATICAL_SCRIPT_SMALL_M'),
('&#x1D4C3;', '&nscr;', '__ent_MATHEMATICAL_SCRIPT_SMALL_N'),
('&#x1D4C5;', '&pscr;', '__ent_MATHEMATICAL_SCRIPT_SMALL_P'),
('&#x1D4C6;', '&qscr;', '__ent_MATHEMATICAL_SCRIPT_SMALL_Q'),
('&#x1D4C7;', '&rscr;', '__ent_MATHEMATICAL_SCRIPT_SMALL_R'),
('&#x1D4C8;', '&sscr;', '__ent_MATHEMATICAL_SCRIPT_SMALL_S'),
('&#x1D4C9;', '&tscr;', '__ent_MATHEMATICAL_SCRIPT_SMALL_T'),
('&#x1D4CA;', '&uscr;', '__ent_MATHEMATICAL_SCRIPT_SMALL_U'),
('&#x1D4CB;', '&vscr;', '__ent_MATHEMATICAL_SCRIPT_SMALL_V'),
('&#x1D4CC;', '&wscr;', '__ent_MATHEMATICAL_SCRIPT_SMALL_W'),
('&#x1D4CD;', '&xscr;', '__ent_MATHEMATICAL_SCRIPT_SMALL_X'),
('&#x1D4CE;', '&yscr;', '__ent_MATHEMATICAL_SCRIPT_SMALL_Y'),
('&#x1D4CF;', '&zscr;', '__ent_MATHEMATICAL_SCRIPT_SMALL_Z'),
('&#x1D504;', '&Afr;', '__ent_MATHEMATICAL_FRAKTUR_CAPITAL_A'),
('&#x1D505;', '&Bfr;', '__ent_MATHEMATICAL_FRAKTUR_CAPITAL_B'),
('&#x1D507;', '&Dfr;', '__ent_MATHEMATICAL_FRAKTUR_CAPITAL_D'),
('&#x1D508;', '&Efr;', '__ent_MATHEMATICAL_FRAKTUR_CAPITAL_E'),
('&#x1D509;', '&Ffr;', '__ent_MATHEMATICAL_FRAKTUR_CAPITAL_F'),
('&#x1D50A;', '&Gfr;', '__ent_MATHEMATICAL_FRAKTUR_CAPITAL_G'),
('&#x1D50D;', '&Jfr;', '__ent_MATHEMATICAL_FRAKTUR_CAPITAL_J'),
('&#x1D50E;', '&Kfr;', '__ent_MATHEMATICAL_FRAKTUR_CAPITAL_K'),
('&#x1D50F;', '&Lfr;', '__ent_MATHEMATICAL_FRAKTUR_CAPITAL_L'),
('&#x1D510;', '&Mfr;', '__ent_MATHEMATICAL_FRAKTUR_CAPITAL_M'),
('&#x1D511;', '&Nfr;', '__ent_MATHEMATICAL_FRAKTUR_CAPITAL_N'),
('&#x1D512;', '&Ofr;', '__ent_MATHEMATICAL_FRAKTUR_CAPITAL_O'),
('&#x1D513;', '&Pfr;', '__ent_MATHEMATICAL_FRAKTUR_CAPITAL_P'),
('&#x1D514;', '&Qfr;', '__ent_MATHEMATICAL_FRAKTUR_CAPITAL_Q'),
('&#x1D516;', '&Sfr;', '__ent_MATHEMATICAL_FRAKTUR_CAPITAL_S'),
('&#x1D517;', '&Tfr;', '__ent_MATHEMATICAL_FRAKTUR_CAPITAL_T'),
('&#x1D518;', '&Ufr;', '__ent_MATHEMATICAL_FRAKTUR_CAPITAL_U'),
('&#x1D519;', '&Vfr;', '__ent_MATHEMATICAL_FRAKTUR_CAPITAL_V'),
('&#x1D51A;', '&Wfr;', '__ent_MATHEMATICAL_FRAKTUR_CAPITAL_W'),
('&#x1D51B;', '&Xfr;', '__ent_MATHEMATICAL_FRAKTUR_CAPITAL_X'),
('&#x1D51C;', '&Yfr;', '__ent_MATHEMATICAL_FRAKTUR_CAPITAL_Y'),
('&#x1D51E;', '&afr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_A'),
('&#x1D51F;', '&bfr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_B'),
('&#x1D520;', '&cfr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_C'),
('&#x1D521;', '&dfr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_D'),
('&#x1D522;', '&efr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_E'),
('&#x1D523;', '&ffr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_F'),
('&#x1D524;', '&gfr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_G'),
('&#x1D525;', '&hfr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_H'),
('&#x1D526;', '&ifr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_I'),
('&#x1D527;', '&jfr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_J'),
('&#x1D528;', '&kfr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_K'),
('&#x1D529;', '&lfr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_L'),
('&#x1D52A;', '&mfr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_M'),
('&#x1D52B;', '&nfr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_N'),
('&#x1D52C;', '&ofr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_O'),
('&#x1D52D;', '&pfr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_P'),
('&#x1D52E;', '&qfr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_Q'),
('&#x1D52F;', '&rfr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_R'),
('&#x1D530;', '&sfr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_S'),
('&#x1D531;', '&tfr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_T'),
('&#x1D532;', '&ufr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_U'),
('&#x1D533;', '&vfr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_V'),
('&#x1D534;', '&wfr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_W'),
('&#x1D535;', '&xfr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_X'),
('&#x1D536;', '&yfr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_Y'),
('&#x1D537;', '&zfr;', '__ent_MATHEMATICAL_FRAKTUR_SMALL_Z'),
('&#x1D538;', '&Aopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_CAPITAL_A'),
('&#x1D539;', '&Bopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_CAPITAL_B'),
('&#x1D53B;', '&Dopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_CAPITAL_D'),
('&#x1D53C;', '&Eopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_CAPITAL_E'),
('&#x1D53D;', '&Fopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_CAPITAL_F'),
('&#x1D53E;', '&Gopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_CAPITAL_G'),
('&#x1D540;', '&Iopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_CAPITAL_I'),
('&#x1D541;', '&Jopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_CAPITAL_J'),
('&#x1D542;', '&Kopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_CAPITAL_K'),
('&#x1D543;', '&Lopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_CAPITAL_L'),
('&#x1D544;', '&Mopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_CAPITAL_M'),
('&#x1D546;', '&Oopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_CAPITAL_O'),
('&#x1D54A;', '&Sopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_CAPITAL_S'),
('&#x1D54B;', '&Topf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_CAPITAL_T'),
('&#x1D54C;', '&Uopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_CAPITAL_U'),
('&#x1D54D;', '&Vopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_CAPITAL_V'),
('&#x1D54E;', '&Wopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_CAPITAL_W'),
('&#x1D54F;', '&Xopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_CAPITAL_X'),
('&#x1D550;', '&Yopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_CAPITAL_Y'),
('&#x1D552;', '&aopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_A'),
('&#x1D553;', '&bopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_B'),
('&#x1D554;', '&copf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_C'),
('&#x1D555;', '&dopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_D'),
('&#x1D556;', '&eopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_E'),
('&#x1D557;', '&fopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_F'),
('&#x1D558;', '&gopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_G'),
('&#x1D559;', '&hopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_H'),
('&#x1D55A;', '&iopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_I'),
('&#x1D55B;', '&jopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_J'),
('&#x1D55C;', '&kopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_K'),
('&#x1D55D;', '&lopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_L'),
('&#x1D55E;', '&mopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_M'),
('&#x1D55F;', '&nopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_N'),
('&#x1D560;', '&oopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_O'),
('&#x1D561;', '&popf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_P'),
('&#x1D562;', '&qopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_Q'),
('&#x1D563;', '&ropf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_R'),
('&#x1D564;', '&sopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_S'),
('&#x1D565;', '&topf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_T'),
('&#x1D566;', '&uopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_U'),
('&#x1D567;', '&vopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_V'),
('&#x1D568;', '&wopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_W'),
('&#x1D569;', '&xopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_X'),
('&#x1D56A;', '&yopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_Y'),
('&#x1D56B;', '&zopf;', '__ent_MATHEMATICAL_DOUBLE_STRUCK_SMALL_Z')]

def striprtf(text):
	pattern = re.compile(r"\\([a-z]{1,32})(-?\d{1,10})?[ ]?|\\'([0-9a-f]{2})|\\([^a-z])|([{}])|[\r\n]+|(.)", re.I)
	# control words which specify a "destionation".
	destinations = frozenset((
		'aftncn','aftnsep','aftnsepc','annotation','atnauthor','atndate','atnicn','atnid',
		'atnparent','atnref','atntime','atrfend','atrfstart','author','background',
		'bkmkend','bkmkstart','blipuid','buptim','category','colorschememapping',
		'colortbl','comment','company','creatim','datafield','datastore','defchp','defpap',
		'do','doccomm','docvar','dptxbxtext','ebcend','ebcstart','factoidname','falt',
		'fchars','ffdeftext','ffentrymcr','ffexitmcr','ffformat','ffhelptext','ffl',
		'ffname','ffstattext','field','file','filetbl','fldinst','fldrslt','fldtype',
		'fname','fontemb','fontfile','fonttbl','footer','footerf','footerl','footerr',
		'footnote','formfield','ftncn','ftnsep','ftnsepc','g','generator','gridtbl',
		'header','headerf','headerl','headerr','hl','hlfr','hlinkbase','hlloc','hlsrc',
		'hsv','htmltag','info','keycode','keywords','latentstyles','lchars','levelnumbers',
		'leveltext','lfolevel','linkval','list','listlevel','listname','listoverride',
		'listoverridetable','listpicture','liststylename','listtable','listtext',
		'lsdlockedexcept','macc','maccPr','mailmerge','maln','malnScr','manager','margPr',
		'mbar','mbarPr','mbaseJc','mbegChr','mborderBox','mborderBoxPr','mbox','mboxPr',
		'mchr','mcount','mctrlPr','md','mdeg','mdegHide','mden','mdiff','mdPr','me',
		'mendChr','meqArr','meqArrPr','mf','mfName','mfPr','mfunc','mfuncPr','mgroupChr',
		'mgroupChrPr','mgrow','mhideBot','mhideLeft','mhideRight','mhideTop','mhtmltag',
		'mlim','mlimloc','mlimlow','mlimlowPr','mlimupp','mlimuppPr','mm','mmaddfieldname',
		'mmath','mmathPict','mmathPr','mmaxdist','mmc','mmcJc','mmconnectstr',
		'mmconnectstrdata','mmcPr','mmcs','mmdatasource','mmheadersource','mmmailsubject',
		'mmodso','mmodsofilter','mmodsofldmpdata','mmodsomappedname','mmodsoname',
		'mmodsorecipdata','mmodsosort','mmodsosrc','mmodsotable','mmodsoudl',
		'mmodsoudldata','mmodsouniquetag','mmPr','mmquery','mmr','mnary','mnaryPr',
		'mnoBreak','mnum','mobjDist','moMath','moMathPara','moMathParaPr','mopEmu',
		'mphant','mphantPr','mplcHide','mpos','mr','mrad','mradPr','mrPr','msepChr',
		'mshow','mshp','msPre','msPrePr','msSub','msSubPr','msSubSup','msSubSupPr','msSup',
		'msSupPr','mstrikeBLTR','mstrikeH','mstrikeTLBR','mstrikeV','msub','msubHide',
		'msup','msupHide','mtransp','mtype','mvertJc','mvfmf','mvfml','mvtof','mvtol',
		'mzeroAsc','mzeroDesc','mzeroWid','nesttableprops','nextfile','nonesttables',
		'objalias','objclass','objdata','object','objname','objsect','objtime','oldcprops',
		'oldpprops','oldsprops','oldtprops','oleclsid','operator','panose','password',
		'passwordhash','pgp','pgptbl','picprop','pict','pn','pnseclvl','pntext','pntxta',
		'pntxtb','printim','private','propname','protend','protstart','protusertbl','pxe',
		'result','revtbl','revtim','rsidtbl','rxe','shp','shpgrp','shpinst',
		'shppict','shprslt','shptxt','sn','sp','staticval','stylesheet','subject','sv',
		'svb','tc','template','themedata','title','txe','ud','upr','userprops',
		'wgrffmtfilter','windowcaption','writereservation','writereservhash','xe','xform',
		'xmlattrname','xmlattrvalue','xmlclose','xmlname','xmlnstbl',
		'xmlopen'
	))
	# Translation of some special characters.
	specialchars = {
		'par': '\n',
		'sect': '\n\n',
		'page': '\n\n',
		'line': '\n',
		'tab': '\t',
		'emdash': u'\u2014',
		'endash': u'\u2013',
		'emspace': u'\u2003',
		'enspace': u'\u2002',
		'qmspace': u'\u2005',
		'bullet': u'\u2022',
		'lquote': u'\u2018',
		'rquote': u'\u2019',
		'ldblquote': u'\201C',
		'rdblquote': u'\u201D', 
	}
	stack = []
	ignorable = False       # Whether this group (and all inside it) are "ignorable".
	ucskip = 1              # Number of ASCII characters to skip after a unicode character.
	curskip = 0             # Number of ASCII characters left to skip
	out = []                # Output buffer.
	for match in pattern.finditer(text):
		word,arg,hex,char,brace,tchar = match.groups()
		if brace:
			curskip = 0
			if brace == '{':
				# Push state
				stack.append((ucskip,ignorable))
			elif brace == '}':
				# Pop state
				ucskip,ignorable = stack.pop()
		elif char: # \x (not a letter)
			curskip = 0
			if char == '~':
				if not ignorable:
					out.append(u'\xA0')
			elif char in '{}\\':
				if not ignorable:
					out.append(char)
			elif char == '*':
				ignorable = True
		elif word: # \foo
			curskip = 0
			if word in destinations:
				ignorable = True
			elif ignorable:
				pass
			elif word in specialchars:
				out.append(specialchars[word])
			elif word == 'uc':
				ucskip = int(arg)
			elif word == 'u':
				c = int(arg)
				if c < 0: c += 0x10000
				if c > 127: out.append(unichr(c))
				else: out.append(chr(c))
				curskip = ucskip
		elif hex: # \'xx
			if curskip > 0:
				curskip -= 1
			elif not ignorable:
				c = int(hex,16)
				if c > 127: out.append(unichr(c))
				else: out.append(chr(c))
		elif tchar:
			if curskip > 0:
				curskip -= 1
			elif not ignorable:
				out.append(tchar)
	return ''.join(out)

import sys, hashlib, time, unicodedata, ntpath
from datetime import datetime
from itertools import izip
from itertools import *
from collections import Counter
# ============ CORRUPTION REGEXPS: https://gist.github.com/ryanmcgrath/982242
L=ur'A-Za-z\u00AA\u00B5\u00BA\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0345\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0559\u0560-\u0588\u05B0-\u05BD\u05BF\u05C1\u05C2\u05C4\u05C5\u05C7\u05D0-\u05EA\u05EF-\u05F2\u0610-\u061A\u0620-\u0657\u0659-\u065F\u066E-\u06D3\u06D5-\u06DC\u06E1-\u06E8\u06ED-\u06EF\u06FA-\u06FC\u06FF\u0710-\u073F\u074D-\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0817\u081A-\u082C\u0840-\u0858\u0860-\u086A\u08A0-\u08B4\u08B6-\u08BD\u08D4-\u08DF\u08E3-\u08E9\u08F0-\u093B\u093D-\u094C\u094E-\u0950\u0955-\u0963\u0971-\u0983\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD-\u09C4\u09C7\u09C8\u09CB\u09CC\u09CE\u09D7\u09DC\u09DD\u09DF-\u09E3\u09F0\u09F1\u09FC\u0A01-\u0A03\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A3E-\u0A42\u0A47\u0A48\u0A4B\u0A4C\u0A51\u0A59-\u0A5C\u0A5E\u0A70-\u0A75\u0A81-\u0A83\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD-\u0AC5\u0AC7-\u0AC9\u0ACB\u0ACC\u0AD0\u0AE0-\u0AE3\u0AF9-\u0AFC\u0B01-\u0B03\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D-\u0B44\u0B47\u0B48\u0B4B\u0B4C\u0B56\u0B57\u0B5C\u0B5D\u0B5F-\u0B63\u0B71\u0B82\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BBE-\u0BC2\u0BC6-\u0BC8\u0BCA-\u0BCC\u0BD0\u0BD7\u0C00-\u0C03\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D-\u0C44\u0C46-\u0C48\u0C4A-\u0C4C\u0C55\u0C56\u0C58-\u0C5A\u0C60-\u0C63\u0C80-\u0C83\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD-\u0CC4\u0CC6-\u0CC8\u0CCA-\u0CCC\u0CD5\u0CD6\u0CDE\u0CE0-\u0CE3\u0CF1\u0CF2\u0D00-\u0D03\u0D05-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D-\u0D44\u0D46-\u0D48\u0D4A-\u0D4C\u0D4E\u0D54-\u0D57\u0D5F-\u0D63\u0D7A-\u0D7F\u0D82\u0D83\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0DCF-\u0DD4\u0DD6\u0DD8-\u0DDF\u0DF2\u0DF3\u0E01-\u0E3A\u0E40-\u0E46\u0E4D\u0E81\u0E82\u0E84\u0E86-\u0E8A\u0E8C-\u0EA3\u0EA5\u0EA7-\u0EB9\u0EBB-\u0EBD\u0EC0-\u0EC4\u0EC6\u0ECD\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F71-\u0F81\u0F88-\u0F97\u0F99-\u0FBC\u1000-\u1036\u1038\u103B-\u103F\u1050-\u108F\u109A-\u109D\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F8\u1700-\u170C\u170E-\u1713\u1720-\u1733\u1740-\u1753\u1760-\u176C\u176E-\u1770\u1772\u1773\u1780-\u17B3\u17B6-\u17C8\u17D7\u17DC\u1820-\u1878\u1880-\u18AA\u18B0-\u18F5\u1900-\u191E\u1920-\u192B\u1930-\u1938\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u1A00-\u1A1B\u1A20-\u1A5E\u1A61-\u1A74\u1AA7\u1B00-\u1B33\u1B35-\u1B43\u1B45-\u1B4B\u1B80-\u1BA9\u1BAC-\u1BAF\u1BBA-\u1BE5\u1BE7-\u1BF1\u1C00-\u1C36\u1C4D-\u1C4F\u1C5A-\u1C7D\u1C80-\u1C88\u1C90-\u1CBA\u1CBD-\u1CBF\u1CE9-\u1CEC\u1CEE-\u1CF3\u1CF5\u1CF6\u1CFA\u1D00-\u1DBF\u1DE7-\u1DF4\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2160-\u2188\u24B6-\u24E9\u2C00-\u2C2E\u2C30-\u2C5E\u2C60-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2DE0-\u2DFF\u2E2F\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312F\u3131-\u318E\u31A0-\u31BA\u31F0-\u31FF\u3400-\u4DB5\u4E00-\u9FEF\uA000-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA674-\uA67B\uA67F-\uA6EF\uA717-\uA71F\uA722-\uA788\uA78B-\uA7BF\uA7C2-\uA7C6\uA7F7-\uA805\uA807-\uA827\uA840-\uA873\uA880-\uA8C3\uA8C5\uA8F2-\uA8F7\uA8FB\uA8FD-\uA8FF\uA90A-\uA92A\uA930-\uA952\uA960-\uA97C\uA980-\uA9B2\uA9B4-\uA9BF\uA9CF\uA9E0-\uA9EF\uA9FA-\uA9FE\uAA00-\uAA36\uAA40-\uAA4D\uAA60-\uAA76\uAA7A-\uAABE\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEF\uAAF2-\uAAF5\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB67\uAB70-\uABEA\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC\U00010000-\U0001000B\U0001000D-\U00010026\U00010028-\U0001003A\U0001003C\U0001003D\U0001003F-\U0001004D\U00010050-\U0001005D\U00010080-\U000100FA\U00010140-\U00010174\U00010280-\U0001029C\U000102A0-\U000102D0\U00010300-\U0001031F\U0001032D-\U0001034A\U00010350-\U0001037A\U00010380-\U0001039D\U000103A0-\U000103C3\U000103C8-\U000103CF\U000103D1-\U000103D5\U00010400-\U0001049D\U000104B0-\U000104D3\U000104D8-\U000104FB\U00010500-\U00010527\U00010530-\U00010563\U00010600-\U00010736\U00010740-\U00010755\U00010760-\U00010767\U00010800-\U00010805\U00010808\U0001080A-\U00010835\U00010837\U00010838\U0001083C\U0001083F-\U00010855\U00010860-\U00010876\U00010880-\U0001089E\U000108E0-\U000108F2\U000108F4\U000108F5\U00010900-\U00010915\U00010920-\U00010939\U00010980-\U000109B7\U000109BE\U000109BF\U00010A00-\U00010A03\U00010A05\U00010A06\U00010A0C-\U00010A13\U00010A15-\U00010A17\U00010A19-\U00010A35\U00010A60-\U00010A7C\U00010A80-\U00010A9C\U00010AC0-\U00010AC7\U00010AC9-\U00010AE4\U00010B00-\U00010B35\U00010B40-\U00010B55\U00010B60-\U00010B72\U00010B80-\U00010B91\U00010C00-\U00010C48\U00010C80-\U00010CB2\U00010CC0-\U00010CF2\U00010D00-\U00010D27\U00010F00-\U00010F1C\U00010F27\U00010F30-\U00010F45\U00010FE0-\U00010FF6\U00011000-\U00011045\U00011082-\U000110B8\U000110D0-\U000110E8\U00011100-\U00011132\U00011144-\U00011146\U00011150-\U00011172\U00011176\U00011180-\U000111BF\U000111C1-\U000111C4\U000111DA\U000111DC\U00011200-\U00011211\U00011213-\U00011234\U00011237\U0001123E\U00011280-\U00011286\U00011288\U0001128A-\U0001128D\U0001128F-\U0001129D\U0001129F-\U000112A8\U000112B0-\U000112E8\U00011300-\U00011303\U00011305-\U0001130C\U0001130F\U00011310\U00011313-\U00011328\U0001132A-\U00011330\U00011332\U00011333\U00011335-\U00011339\U0001133D-\U00011344\U00011347\U00011348\U0001134B\U0001134C\U00011350\U00011357\U0001135D-\U00011363\U00011400-\U00011441\U00011443-\U00011445\U00011447-\U0001144A\U0001145F\U00011480-\U000114C1\U000114C4\U000114C5\U000114C7\U00011580-\U000115B5\U000115B8-\U000115BE\U000115D8-\U000115DD\U00011600-\U0001163E\U00011640\U00011644\U00011680-\U000116B5\U000116B8\U00011700-\U0001171A\U0001171D-\U0001172A\U00011800-\U00011838\U000118A0-\U000118DF\U000118FF\U000119A0-\U000119A7\U000119AA-\U000119D7\U000119DA-\U000119DF\U000119E1\U000119E3\U000119E4\U00011A00-\U00011A32\U00011A35-\U00011A3E\U00011A50-\U00011A97\U00011A9D\U00011AC0-\U00011AF8\U00011C00-\U00011C08\U00011C0A-\U00011C36\U00011C38-\U00011C3E\U00011C40\U00011C72-\U00011C8F\U00011C92-\U00011CA7\U00011CA9-\U00011CB6\U00011D00-\U00011D06\U00011D08\U00011D09\U00011D0B-\U00011D36\U00011D3A\U00011D3C\U00011D3D\U00011D3F-\U00011D41\U00011D43\U00011D46\U00011D47\U00011D60-\U00011D65\U00011D67\U00011D68\U00011D6A-\U00011D8E\U00011D90\U00011D91\U00011D93-\U00011D96\U00011D98\U00011EE0-\U00011EF6\U00012000-\U00012399\U00012400-\U0001246E\U00012480-\U00012543\U00013000-\U0001342E\U00014400-\U00014646\U00016800-\U00016A38\U00016A40-\U00016A5E\U00016AD0-\U00016AED\U00016B00-\U00016B2F\U00016B40-\U00016B43\U00016B63-\U00016B77\U00016B7D-\U00016B8F\U00016E40-\U00016E7F\U00016F00-\U00016F4A\U00016F4F-\U00016F87\U00016F8F-\U00016F9F\U00016FE0\U00016FE1\U00016FE3\U00017000-\U000187F7\U00018800-\U00018AF2\U0001B000-\U0001B11E\U0001B150-\U0001B152\U0001B164-\U0001B167\U0001B170-\U0001B2FB\U0001BC00-\U0001BC6A\U0001BC70-\U0001BC7C\U0001BC80-\U0001BC88\U0001BC90-\U0001BC99\U0001BC9E\U0001D400-\U0001D454\U0001D456-\U0001D49C\U0001D49E\U0001D49F\U0001D4A2\U0001D4A5\U0001D4A6\U0001D4A9-\U0001D4AC\U0001D4AE-\U0001D4B9\U0001D4BB\U0001D4BD-\U0001D4C3\U0001D4C5-\U0001D505\U0001D507-\U0001D50A\U0001D50D-\U0001D514\U0001D516-\U0001D51C\U0001D51E-\U0001D539\U0001D53B-\U0001D53E\U0001D540-\U0001D544\U0001D546\U0001D54A-\U0001D550\U0001D552-\U0001D6A5\U0001D6A8-\U0001D6C0\U0001D6C2-\U0001D6DA\U0001D6DC-\U0001D6FA\U0001D6FC-\U0001D714\U0001D716-\U0001D734\U0001D736-\U0001D74E\U0001D750-\U0001D76E\U0001D770-\U0001D788\U0001D78A-\U0001D7A8\U0001D7AA-\U0001D7C2\U0001D7C4-\U0001D7CB\U0001E000-\U0001E006\U0001E008-\U0001E018\U0001E01B-\U0001E021\U0001E023\U0001E024\U0001E026-\U0001E02A\U0001E100-\U0001E12C\U0001E137-\U0001E13D\U0001E14E\U0001E2C0-\U0001E2EB\U0001E800-\U0001E8C4\U0001E900-\U0001E943\U0001E947\U0001E94B\U0001EE00-\U0001EE03\U0001EE05-\U0001EE1F\U0001EE21\U0001EE22\U0001EE24\U0001EE27\U0001EE29-\U0001EE32\U0001EE34-\U0001EE37\U0001EE39\U0001EE3B\U0001EE42\U0001EE47\U0001EE49\U0001EE4B\U0001EE4D-\U0001EE4F\U0001EE51\U0001EE52\U0001EE54\U0001EE57\U0001EE59\U0001EE5B\U0001EE5D\U0001EE5F\U0001EE61\U0001EE62\U0001EE64\U0001EE67-\U0001EE6A\U0001EE6C-\U0001EE72\U0001EE74-\U0001EE77\U0001EE79-\U0001EE7C\U0001EE7E\U0001EE80-\U0001EE89\U0001EE8B-\U0001EE9B\U0001EEA1-\U0001EEA3\U0001EEA5-\U0001EEA9\U0001EEAB-\U0001EEBB\U0001F130-\U0001F149\U0001F150-\U0001F169\U0001F170-\U0001F189\U00020000-\U0002A6D6\U0002A700-\U0002B734\U0002B740-\U0002B81D\U0002B820-\U0002CEA1\U0002CEB0-\U0002EBE0\U0002F800-\U0002FA1D'
IsCJKSymbolsandPunctuation = ur'\u3000-\u303F'
IsBasicLatin = ur'\u0000-\u007F'
IsHalfwidthandFullwidthForms = ur'\uFF00-\uFFEF'
IsLatin1Supplement = ur'\u0080-\u00FF'
IsHiragana=ur'\u3040-\u309F'
IsKatakana=ur'\u30A0-\u30FF'
IsKatakanaPhoneticExtensions=ur'\u31F0-\u31FF'

rxZHCNCorrupt = re.compile(ur"(?i)(?:¡°|¡±|¡­|â€.|¡Ü|¡£|¡¦|¡×|¡¯)|(?:\\'u?[0-9a-fA-F]+)+|(?:(?![{pIsBasicLatin}{pIsCJKSymbolsandPunctuation}{pIsHalfwidthandFullwidthForms}㐁㐆㐌㐖㐜㐨㐬㐱㐷-㐸㐻-㐾㑃㑇-㑈㑋-㑌㑎㑐㑔-㑕㑗㑙㑜㑞㑠㑢㑥-㑦㑫㑮㑳-㑶㑾-㒂㒄-㒆㒈㒊㒍-㒎㒑-㒔㒘㒚㒜-㒝㒟-㒡㒤㒦-㒩㒸㒻㒽-㒿㓃-㓄㓎㓖㓘㓚㓝-㓤㓦㓨㓱-㓷㓹-㓾㔀㔂-㔃㔅-㔇㔊-㔍㔏㔑-㔓㔗㔙㔝-㔞㔠-㔣㔥㔧-㔪㔮-㔯㔱㔴㔶-㔹㔻㕂㕆-㕌㕎㕒㕙㕞-㕟㕢-㕤㕦-㕪㕬-㕰㕲-㕳㕶-㕹㖀-㖃㖅-㖆㖏㖑㖔-㖕㖞㖡㖣㖥㖧-㖪㖵㖷-㖼㖿-㗁㗃-㗄㗈-㗊㗏㗑-㗕㗗-㗙㗛㗢㗤-㗨㗫-㗭㗰-㗲㗴-㗵㗺-㗼㗾-㘀㘄㘆㘈-㘎㘐㘓㘖-㘗㘙-㘛㘝㘣-㘥㘧-㘫㘮㘲㘵㘿-㙂㙋-㙍㙏-㙐㙔㙘-㙚㙜-㙝㙟-㙢㙤㙦㙩-㙬㙱-㙳㙶-㙷㙺㚁-㚃㚇㚊-㚋㚍㚒㚔㚖-㚘㚛-㚞㚠㚢㚤㚧㚯-㚰㚲㚻㚿-㛀㛂-㛅㛊㛍㛑-㛒㛗-㛘㛚㛣-㛥㛪-㛫㛯-㛱㛳-㛴㛸-㛺㛼㜅㜇㜌-㜏㜑㜖-㜘㜝-㜟㜢-㜤㜧㜪㜮-㜰㜲㜷-㜺㜼-㜽㜿-㝃㝅㝉㝌㝏㝔㝗㝞㝢-㝦㝩-㝪㝬-㝱㝵㝸-㝺㝼-㞂㞄㞆-㞋㞎-㞐㞒-㞘㞚-㞜㞞-㞠㞢㞥-㞧㞰-㞱㞻㞽-㞾㟂㟅㟇-㟉㟋-㟌㟎-㟐㟖㟙㟛㟞㟤㟦-㟧㟪㟬-㟭㟰-㟲㟴㟶-㟹㟻-㟽㟿㠁-㠂㠄-㠇㠉-㠏㠑-㠔㠚-㠛㠠-㠣㠥㠧㠭㠱-㠲㠴-㠵㠷-㠺㠽-㡂㡄-㡋㡏-㡔㡖-㡡㡥-㡨㡪㡭-㡯㡲㡵-㡼㡿-㢅㢈-㢋㢍-㢏㢒-㢔㢖㢙-㢛㢝-㢟㢥-㢦㢨-㢩㢫㢯-㢰㢳㢵㢷-㢸㢺-㢼㢾㣁-㣂㣄-㣈㣌㣎㣑-㣒㣔㣙-㣛㣝㣤㣫㣭㣯-㣱㣵-㣶㣻㣿㤃-㤇㤉-㤊㤍-㤏㤓-㤖㤘㤝-㤞㤡㤣-㤦㤨㤬-㤮㤰-㤲㤴㤶㤸-㤻㤽-㥀㥂㥄-㥆㥈㥊㥍㥏㥑-㥓㥗㥚-㥢㥥㥨㥪㥮-㥯㥳-㥷㥼-㥾㦀-㦁㦃㦅-㦈㦊-㦓㦕-㦗㦚㦜-㦝㦟-㦠㦢㦥-㦦㦩-㦬㦰㦴-㦵㦸-㦺㦼㦿-㧁㧃-㧄㧆㧈-㧊㧌-㧔㧖-㧙㧟㧡-㧢㧦㧩-㧭㧰㧳㧶㧹-㧻㧾㨁-㨇㨉-㨎㨐-㨒㨔㨖㨘-㨞㨠-㨣㨥㨨㨬-㨮㨰㨳㨶-㨷㨹-㨻㨽㩃-㩄㩆-㩌㩎-㩔㩙㩛-㩝㩟-㩠㩢-㩤㩧-㩩㩫㩭㩯-㩱㩳-㩷㩹-㩿㪁-㪄㪆㪈㪊-㪗㪙㪛-㪞㪠-㪦㪨-㪪㪬-㪮㪵㪷㪹-㪼㪾㫃㫊㫍-㫐㫒㫘㫚㫟㫥㫰-㫲㫶-㫷㫹㫽㬅㬊-㬋㬍-㬎㬐㬓㬗-㬘㬚㬟-㬠㬣-㬦㬫㬭-㬮㭁㭇-㭊㭎-㭏㭒㭔-㭕㭘-㭜㭡㭤-㭥㭨-㭫㭭㭯-㭰㭵-㭸㭺-㭽㭿㮂-㮃㮌㮏-㮒㮔-㮗㮙-㮚㮝-㮞㮠㮢㮤-㮫㮭-㮲㮵-㮶㮹㮾-㯂㯅-㯆㯊-㯋㯍㯏-㯐㯔-㯕㯘-㯚㯝㯡-㯢㯥㯨-㯬㯯㯱-㯳㯷-㯸㯺-㯻㯾-㯿㰁-㰄㰇㰋-㰍㰏㰘㰟㰡-㰥㰧-㰨㰪-㰰㰲-㰳㰶-㰷㰹-㰾㱁-㱂㱄㱆-㱇㱊㱌㱎㱕-㱖㱙-㱚㱜㱞-㱠㱣-㱨㱪-㱯㱱-㱶㱸-㱹㱻㱽-㲃㲅㲈-㲉㲋㲍-㲏㲓-㲗㲙-㲚㲝-㲟㲡-㲦㲨㲪-㲬㲯-㲳㲺-㲻㲽㳀-㳂㳅-㳇㳏-㳐㳔-㳕㳗-㳘㳛-㳜㳠-㳢㳥㳧㳪㳬㳮㳰-㳱㳶-㳷㳹㳻㳾-㳿㴂㴄㴋㴎-㴐㴒㴔㴘-㴚㴥㴧-㴩㴫-㴭㴯㴲-㴳㴶-㴸㴽㴿㵃㵅㵇㵋-㵎㵐-㵒㵗㵝-㵞㵠㵣㵦-㵨㵪-㵫㵭㵲-㵷㵹-㵺㵽-㶁㶄-㶇㶍-㶏㶒㶔-㶖㶛㶞-㶟㶡㶣㶦-㶧㶭㶲-㶴㶼㶿㷃㷅㷇-㷈㷏㷓㷕㷟-㷠㷢-㷥㷪㷭-㷮㷰㷳㷶㷹㷿㸅㸊㸍-㸓㸗㸙-㸝㸠-㸢㸤-㸥㸨㸪㸬㸮-㸱㸵㸷-㸹㸻-㸽㹁-㹄㹆-㹇㹉-㹔㹖-㹙㹛-㹠㹢㹤-㹧㹪-㹮㹱㹳-㹴㹶㹺-㺄㺇-㺊㺌㺎㺐-㺒㺔-㺘㺛-㺪㺴㺹㺿㻂-㻃㻅㻉-㻊㻌-㻍㻒㻗㻝-㻞㻪-㻬㻯-㻰㻷-㻸㻺㻼㻾㼆㼈-㼊㼌-㼗㼚㼜㼞-㼻㼽-㽌㽎-㽏㽑㽓㽘㽚-㽛㽠-㽡㽥-㽩㽫-㽭㽯-㽳㽷㽹-㽻㽽-㾁㾃-㾖㾘-㾙㾛-㾞㾠-㾢㾤-㾫㾭-㾰㾵-㾷㾹-㾾㿁㿃-㿇㿉-㿊㿌㿎㿑-㿓㿕-㿛㿝㿟㿣㿥-㿱㿳-㿴㿷-䀄䀇-䀊䀍䀏-䀙䀛䀟-䀣䀦䀨-䀮䀰䀲䀴-䀿䁂-䁈䁊-䁝䁢䁤-䁥䁨-䁮䁰-䁸䁺-䁿䂁-䂄䂆-䂉䂌-䂒䂔-䂕䂘-䂜䂟-䂠䂦-䂧䂩䂫-䂬䂮䂱䂳䂵-䂹䂻䂿-䃂䃄-䃅䃇-䃎䃑-䃛䃞䃠-䃤䃧䃬-䃮䃰䃳-䃺䃽-䃿䄄-䄆䄉-䄍䄏-䄐䄔䄚-䄝䄟䄤䄪-䄫䄭-䄰䄲䄶-䄷䄻-䄼䄾䅀-䅅䅊䅌䅑䅓-䅔䅖-䅘䅚-䅝䅟䅢-䅣䅥䅧䅩䅬-䅭䅲-䅵䅷-䅸䅺-䅾䆀䆃-䆅䆉-䆊䆍-䆏䆑䆕-䆘䆚-䆛䆞-䆟䆡-䆢䆧-䆨䆪䆬䆯-䆲䆵䆷-䆺䆼-䆾䇀-䇁䇅䇈䇍-䇔䇗-䇘䇚䇜-䇟䇢-䇣䇥-䇩䇫-䇰䇴䇶-䇹䇻䇽-䇾䈀䈂-䈃䈅-䈉䈋-䈐䈓-䈕䈗䈚-䈝䈠-䈦䈪-䈫䈭-䈯䈱-䈳䈵-䈶䈸䈺-䈼䈾-䈿䉁-䉅䉈-䉎䉐-䉑䉓-䉕䉗䉚-䉛䉞䉠-䉡䉣䉥-䉨䉫-䉮䉰-䉸䉺䉽-䉾䊂-䊃䊆䊉䊎䊓䊕䊗䊙-䊟䊡䊤䊦-䊧䊪-䊮䊱-䊳䊵䊷-䊸䊺-䊻䊽-䊾䋀-䋂䋈-䋑䋚-䋛䋟䋢-䋤䋨-䋭䋰䋵-䋷䋺-䋿䌃䌆䌈䌌䌎䌐䌔䌖-䌘䌛-䌠䌢䌤-䌥䌧-䌪䌭-䌰䌳-䌵䌷-䌻䍂-䍄䍇䍉-䍎䍐䍒-䍕䍗-䍝䍠-䍥䍨䍪-䍬䍮-䍸䍺-䍽䍿-䎄䎇-䎈䎊䎌䎎䎑-䎖䎘-䎚䎜䎟-䎢䎤䎦-䎳䎶-䎷䎺-䎽䏀-䏇䏉䏌䏎-䏐䏒䏔-䏚䏝䏟-䏡䏥-䏨䏪䏰-䏶䏼-䏿䐁-䐊䐎-䐕䐗䐙-䐠䐢-䐥䐧-䐯䐱-䐷䐹-䐼䐾-䑁䑄䑇-䑈䑊-䑏䑔䑖-䑘䑜䑞䑠-䑣䑥-䑦䑫-䑬䑰-䑳䑻-䑽䑿-䒁䒅-䒐䒓-䒗䒜䒞䒠-䒢䒦-䒪䒰䒲䒴䒷-䒹䒼-䒽䓂-䓄䓆-䓊䓖䓘-䓠䓢-䓣䓥䓧䓫-䓰䓲-䓴䓶䓸䓺䓼䓾䔂䔄䔇䔉䔌䔏䔑-䔒䔕䔗-䔘䔚-䔜䔞-䔠䔣䔪䔬-䔲䔴䔶-䔻䔽-䕁䕄-䕈䕊-䕋䕎䕓-䕕䕘-䕙䕛䕝-䕞䕡-䕤䕧-䕪䕭-䕮䕰䕲-䕳䕵䕷-䕹䕻-䕼䕾-䖀䖂-䖄䖆䖈-䖊䖑䖔-䖕䖗-䖙䖜䖟䖡-䖢䖤-䖩䖬-䖯䖲-䖷䖺-䖽䖿䗁-䗇䗊䗐-䗔䗗-䗘䗚-䗜䗠-䗥䗧䗩-䗪䗯䗱䗴䗷-䗹䗻-䗿䘁䘃-䘅䘋䘎䘒-䘕䘘䘜-䘝䘟䘢-䘦䘨-䘪䘯-䘰䘳-䘴䘶-䘿䙁-䙉䙌䙎-䙒䙔-䙕䙗-䙘䙜䙟-䙤䙦䙩䙬䙯䙱䙴-䙵䙷䙹䙻-䙼䙾䚂-䚇䚉䚋-䚕䚗-䚣䚥-䚫䚭-䚮䚰-䚱䚳-䚴䚶-䚷䚹䚻䚾-䛀䛄-䛈䛌-䛏䛒䛗-䛙䛜-䛠䛢-䛥䛩-䛮䛰䛲-䛵䛷䛹䛽䛿䜂-䜋䜎-䜐䜒䜕䜗䜙-䜚䜜-䜞䜡䜣䜩-䜫䜭-䜮䜰-䜲䜴䜶-䜸䜺䜼䜾䝀-䝁䝃-䝆䝈䝊-䝓䝕-䝖䝚䝟-䝠䝣䝦-䝧䝪-䝫䝭䝯䝸-䝹䝻-䝼䝿-䞃䞆䞈䞋䞍䞓-䞕䞗-䞚䞞-䞟䞣-䞦䞨-䞩䞫䞭䞰䞳-䞵䞷䞽-䞿䟁䟃-䟇䟉-䟍䟏-䟕䟗-䟘䟛-䟝䟠-䟡䟣-䟤䟨-䟫䟮䟵-䟻䟾-䟿䠄-䠋䠍䠏-䠑䠓䠗-䠜䠟-䠢䠤-䠫䠭䠯-䠱䠴-䠵䠸䠻-䠽䡀䡂-䡃䡅䡇-䡊䡑䡔䡗-䡚䡜-䡟䡢-䡤䡦-䡨䡪-䡰䡲-䡷䡹䡻䡽-䡾䢀-䢁䢃䢅-䢆䢈䢋-䢌䢐-䢔䢖䢙-䢚䢜-䢝䢡䢦-䢩䢭-䢮䢱-䢲䢵-䢶䢹-䢺䢼-䢽䢿-䣀䣄-䣅䣇䣊-䣋䣍䣏䣓-䣔䣗䣙䣝䣟-䣠䣢䣤䣩-䣪䣮䣱-䣲䣶-䤆䤈-䤊䤌䤎-䤙䤥䤨䤪䤬䤲䤴-䤶䤹䤻-䤼䤿-䥀䥂䥄䥇-䥈䥍䥏䥕䥗䥛䥝䥟-䥡䥯-䥱䥺䥽䦂-䦃䦅-䦆䦈䦊-䦋䦍䦏䦓-䦔䦖䦛䦝䦟-䦡䦥䦩-䦪䦬-䦭䦯䦱-䦳䦵-䦷䧁-䧂䧅䧇䧉-䧋䧎䧒䧘䧜-䧞䧡-䧢䧨䧪-䧫䧯-䧰䧲䧴䧷䧹䧿䨁-䨂䨈䨏-䨒䨕䨚-䨜䨞䨡-䨦䨨䨰䨲-䨴䨹䨼-䨿䩁-䩂䩆-䩌䩏-䩐䩒䩔-䩖䩙-䩜䩞-䩦䩩-䩪䩬-䩯䩱-䩲䩵-䩶䩸-䩺䩼-䩽䪁-䪂䪇-䪊䪌䪎-䪕䪗䪙-䪞䪡䪤-䪥䪫-䪬䪮-䪯䪱䪳-䪴䪷-䪹䪻-䪼䪾䫀-䫁䫃-䫄䫆䫈-䫉䫋-䫌䫏-䫒䫔䫖-䫘䫛-䫜䫞-䫢䫤-䫪䫬-䫰䫲䫴-䫵䫷-䫹䫻-䬂䬄-䬑䬓-䬔䬘䬛䬝-䬟䬣䬦䬨䬪-䬬䬯䬳-䬵䬷䬹-䬺䬼-䭉䭐-䭖䭘-䭚䭝-䭞䭠-䭢䭤䭧-䭩䭫䭭-䭮䭱䭴䭷䭹䭿䮂䮄-䮅䮋䮑䮕䮗䮙-䮚䮜-䮞䮠-䮤䮧䮫-䮮䮱䮴-䮵䮷-䮹䮾䯀䯂䯇-䯈䯊-䯍䯏䯑-䯔䯖-䯘䯚䯜䯞-䯠䯢-䯨䯪䯰-䯲䯵䯷-䯺䯼-䰆䰈-䰊䰎-䰐䰓䰕-䰖䰘䰛-䰞䰠-䰢䰤-䰧䰩䰫-䰬䰯-䰲䰴䰷-䰸䰻-䰾䱀-䱂䱅䱇䱊-䱌䱎䱐䱒-䱕䱗-䱟䱢䱤-䱥䱬䱮䱱䱵䱷-䱹䱻䱾䲀-䲁䲃䲅䲉-䲌䲓-䲔䲗-䲘䲚-䲛䲟-䲣䲥䲨䲪䲬-䲭䲯-䲰䲲䲸-䲹䲻䲽䳀-䳅䳇䳉䳋䳍䳏䳑䳓-䳖䳙-䳚䳜-䳝䳟-䳠䳢䳤-䳥䳧䳪-䳫䳭-䳯䳲-䳴䳷-䳼䳾䴁䴃䴆-䴌䴑䴓-䴛䴝䴟-䴠䴤-䴥䴧䴫-䴭䴯-䴷䴹-䵀䵃䵆䵈-䵉䵋-䵐䵒䵔-䵝䵟-䵤䵦䵨䵪-䵬䵮䵰-䵸䵺-䶆䶈-䶉䶋-䶌䶏-䶐䶒䶔-䶙䶛-䶝䶠-䶧䶩-䶫䶮-䶯䶱-䶴一-七丆-丑专-世丘-丞丠丢两-中丰-临丶-主丽-丿乁-乃久乇-乐乒-乔乖乘-乙乛-乡乣-书乨-乳乶乸乺-乿亂-争事-亏云-井亘亚-些亞-亢交-亮亲-亳亵-亶亸-亻亽亿-从仑-以仨仪-们仮-仹任份仿-伋伍-休伓伕众-伛伝-伫伭伯-估伲-伿佁-佇佉-体何-佥佧佩-佰佲-佴佶-例侍侏-侒侔侖-侠侢-侪侬侮-侵侸-侼便-俀係-俚俜-信俣-俦俨-俫俭-俱俳-俺俽-倀倄-倉個-倏們-倕倗-倢倥-倵倷债-倾偀-偁偃-偕偙-偩偫-偰偲-偷偻偾-傉傋傍-傏傑-備傛-傠傢-傥傧-傮傰-傻傽-僂僄-僉僋-僗僙-僞僡-僢僤-僰僳僵-僶僸-價僻-儀儂-儉儋儍-儎儐-儕儘儚-儜償-儧儩-儫儭儰-儴儶-儼儾-允元-兆先-光克免兑-兖党兜兟兢入全-兩八-共关-兽冀-冂内冇-冉册-冏冒-农冞-冢冤-冥冧-冨冫-冬冮-决况-冹冻-凁凃-凒凔-凕凗-凘凚-凛凝凟-凡凤-凥凨凫-凭凯-凱凳凵-函凿-刃分-刊刌-刓刕-刞删-刢判刨-利别-刮到-刳刵-刻刽刿-剅則-剈削-前剐-剘剚-剜剞-剢剥剧-副割剴-剶剸剺-劃劇-劍劏-劑劓劕-劤劦动-劮励-劳効-劼劾-勁勃勇勉-勋勍-勎勐勒-募勡-勢勤-勥勨-勩勫-勱勳-勺勼-匀包-匆匈-匍匏-匒匔-匚匜-匝匠-匡匣匥-匧匪-匱匴-匵匸-卅升-半卌-南卙-博卜-卤卦-卸卺卼卿厁-厇厉-厑厓-厚厜-厠厢-厣厥-厮厱-厲厴-厷厹去-县叁-參叆-反发-叒叔-叙叛-叜叞-叠叢-另叨-叹叻-叿吁-吙君-吲吴-吵吷-吾呀-呁呃呅-呆呈告-呋呎呐呒-呙呛-呞呠-呩呫-呭呯-咂咄-咉咋-咒咔-咛咝咟-咱咳-哕哗哙-哿唁-唌唎-唑唓-唔唗唙-唛唝-唧唩-唪唬-唷唹-啍問-啐啒-啞啡啤-啲啴-啾喀-喌喏-喑喓-喝喟-喨喪喬-喯喱-喵喷-喹喻-嗀嗂-嗗嗙-嗟嗡-嗦嗨-嗭嗯-嗳嗵-嘂嘄-嘐嘒-嘘嘚-嘜嘞-嘟嘡-嘧嘩-嘶嘸-噈噊-噐噔-噙噜-噭噯-噴噶-噹噻-嚈嚊-嚏嚓-嚞嚡嚣-嚤嚦-嚯嚲-嚷嚹嚼-囂囅-囆囈-囍囏-囑囔-囗囚-四囝-团囤-囧囩囫园-囮困-囱围-囵囷-固囼-圄圆-圍圐園-圔圖團-圜圞-圤在-圴圶圹-坒坔块坚-坴坶-垈型-垛垝-垧垩垫垭-垯垱-垲垴-垺垼-垿埁-埇埉-埒埔-埕埗-埚埝-埲埴-堎堑堕-堗堙-堛堝-堥堧-堨堪-堶堸-堺堼-堾塂-塆塈-塚塜-塞塠塢塤-塥塧-塨填-塬塮塱塳-塵塷-塻塽-墌墎-墕墘-墚墜-墣墥-墦墨-墩墫-墴墶-墷墺-墿壁-壂壅-壇壋壍壏-壖壘-壛壝-壠壢壤壧壩-声壳-壴壶壸-壺壼-壾夂-备夊-夐夒夔-夗夙-多夜-够夡-夢夤-夥大-夲头-夵夷-奋奎-奘奚奜-奦奩-奰奲-奶奸-奾妁-妔妖-妚妜-妫妭-妰妲-妶妸-妼妾-姃姅-姈姊-姌姎-姘姚-姡姣-姥姧-姩姫-姬姮-姷姹-姽姿-娎娐-娙娜-娡娣娥娧-娭娱-娲娴-娾婀-婂婄婆婈-婏婑婓婕婗-婚婜婞-婢婤-婫婭婰婳-婽婿-媆媉-媌媎-媗媚-媠媢-媪媭-媮媰-媻媽-媾嫀-嫊嫌嫎-嫏嫒嫔-嫜嫞-嫯嫱-嫸嫻-嫽嫿-嬀嬂-嬃嬅-嬉嬋-嬌嬎-嬐嬒嬕-嬗嬙-嬜嬞-嬡嬣-嬪嬬嬮-嬴嬷-嬼嬿-孀孂-孎子-孑孓-孝孟孡-学孨-孮孰-孱孳-孵孷-學孺-孻孽孿-宁它-宅宇-宏宓-实宠-宧宪-宭宰-宱害-家宸-容宽-宿寁-寂寄-寇寉-寐寒-寓寖寙寝-寬寮寰-寲寴-寽寿-封尃-小少尔-尘尚-尞尢尤-尥尧-尨尪尬尯-尵尷-居屇-屌屎-屖屙-屚屜-屵屸-屿岁-岃岈岊-岱岳-岻岽-岿峁-峄峆-峇峉-峌峎-峐峒-峔峖-峜峞-峟峡峣-峨峪-峮峰-峷峹-崇崌-崎崑-崗崙-崯崱-崷崹-嵃嵆-嵇嵉-嵌嵎-嵑嵓-嵖嵘嵚-嵛嵝嵟-嵬嵮-嵲嵴嵷-嵺嵼-嵽嵿嶁-嶂嶄-嶋嶍嶏嶒-嶤嶦-嶪嶬-嶮嶰-嶱嶳-嶴嶷-嶼嶾巁-巇巉-巋巍-巒巔巖巘巛-巟巡-巢巤-巴巶-巹巼-巿币-帟帡-師席-帮帱帳-帾幀幂-幆幈幋-幐幒-幘幛-幣幦-幭幯-年并幸-庂庄庆-庑库-庺庼庾-庿廄-廌廎廑-廔廖-廙廛-廜廞-廨廪廬廮-廯廱-廴延-廷建廾-弄弆-弈弊-式弑弓引弗-弪弭-弶弸-弽弿-彀彃-彄彆-彉彋-彐归-当录-彙彜-彝彟-彤彦-彪彬-彴彶-役彻-彾往-徂径-後徎徐-徒徕得-徙徛-從徠-御徥-徦徨-徯徲徵-徹徼-徽徿-忀忂-忍忏-忚忝-忞忠-忡忣-忨忪-忯忱-怰怲怴-怶怸-怹总-怼怾-恃恅恇-恎恐-恕恗恙-恟恢-恤恧-恰恲-恳恶恸-悄悆-悐悒悔-悝悟-悠悢-患悦-您悫-悲悴-悼悾-惁惃-惌惎惐-惝惟-惢惦-惩惫-惶惸-愁愃-愠愢-愤愦-愫愭-愮愰愲愴-愸愺-愻愾-慁慃慅-慆慈-慌慎慑-慘慚-慳慵-慺憀-憃憆憈憊-憖憙-憟憡-憲憴-憼憾-懂懅-懌懑-懒懔-懖懘-懙懛懞-懦懨懪-懫懭-懲懵-懼懾-戒戔-戜戟-戥戧-戮戰戲-戵户戺戽-扃扅-払托-扛扝扟-扤扦-执扩-扶扸-抁抃-抛抟-抢护-抶抸-抹抻-抿拂-拊拌-拎拐-拜拟拢-拺拼-拿持-挄挆-按挋-挏挑-挓挕-挖挚-挦挨挪-挰挲挴挶-挾捀-捃捅-捐捒-捘捚捝-损捡-捣捥-捯捱-捳捵-捷捺-捻捽-掅掇-掐排-掚掜-掠探-掱掳-掴掷-掺掼掾-提插-揖揘-揪揬-揮揰-揶揸揻-搂搄-搅搈搊-搕搗-搣搦-搧搪-搭搯-搴搶-搽搿摁摄-摈摊-摚摜-摤摦-摾撂撄-撏撑-撗撙撛-撥撨-撩撫-撰撲-撵撷-撸撺-擇擉-擋操-擒擔擖-擘據擝-擞擠-擢擤-擦擨-擭擯-擴擷-擸擺-攉攋-攙攛攝-攧攪-收攸-敁敃-敆效-敊敌敏-救敔-敗教-敤敦-敧敩敫-敬敮-敲整-敹敿-斈斋-斌斏-斕斗料斛-断斯-新斳斶-施斿-旇旉-旐旒-旓旕-旗旚-既日-旪旬-旸旺-旽旿-昀昂-昄昆-昗昙昜-昢昤-昫昭-是昱-昷昹-昺昼-显晁-晅晇-晌晏-晐晒-晟晡-晨晫-智晼-晾暀暂暄-暛暝暟暡-暥暧-暨暪-暬暮-暯暲-暻暽-曀曃-曌曒曔曖曘-曝曠曣曥-曦曨-曩曬-曮曰-更曶-曹曼曾-朁會-朆月-服朏-朐朒-朕朗-望朝期朡朣朦-札术-朵朷-杀杂-杉杌-杚杜-条来杧-枎析-枑枓-枚果-枟枢-枣枥枧-枨枪-枫枭-枳枵-枼枿-柈柊柌-柔柖柘-柞柠柢-柪柬-柴柶-柸柽柿-栀栅标-栏树-栝栟-校栧-栯栱-栵样-框案-桎桐-桑桓-桖桠-桭桯-桲桴-桹桻-桼桾梀-梈梊-梓梕-梙梛-梱梳-梶梸-梹梼-棂棄-棆棈-棉棋-棎棐-棡棣棦-棬森-棽椁-椈椊-椕椝椟-椠椤椧椪-椫椭椯-椵椸-椽椿-楌楎-楛楝-楠楢-楤楦-楲楴-楼榀概-榉榋-榑榓-榞榠-榥榧-榱榳-榹榻-榿槁-槆槈-槐槔槖槙-槜槟-槠槢-槧槫-槸槺-槻槽-樂樄-樏樑-樦樨横樬樯樱-樳樵-樶樸-橁橃-橅橇-橉橋-橑橓-橛橝-橣橥-橨橪橬-橯橱橴-橵橹橻-檀檂檄-檆檈-檎檐-檔檖-檗檙-檜檞-檩檫-檰檳-檹檻-櫁櫃-櫇櫋-櫎櫑櫓-櫕櫗-櫣櫧-櫪櫬-櫮櫰櫲-櫴櫶-櫾欀-欄欆-欈權-欌欏-欖欘欚-欜欞欠-欪欭-欲欶-歍歏-歑歔-歙歜-歨歪-歮歰-歲歵歷-歹死-歼歾殁-残殍殐-殥殧-殨殪-殫殮-殰殲-殼殿毁-毃毅-母每-毗毙-毛毞毡-毣毥-毦毨毪-毫毭毯-毵毷-氀氃-氉氋-氍氏-氖氘-氝氟氡-氲水-氶永-氹氻-汃汆-汍汏-汐汒-汕汗-汘汛-污汤-汹汻-沑沓-沖沘-沟没沣-泀泂-泜泞-泸泺-洅洇-洕洗-洛洝-洵洷-浖浘-浧浩-浲浴-涊涌-涏涑-涕涘涚-涛涝-涤润-涯涱-涻涽-淑淓-淙淜-淤淦淩-淬淮-混淹-淾渀渂-渃清渊渌-渎渐-渒渔渖-渝渟-渴渶游-湁湃-湇湉湋-湎湐-湙湛-湴湶湸-湹湾-湿溁溃溅-溇溉溍-溔準-溪溭-溻溽-滉滋-滕滗-滘滚滜滞-滽滿-漃漅-漐漒-漖漘-漚漜-漦漨-漴漶-漿潁潆-潇潋潍-潰潲-潵潷-潺潼-澀澂澄-澏澒-澕澗-澘澛-澜澞澠-澢澤-澴澶澹-濆濈-濏濑-濒濔-濖濘-濜濞-濩濫-濱濳濺濼濾-瀉瀋-瀑瀔-瀥瀧-瀨瀫瀯-瀵瀷-灀灂-灆灈-灊灌-灍灏灑-灓灕-灖灘-灛灝-灠灣-灥灧灪-灭灯-灱灴-灺灼灾-炊炌炎-炣炥-炽烀-烈烊-烍烏-烕烗-烠烢-烤烦-烩烫-热烯-烽烿-焇焉-焊焌-焎焐焓焕-焚焜-無焥-焧焩-焫焭-焲焴-焸焺-焻焾煀-煁煃-煆煈-煌煎-煐煒-煔煘煚-煠煢-煬煮煲-煴煸煺-煽煿-熄熆-熇熉-熋熏熑-熒熔熗-熠熣-熪熬-熳熵-燃燅-燏燑-燖燘-燚燜營-燡燤-燧燩-燫燭-燯燱燴燶-燺燼-爁爃-爊爌-爍爏-爑爓-爔爖爙-爛爝爟爡爣爥爨爪爬-爳爵-爻爽-爿牁-牂牄片-牊牌-牍牏牑-牒牖牘-牛牝-牟牡-牪牭-牯牲-牳牵-犁犃-犚犜-犝犟犡-犭犯-犰犲-犽犿-狅狈-狛狝-狤狧-狿猁猃-猄猆-猈猊-猋猍-猎猑-猞猠-猥猧猩-獂獄-獆獉-獊獌-獍獏-獓獕-獗獚獜-獢獤-獦獨-玄玆-珀珂-珃珅-珍珏-珖珘-珠珢-珮珰珲珴-珺珼-琋琎-琐琔-琕琗-琝琟-琰琲-琷琼琾-瑆瑈-瑏瑑-瑒瑔-瑟瑢-瑣瑥-瑮瑰-璋璎-璓璕璗-璡璣璥-璬璯-璲璵-璾瓀-瓁瓃-瓅瓉-瓊瓏瓑-瓘瓚-瓤瓦瓨-瓯瓳-瓷瓹-瓻瓽-甀甂-甄甆-甍甏-甔甗-甝生甡産-甦用-画甽-畁畅畇-畉畋-界畎-畑畓-畝畟畡-畦番-畬畯畲畴當-畺畼-疁疃-疄疆-疈疊-疍疏-疗疙-疛疝疟-疨疪-疾痀-痏痑-痛痝-痨痪-痱痳-痹痻-痽痿-瘈瘊-瘑瘓-瘕瘗-癀療-癃癆-癇癉-癊癌-癚癜-癠癢-癧癩癫-癲癶癸-癹登-皀皂-皋皎-皏皑-皛皝-皠皢-皤皦-皧皪-皯皱-皲皴-皵皸皺-皻皽-盀盂盄-盆盈-益盍-盘盚-盛盝-盡監-盼盾眀-看眍眏-眗眙-眝真-眠眢-眣眦-眪眬-眽着-睁睃-睘睚-睜睞-睟睡-睩睫-睯睱-睷睹-瞂瞄-瞆瞈-瞓瞕瞗-瞜瞞-瞢瞤-瞧瞩-瞭瞯-瞷瞹-瞽瞿-矀矂矄-矎矐-矑矓-矘矚-矧矩矫-石矶-砇砉-砒研砖-砘砚砜-砝砟-砧砩-砱砳-砵砷-砼砾础-硎硐-硒硕-硗硙-硢硤-硯硱硳硵-硹硻-碀碂-碃碅-碊碌-碩碫-碴碶碸-碿磁-磕磗磙-磞磠-磥磧-磬磯-磰磲-磷磹-磿礁礃-礅礈-礉礋-礌礎-礐礒-礔礗-礙礛礝-礞礣-礭礯-礷礹-祁祃-祄祆-祌祎-祑祓-祔祖-祣祥祧-祭祯-祲祴祷-祺祼-祾禀-禅禈禊-禋禍-禑禓-禘禚-禝禟-禢禤-禨禪-禮禰-禶禸-离禽-禾秀-私秃-秆秉秋种-秏科-秓秕秘-秙秛-秠秢-秤秦-秭积-秵秷-秸秺-移秽-稀稂-稄稆-稇稊-稛稝-稞稠-稤稦-稩稫種-稱稳-稵稷-稹稻-稽稿-穁穄穆-穈穊-穎穑-穒穔穖-穜穞-穢穥穧穩穫-穮穰-穱穳-穼穾-窒窔-窚窜-窣窥-窦窨-窮窱-窶窸窺窾-竂竄-竅竇-立竑竖竘-站竛-竜竞-章竣-竧竪-竫竭-端竱-竳競竹-竻竽-竿笃-笛笝-笨笪-笵笸笺-笼笾-筀筃-筌筎-筒答-筘筚-筝筟-筥筧-筨筫-筮筰-筳筵筷-筹筻-箅箇-箈箊-箋箍-箑箓-箝箟管-箣箦-箭箯-箹箽-篁篃-篏篑篓-篚篜-篬篮-篴篷-篸篺-篼篾-簃簅簇簉-簐簕-簖簙-簬簰簳-簶簸-籁籃-籈籊-籍籐籓-籔籗籙-籠籣-籧籩-籰籲-籴籷-籽粄-粆粈-粉粑-粚粜-粦粪粬粮-粯粱-粳粷粹粻-粿糁-糈糊-糍糏糑-糗糙糛-糨糪-糫糯-糶糸-糾紀-索紧-紩紫-紭累-終組-絇絍-絎結-絑絓-絔絖絘-絙絝-絳絶-綁綃-綆綈-綐綒-經綕-綖綘綜-綟綡-綴綷-緎緑-緒緔緗-緙緛緝-緤緦-緩緬-緲練-縀縆-縔縖-縗縙縛-縤縧縩-繂繄-繇繎-繕繗-繘繚繜繞-繠繢-繤繦繨-繹繻-繾纀-纂纅-纈纊-纍纏纑纓-纜纟-缶缸-缻缿罁-罆罉罌-网罔-罘罚-罢罥-罫罭-罴罶-罷罹-罿羁-羈羊-羏羑-羖羘羚-羡群-羧義羫-羭羯-羳羵羷-羺羼-翅翇-翕翗-翜翟-翣翥-翪翬-翴翷-翹翻-老考-耈耊-耐耒耔-耞耠耢-耬耮-耻耽-耿聂-聆聉-聒联-聛聝-聞聤-聥聧聩-聪聬-聭聯-聳聵-聹聻聽-肍肏肑-肝肟-肥肨-肺肼-胉胋-胏胑-胶胸-脀脂脄-脆脉-脊脌-脖脘-脛脝-脢脤-脦脨-脪脬-脲脴脶-腀腂-腖腘-腧腩-腲腴-膂膄膆-膏膑-膒膔-膕膗-膣膥-膦膨-膰膲-臆臉-臊臌-臒臔臖-臘臚-臜臞-臤臧-臨自臬-臭臰-致臶-臸臺-舍舐-舖舘-舣舥-舨航-舭舯-舾艀-艁艄-艇艉艋-艜艞-艟艡艤-艦艨-艩艫-艵艷-艺艼-芋芍-芔芗-花芳-苁苄-苅苇-苏苑-苙苛-苭苯-苾茀-茉茌茎-茏茑茓-茗茙-茢茤-茯茱茳-茺茼茿-草荋-荌荎-荔荖荙-荡荣-药荱-荲荴-荵荷-莇莉-莖莘-莬莰-莴莶-莽莿-菂菄-菈菊-菏菑-菒菔-菢菤-菥菧-菪菬-菭華-菳菵-萔萘萚萜-萝萤-萱萳-葀葂-葓葕-著葙-葭葯-葱葳-葽葿-蒀蒂蒇-蒌蒎蒑-蒔蒖-蒗蒙-蒚蒜-蓂蓄-蓖蓘蓚-蓛蓝蓟-蓠蓣蓥-蓬蓮-蓳蓵-蔃蔇-蔈蔊-蔔蔖-蔤蔦-蔭蔯蔳-蔵蔷-蔽蔿-蕊蕍-蕏蕑-蕙蕛-蕞蕠-蕰蕲蕴-蕵蕷-蕼蕾薁-薑薓-薖薘薛-薝薟-薢薤-薪薮-薺薽-薿藁-藃藅-藇藉-藓藕-藠藢-藦藨-藱藳-藴藶藹-藻藽-蘁蘄-蘉蘋-蘌蘑蘔蘖-蘜蘞蘡-蘣蘥-蘮蘳蘵-蘶蘸蘺蘼-蘽蘿虃-虄虇虉虋虍-虖虘-虚虜虞-號虡-虮虰-虱虳-虴虶-蚏蚑-蚗蚙-蚝蚟蚡-蚥蚧-蚪蚬蚮-蛌蛎-蛔蛖蛘-蛟蛡-蛮蛰-蛵蛷-蛺蛼蛾-蜀蜂-蜊蜌-蜓蜕蜗-蜚蜜-蜧蜩-蜬蜮-蜵蜷-蜹蜻-蝀蝂-蝄蝇-蝉蝌-蝓蝕-蝝蝠蝢-蝦蝩-蝪蝭-蝮蝰蝲-蝶蝸-蝾螀螂-融螏螒-螠螢-螣螦螨螪-螶螹-蟀蟂-蟆蟈-蟌蟎-蟏蟑-蟰蟲-蟴蟶-蟷蟹-蟼蟾蠀-蠁蠃-蠆蠉-蠌蠐-蠑蠓蠕-蠝蠟蠡-蠣蠦-蠪蠭-蠮蠰-蠳蠵-蠹蠻-蠼蠾血-衁衃-衆衈-衏衒-衔街衙衛-衝衟-衹衼-袂袄-袆袈-袝袡-被袭袯袱-袳袷-裂装-裋裍-裏裑-裟裢-裥裧-裬裮-裴裶-褀褂-褃褅-褛褞-褨褪-褫褮-襂襄襆-襈襊-襌襎-襓襕-襘襚-襡襣-襤襦襨-襶襸-襹襻-襼襾-覃覅-覆覉見覎-規覑-覓覕-覙覛覝-覦親-覭覯-覲覴覶-覻覽-觔觖觘-触觩-觸觺-觼觾-訖記訚-訠訢-訣訥-訮訰-訲訴-診訽-詘詚-詟詡-詣詥-試詨-詵詷-詼詾-誇誉-誋認-誕誗-誜語誠-誡誣-誨説誯-誴誶-請諍-諏諑-諘諛-諟諢-諧諫諭-謂謄-謋謍-謑謓-謟謡謣-謨謪-謳謵-謻謽-譀譃-譅譇-譊譍-譏譑-譓譕-譚譜-譞譠-譬譮-議譳-譻譽譿-讀讂讄-讅讇讉-讌讎讑-讘讛-讞讠-谾豀-豍豏-豑豕-豢豤-豫豭-豻豽-貃貅-貊貌貏-貒貔-貕貘-貙貜-貤貦-責貯-貴貶-賅資-賈賊賌賑-賓賕賙-賚賜-賞賠-賨質-賮賲賴-賵賹-賾贀贄-贅贇-贋贍-贐贔-贖贙-走赲-赺赽-赾趀-趁趃-趆趈-趋趍-趑趓-趗趙趜-趣趥-趯趱-趵趸-跉跋-跌跎-跛距-跠跢-跤跦-跳践-跻跽跿踂-踆踉-踊踌踎-踖踘踚-踧踩-踪踬-踯踱-踶踸-蹎蹐-蹓蹕蹗-蹙蹛-蹞蹡-蹣蹥-蹦蹨-蹴蹶-蹺蹼-躋躍躏-躔躘-躚躜躞-躧躩-躭躯-躰躲躴躷-躸躺躽躿-軁軃車-軒軔軖軘軚-軟軤-軥軧-軨軪-軯軱-軳軵-軼軾-較輅-輋輐-輒輔-輘輚-輦輨-輬輮-輰輲-輹輻-輼輾-輿轂-轋轍-轙轛-轜轞-辜辞-辟辣辥-辦辨-辩辫-農辴-辶辸-边辽-迂迄-迈迋迍-迎运-迕还-这进-迟迡-迦迨-迫迭-迵迷-迺迼-逇选-递途-逗這-連逦逨逪-逫逭-逯進-逸逻-逿遁-遄遆-遇運-違遗-遘遛-遠遢-遮遰-遵遷-邈邊-邌邏-邓邕-邙邛邝邟-邪邬邮-邻邽-郈郊-郋郍-郑郓-郝郟-郤郦-郫郭郯-郵郸-郹都-鄀鄂-鄉鄋-鄒鄔鄖-鄤鄦-鄶鄸-鄻鄽-酀酂-酐酒-酓酕酗-酘酚酝-酟酡-酦酨-酪酬-酺酽-醂醄-醅醇-醎醐-醓醖醚-醝醟-醣醦-醷醹-醺醽-醾釀-釃釅采釉-量金-釚釜-釞釣-釥釧釩-釪釭釰-釷釹-釺釽-鈄鈇-鈒鈔-鈕鈙-鈚鈞鈠鈣鈥-鈧鈪鈮-鈱鈳-鈴鈶-鉀鉂鉅鉈-鉉鉌-鉎鉑-鉒鉕鉗鉚-鉜鉞鉠-鉢鉥-鉧鉩鉬-鉮鉴-鉼鉾-銀銃銅銇-銈銊-銋銍-銎銐-銑銓-銜銠-銡銣-銦銨-銬銮銱銴-銹銻-銼銾鋀-鋃鋅-鋈鋊-鋍鋏-鋐鋒鋕-鋚鋜-鋡鋣-鋪鋬-鋱鋶鋸-錂錆-錊錍-錒錔-錜錞-錫錭-錯録-錳錶錸錽-錾鍀-鍁鍃鍆-鍉鍋-鍍鍏鍑鍔鍖-鍘鍚-鍛鍝鍠鍤-鍧鍩-鍪鍬-鍮鍰-鍲鍴-鍶鍹-鍺鍾鎁-鎂鎄-鎅鎇-鎋鎍鎏-鎓鎕-鎖鎘鎛鎝-鎞鎡-鎤鎦-鎪鎬鎮-鎰鎳鎵鎸鎿-鏊鏌-鏍鏏-鏓鏕-鏢鏤鏦鏨-鏩鏰鏵鏷-鏻鏾鐀鐃-鐈鐋-鐐鐒-鐖鐘-鐙鐜-鐝鐠鐥-鐪鐬-鐶鐸-鐼鐾-鐿鑄-鑅鑇-鑈鑊-鑌鑏-鑐鑒鑔-鑖鑘鑝-鑞鑠-鑣鑥鑨鑫鑭-鑲鑴鑷鑹-鑺鑼-钃钅-镸镺镼-門閂-閃閆閈-閉開-閏閑間-閕閘閛-閜閟閡閣-閦閨-閮閲閵-閷閹-闀闃-闄闆闈-闍闏-闖闛-闥门-队阡-阤阧阪-阫阭-阮阰-陂附-降陏-陖陘-陛陝-除陧-陮陰-陸陼-陾隁隃隅-隕隗-隙際-隟隤-隥隧-隫隮隰-隱隳-隴隶隸-难雀-雇雉-雊雌-雐雒雔-雜雟-難雥雧-雪雭雯雱-雳零-雷雹-電雾-霉霋霍-霐霒-霔霖霙霛-霞霠-霤霦-霫霭-霮霰-霳霵-霶霸-霹霼-靉青-靔靖-面靤-靬靮-靰靲-靴靶-靸靺-鞁鞃-鞅鞇-鞋鞍鞏鞑-鞕鞗-鞣鞥-鞨鞪-鞴鞶鞸-鞹鞻-鞽鞿-韀韂-韇韉韋-韐韒-韔韖-韙韛-韣韦-韭韯-韱音韵-韶韸-韺韽響-頊頌-頙頛-頞頠-頢頤頦-頪頭-頰頲-頳頵頷-頸頻頽頿-顂顄-顆顈-顊題-顎顐-顔顖-顙顛-顥顧-顬顮-颩颬-颳颵-颾飀-飂飄飆飈-飉飋-飛飞-飣飥-飫飭飯飲-飷飺-餀餂-餅餉-餘餛-餟餡餣-餦館-餫餭-餰餲-餴餶-餷餺餼餾-饁饃饅-饌饎饐-饒饔-饙饛-饜饞饠-馞馠-馡馣-馪馬-馶馸-馺馽-馾駁-駃駉-駊駍駏-駝駟駡-駥駧-駨駪駬-駭駰-駱駴-駵駷-騂騄-騅騇騉-騋騍-騏騑騕-騗騙騜-騠騢騤騦-騧騩-騳騵-騻騽-騾驀-驅驈-驐驒驔-驗驙-驝驟驡-驢驤-驨驪-骨骫-骴骶-骼骿-髃髅-髆髉-髌髎-髖高髝-髢髤髦-髧髩髫-髯髲-髳髵-髶髹-髿鬁鬃-鬈鬊-鬓鬕-鬚鬜鬞-鬥鬧鬩鬮-鬯鬱-鬷鬹-魑魔-魝魟-魨魪-魯魱魳-魷魺-鮈鮊-鮓鮚-鮡鮣-鮮鮰鮳鮶-鮺鮿-鯁鯄-鯊鯒鯔-鯘鯚-鯛鯝-鯞鯡-鯮鯰鯴鯶-鯸鯺-鯿鰁-鰃鰅-鰆鰈-鰋鰍-鰐鰒-鰕鰛-鰝鰟-鰡鰣-鰭鰯鰱-鱊鱍-鱒鱔鱖-鱘鱚鱝-鱨鱬-鱯鱲-鱵鱸鱺鱼-鳪鳬-鳭鳱-鳴鳶-鴇鴉-鴋鴍鴐鴒-鴛鴝-鴦鴨鴯-鴴鴷鴹-鴽鴿-鵅鵊鵌-鵗鵙鵛-鵝鵟-鵡鵩-鵬鵮-鵯鵲-鵳鵵鵷-鵹鵻-鵾鶀鶂-鶌鶒-鶓鶖-鶛鶝鶠-鶡鶣-鶥鶩-鶪鶬鶮-鶲鶴-鶵鶸-鶾鷀-鷅鷇鷉-鷋鷎鷐鷓-鷜鷞-鷟鷢鷤-鷦鷩鷫鷭-鷯鷲-鷳鷸-鷻鷽-鷾鸀-鸃鸅-鸇鸉-鸌鸏-鸑鸓鸕鸗-鸘鸚-鹶鹹-鹺鹼-麈麊-麌麑-麗麙麛-麝麟麥-麩麮-麱麳-麵麷-麸麻麽-麾黀-黂黄-黅黇黉-黑黓-默黚-黹黻-鼂鼄-鼆鼉鼋-鼐鼒-鼗鼙-鼝鼟-鼠鼢鼤-鼬鼮-鼯鼱-鼳鼵-鼹鼻-鼿齁齃-齇齉-齍齏-齡齣-齤齦齨齪-齵齷-齸齺-龑龓-龗龙-龡龣龥龴-龻𠂇𠂉𠃌𡗗𢦏𤇾])[\u0080-\u009F{pL}])+".format(pIsBasicLatin=IsBasicLatin, pIsCJKSymbolsandPunctuation=IsCJKSymbolsandPunctuation, pIsHalfwidthandFullwidthForms=IsHalfwidthandFullwidthForms, pL=L))
rxRUCorrupt = re.compile(ur"(?i)(?:(?![{pIsBasicLatin}а-яё])[\u0080-\u009F{pL}])+".format(pIsBasicLatin=IsBasicLatin, pL=L))
rxDECorrupt = re.compile(ur"(?i)(?:¡°|¡±|¡­|â€.|¡Ü|¡£|¡¦)|(?:\\'u?[0-9a-f]+)+|(?:(?![{pIsBasicLatin}äöüß])[\u0080-\u009F{pL}])+".format(pIsBasicLatin=IsBasicLatin, pL=L))
rxENCorrupt = re.compile(ur"(?i)(?:(?![{pIsBasicLatin}{pIsLatin1Supplement}])[\u0080-\u009F{pL}])+|¡°|¡±|¡­|â€.|¡Ü|¡£|¡¦|¡×|¡¯|\?{{4,}}".format(pIsBasicLatin=IsBasicLatin, pIsLatin1Supplement=IsLatin1Supplement, pL=L))
#rxJACorrupt = re.compile(ur"(?i)\?{{4,}}|(?:¡°|¡±|¡­|â€.|¡Ü|¡£|¡¦|¡×|¡¯)|\\'u?[0-9a-f]+|[\uFF61-\uFF9F].*[\u30A0-\u30FF]|[\u30A0-\u30FF].*[\uFF61-\uFF9F]|(?![{pIsBasicLatin}{pIsCJKSymbolsandPunctuation}{pIsHalfwidthandFullwidthForms}{pIsHiragana}{pIsKatakana}{pIsKatakanaPhoneticExtensions}一-丁七万-下不-与丐-丑且-丙丞両並个中丱-串丶丸-丹主-丼丿乂-乃久之乍-乏乕-乙九-也乢乱乳乾亀亂亅-了予-二于云-互五-井亘-亙些-亜亞-亢交-亦亨享-亮亰亳亶人什-仂仄仆-仇今-介仍-仏仔-仙仝-仟代-以仭-仮仰仲件-价任企伉-伊伍-休会伜-伝伯-估伴伶伸伺似-伽佃但-佇位-佑体何佗余-佞佩佯-佰佳併-佶佻-佼使侃來侈例侍侏侑侖侘供依侠-価侫侭-侯侵-侶便係-俄俊俎俐-俑俔俗-俘俚-俛保俟信俣-俥修-俯俳俵-俶俸俺俾倅-倆倉個倍倏們-倒倔倖候-倚借倡倣-倦倨-倭倶倹偃假-偉偏-偐偕-偖做停健偬偲側-偶偸偽傀傅傍傑傘-傚催-傭傲-債傷傾僂僅僉-僊働像僑僕-僖僚僞僣僥僧僭-僮僵價僻儀-儂億儉儒儔-儖儘儚償儡優儲儷儺-儼儿-允元-光克-兎児兒兔党兜兢入全-兮共兵-典兼冀冂内-円冉-冊册-再冏-冓冕-冗写冠冢冤-冦冨-冬冰-冷冽凄-准凉凋-凍凖凛-凝几-凡処-凧凩-凪凭凰-凱凵-凶凸-出函-凾刀刃-刄分-刈刊-刋刎刑刔列初判-別刧利-刪刮到刳制-刻剃-剄則削-前剏剔剖剛剞剣-剥剩-剪副-創剽剿劃劇-劉劍劑-劒劔力功-加劣助-劭励労-劵効劼劾勁勃勅勇勉勍勒動勗-務勝-勠勢-勤勦-勧勲-勳勵勸-勺勾-勿匁-匂包-匆匈匍匏-匐匕-北匙-匚匝匠-匡匣匪匯匱匳匸-医匿-十千卅-半卍卑-協南-単博卜卞占卦卩卮-危即-卵卷-卸卻卿厂厄厖厘厚原-厠厥-厦厨-厩厭-厮厰厳厶去参-參又-収叔取-受叙叛叟叡-句叨-右叶-司叺吁吃-各合-向君吝吟-吠否吩含-吮吶吸-吹吻-吾呀呂呆呈-告呎呑呟周呪呰-呱味呵-呷呻-命咀咄咆咋-和咎-咐咒咢咤-咥咨咫-咬咯咲-咳咸咼-咾哀-哂哄哇-哉哘員-哢哥-哦哨-哩哭-哮哲哺哽唄唆-唇唏-唐唔唖售-唯唱唳唸-唹唾啀啄-商啌問啓啖-啗啜-啝啣啻-啼啾喀喃-善喇喉-喋喘-喚喜-喟喧-喬單喰営嗄-嗅嗇嗔嗚嗜嗟嗣-嗤嗷嗹嗽-嗾嘆嘉嘔嘖-嘘嘛嘩嘯嘱-嘲嘴嘶嘸噂噌噎噐噛噤器噪-噬噴噸噺嚀嚆-嚇嚊嚏嚔嚠嚢嚥嚮嚴嚶嚼囀-囃囈囎囑囓囗-囘囚-四回因団囮困囲-図囹-固国囿-圀圃-圄圈-圉國圍圏園-圓圖團圜土圦-在圭地圷-圸圻址坂均坊坎-坑坡坤坦坩-坪坿垂垈-垉型垓垠垢-垤垪垰垳埀埃埆埋城埒-埔埖埜域-埠埣埴執培-基埼堀堂堅-堆堊-堋堕堙堝堡堤堪堯-報場-堵堺堽塀-塁塊-塋塑-塒塔塗-塚塞塢塩填塰塲塵塹塾境墅墓増墜墟墨墫墮墳墸-墻墾壁壅壇壊壌壑壓壕壗-壙壜壞-壟壤-壥士-壬壮-売壷壹-壽夂変-夊夏-夐夕-外夘-夜夢夥大天-央失-夲夷-夸夾奄奇-奉奎-契奔-奕套-奘奚奠奢奥奧-奪奬奮女-奴奸好妁-妄妊妍妓妖妙妛妝妣妥妨妬妲妹妻妾姆姉始姐-姑姓-委姙-姚姜姥-姦姨姪-姫姶姻姿威娃娉娑娘娚娜娟-娠娥娩娯娵-娶娼婀-婁婆婉婚婢婦婪婬婿媒媚-媛媼-媾嫁-嫂嫉嫋-嫌嫐嫖-嫗嫡嫣嫦嫩嫺-嫻嬉嬋-嬌嬖嬢嬪嬬嬰嬲嬶嬾孀孃孅子-孑孔-孕字-存孚-孝孟季-学孩孫孰-孱孳孵學孺宀它宅宇-安宋-宍宏宕宗-宝実客-宦宮宰害-家宸-容宿寂-寇寉富寐寒-寔寛寝-察寡-寢寤-審寫寮寰寳寵-寶寸寺対-寿封-専射-尋對-小少尓尖尚尠尢尤尨尭就尸-屁居-屆屈届-屋屍-屑屓展属屠-屡層-履屬屮-屯山屶屹岌岐-岑岔岡岨-岩岫-岬岱岳岶-岸岻-岼岾峅峇峙峠-峡峨-峪峭峯-峰島峺-峻峽崇崋崎崑崔-崛崟崢崩嵋-嵌嵎嵐嵒嵜嵩嵬嵯嵳嵶嶂嶄嶇嶋-嶌嶐嶝嶢嶬嶮嶷嶺嶼-嶽巉巌-巍巒-巓巖巛川-州巡巣工-巨巫差己-巵巷巻巽-巾市-布帆帋-希帑帖帙-帛帝帥師席帯-帰帳帶-常帽幀幃-幅幇幌幎幔-幕幗幟幡-幤干-并幸-广庁広-庄庇床序底-店庚府庠度-座庫庭庵-庸廁-廃廈-廊廏-廐廓廖廚-廛廝廟-廣廨-廩廬廰-廱廳-廴延-廸建-廼廾-廿弁弃-弄弉-弍式-弑弓-弘弛弟弥-弧弩弭弯弱張強-弸弼弾彁彈彊彌彎彑当彖-彗彙彜-彝彡-形彦彩-彭彰-影彳彷役彼彿-待徇-很徊-後徐-従得-徙從徠-御徨-循徭-微徳-徴徹徼-徽心必忌-忍忖-忙応-忝忠忤快忰-忱念忸忻忽忿怎-怐怒怕-怖怙怛-思怠-怡急-怫怯怱怺恁-恃恆恊-恋恍恐恒恕恙-恚恟-恠恢-恥恨-恭息-恰恵恷悁悃-悄悉悋-悍悒悔悖-悗悚-悛悟-悠患悦-悧悩-悪悲-悶悸悼-悽情-惇惑惓惘惚惜惟-惡惣惧-惨惰-惱想-惴惶-惷惹-惻愀-愁愃愆愈-愉愍-意愕愚-愛感愡愧-愨愬愴愼-愿慂慄慇-慈慊-慎慓慕慘-慚慝慟慢-慣慥慧-慨慫慮-慱慳-慷慾憂憇憊憎憐-憑憔憖憙-憚憤憧憩憫-憬憮憲憶憺憾懃懆-懍懐懣懦懲懴懶-懸懺懼-戀戈-戊戌-戎成-戒戔或戚-戛戝-戟戡戦截戮-戰戲-戴戸戻房-扁扇-扉手才-扎打払托扛扞扠扣扨扮扱扶批扼找-技抂-抄抉-把抑-折抛-抜択披-抬抱抵抹抻-抽拂担-拊拌-拍拏-拔拗-拙招-拝拠-拡括-拯拱拳拵-拷拾-拿持-挂指-按挌挑挙挟挧-挨挫振挺挽-挿捉捌-捍捏-捐捕捗捜捧-捩捫据捲捶-捷捺-捻掀掃授-掉掌掎-掏排掖掘掛掟-掣接控-掬掲掴-掵掻掾揀揃-揄揆揉描-提插揖揚-換握揣揩揮援揶揺搆損搏搓搖-搗搜搦搨搬-搭搴搶携搾摂摎摘摧摩摯摶摸摺撃撈撒-撓撕撚撞撤-撥撩撫播-撮撰撲撹撻-撼擁-擂擅擇操擒擔擘據擠-擣擦-擧擬擯擱-擲擴擶擺擽-擾攀攅攘攜-攝攣-攤攪-攬支攴-改攻放-政故效敍敏救敕-教敝-敞敢-散敦敬数敲整-敵敷-數斂-斃文-斉斌斎斐-斑斗料斛-斜斟斡斤-斥斧斫-断斯-新斷方於-施旁旃-旆旋-旌族旒旗旙旛无-既日-早旬-旭旱旺-旻昂-昃昆-昇昊昌明-昏易-昔昜星-映春昧-昨昭是昴-昶昼昿晁-晄晉晋晏晒晝-晟晢晤晦-晩普-晰晴晶智暁暃-暄暇-暉暎暑暖-暘暝暢暦暫暮暴暸-暹暼暾曁曄曇曉曖曙-曚曜-曝曠曦曩曰曲-曵曷-曹曼-最會月-有朋服朏朔-朗望朝-期朦-木未-朮朱朴朶-朸机朽朿杁杆杉李-村杓杖杙杜杞-来杪杭杯-杳杵杷杼松-板枅枇枉枋-枌析枕林枚果-枝枠-枢枦枩枯枳-枴架-枹柁柄柆柊柎-柑染-柔柘柚柝-柞柢柤柧柩柬柮-柯柱柳-柵査柾-柿栂-栄栓栖-栗栞校-栢栩-栫栲栴核-根格-栽桀-桃框案桍-桎桐-桑桓-桔桙桜-桝桟档桧桴桶-桷桾-桿梁梃梅梍梏梓-梔梗梛條梟-梠梢梦-梨梭梯-梱梳梵-梶梹-梺梼棄棆棉-棋棍棒棔-棕棗-棘棚棟-棡棣棧森-棯棲棹-棺椀-椁椄-椅椈椋-椏椒椙-検椡-椣椥-椦椨椪椰椴椶椹椽椿楊楓-楕楙-楚楜-楞楠-楢楪-楫業-楯楳-極楷-楹楼-楾榁-概榊榎榑榔-榕榛-榜榠榧榮榱-榲榴榻榾-榿槁槃槇槊-槎槐槓様-槙槝-槞槧-槨槫槭槲槹槻槽槿樂樅樊-樌樒-樔樗標樛樞-樟模-樣権-樫樮樵-樶樸-樺樽橄橇-橈橋橘-橙機橡-橢橦橲橸橿-檀檄檍-檎檐檗檜檠檢-檣檪檬檮檳檸檻櫁-櫃櫑櫓櫚-櫛櫞-櫟櫨櫪櫺-櫻欄-欅權欒欖欝欟-次欣欧欲欷-欺欽-款歃歇歉歌歎歐歓-歔歙歛歟歡-此武歩-歪歯歳-歴歸-歹死歿-殀殃-殄殆殉-残殍殕-殖殘殞殤殪-殫殯殱-段殷殺-殼殿-毀毅-毆毋母-毎毒-比毘毛毟毫-毬毯毳氈氏民氓-气気氛氣-氤水氷-永氾汀-求汎汐汕汗汚汝-池汢汨汪汰汲-汳決汽-汾沁-沃沈沌-沍沐沒-沓沖沙-沛没-沢沫沮沱河沸-沿況泄-泅泉-泊泌泓法泗泙泛泝泡-泣泥注泪泯-泱泳洋-洌洒洗洙洛洞-洟津洩-洫洲-洳洵-洶洸活洽-派流浄-浅浙-浚浜浣-浤浦浩-浪浬浮浴海-浹涅消涌涎涓涕涙涛-涜涯液涵涸涼淀淅-淇淋-淌淑-淒淕淘-淙淞淡淤淦淨淪-淬淮深淳淵混淹-添清渇-渋渓渕渙-減渝渟-渡渣-渦温渫-港游渺渾湃湊湍-湎湖湘湛湟湧湫湮-湯湲湶湾-満溂溌溏-源準溘溜-溝溟溢溥溪溯溲溶-溷溺溽滂滄-滅滉滋-滌滑滓-滕滝-滞滬滯滲滴滷-滸滾-滿漁-漂漆漉漏漑漓-漕漠漢-漣漫-漬漱-漲漸漾-漿潁潅潔潘潛-潜潟潤潦潭-潰潴潸潺潼澀-澂澄澆澎澑澗澡澣-澤澪澱澳澹激-濃濆濔-濕濘濛濟-濡濤濫-濬濮-濯濱濳濶濺濾瀁瀉瀋瀏瀑瀕瀘瀚-瀛瀝-瀟瀦-瀧瀬瀰瀲瀾灌灑灘灣火灯-灰灸灼-災炉-炊炎炒炙炬-炯炳炸-為烈烋烏烙烝烟烱烹烽焉焔焙-焚焜無焦然焼煉煌煎煕-煖煙煢煤-照煩煬煮煽熄熈熊熏熔-熕熙熟熨熬熱熹熾燃燈-燉燎燐燒燔-燕燗營-燠燥-燧燬-燮燵燹燻-燼燿爆爍爐爛爨爪爬-爭爰爲爵-父爺-牀牆-版牋-牌牒牘-牙牛牝牟牡-牢牧物牲牴特牽-牾犀-犂犇犒犖犠犢犧犬犯犲状犹狂-狄狆狎狐狒狗狙狛狠-狢狩独-狭狷-狹狼-狽猊猖-猗猛-猝猟猥猩-猫献-猯猴猶-猷猾-猿獄-獅獎-獏獗獣獨獪獰獲獵獸獺-獻玄率玉王玖玩玲-玳玻珀珂珈珊珍-珎珞珠珥珪班-珮珱珸現球琅-理琉琢琥琲-琶琺琿瑁瑕瑙-瑜瑞-瑠瑣-瑤瑩-瑪瑯-瑰瑳瑶瑾璃璋璞璢璧環璽瓊瓏瓔瓜瓠瓢-瓣瓦-瓧瓩瓮瓰-瓲瓶-瓸甃-甅甌-甎甑甓甕甘甚甜甞-生産甥-甦用甫-甬田-申男-甸町-甼畄畆畉-畍畏畑畔留-畝畠畢畤-畧畩-畫畭異畳-畴當-畸畿疂疆-疇疉-疋疎-疏疑疔疚疝疣疥疫疱-疳疵疸-疹疼-疾痂-痃病症痊痍痒痔-痕痘-痙痛痞痢-痣痩痰痲-痴痺痼痾-痿瘁瘉瘋瘍瘟-瘢瘤瘧瘰瘴瘻療癆-癈癌癒癖癘癜癡-癢癧-癪癬癰癲癶癸発-百皀皃-的皆-皈皋皎皐皓皖皙-皚皮皰皴皷-皺皿盂-盃盆盈益盍盒盖-盗盛-盜盞-盟盡監-盥盧盪目盲直相盻盾省眄眇-眉看-県眛眞-眠眤-眦眩眷-眸眺眼着睇睚-睛睡督睥-睦睨睫睹睾-睿瞋瞎瞑瞞瞠瞥瞬-瞭瞰瞳瞶瞹瞻-瞽瞿矇矍矗矚-矜矢-矣知矧矩短-矯石矼砂砌砒研-砕砠砥-砧砲破砺砿硅硝硫-硬硯硲硴硼碁碆-碇碌-碎碑碓碕碗碚碣碧碩-碪碯碵確碼碾磁磅-磆磊-磋磐-磑磔磚磧-磨磬磯磴磽礁礇礎礑-礒礙礦礪-礬示礼社祀-祁祇-祉祐祓祕-祗祚祝-祠祢祥票祭祷祺祿-禁禄-禅禊禍-福禝禦-禧禪禮禰禳禹-禺禽-私秉秋科-秒秕秘租秡秣-秤秦-秧秩秬称移稀稈程稍-税稔稗-稚稜稟-稠種稱-稲稷稻-穀穂-穃穆穉積-穐穗穡-穣穩穫穰穴究穹-空穽穿突窃-窄窈窒-窓窕-窘窟窩-窪窮-窰窶窺窿竃-竅竇-竈竊-立竍竏竒-竓竕站-竚竜-竝竟-竣童-竦竪竭端-竰競竸-竺竿笂笄笆笈笊-笋笏笑笘-笙笛笞笠笥-符笨第笳笵-笶笹筅-筆筈-等筋-筍筏-筒答策筝筥筧筬筮筰-筱筴-筵筺箆-箇箋箍箏箒箔-箕算-箚箜-箝箟管箪箭箱箴箸節-篁範篆-篇築篋-篌篏篝篠篤-篦篩篭篳篶-篷簀簇簍簑-簔簗簟簡簣簧簪-簫簷-簸簽-籀籃籌-籍籏-籐籔籖籘籟-籠籤-籥籬米籵籾粁-粃粉粋粍粐粒粕粗-粘粛粟粡-粢粤-粥粧-粨粫粭-粮粱-粳粹粽-精糀糂糅糊糎糒糖糘糜糞-糠糢糧糯糲糴糶糸糺-系糾紀紂約-紆紊-紋納紐純-紕紗-紜素-索紫-紬紮-細紲-紳紵紹-紺紿終-絆絋-経絎-結絖絛絞絡-絣給絨絮統-絳絵-絶絹絽綉綏經継-綜綟綢-綣綫-網綴-綵綸綺-綻綽-綿緇緊-緋総緑-緒緕緘線緜-緞締-緡緤編-緩緬緯緲練緻縁縄-縅縉-縋縒縛縞-縟縡-縣縦縫縮縱-縲縵縷縹-縻總-績繁繃繆繊-繋繍織-繖繙-繚繝-繞繦-繧繩-繪繭繰繹繻-繽繿纂-纃纈-纉續纎-纐纒-纔纖纛-纜缶缸缺罅罌-罎罐-网罔-罕罘罟-罠罧-罫置罰署罵罷-罹羂-羃羅-羈羊羌美羔羚羝-羞羣-群羨-義羮-羯羲羶羸-羹羽翁翅-翆翊翌習翔-翕翠-翡翦翩翫翰翳翹翻-翼耀-老考-耆耋-而耐耒耕耗-耙耜耡耨耳耶耻耽耿聆聊聒聖聘聚聞-聟聡-聢聨聯-聰聲-聴聶-職聹聽-聿肄-肇肉肋-肌肓肖肘肚-肛肝股-肢肥肩-肪肬-肭肯肱-育肴肺胃-胄胆背胎胖胙-胛胝-胞胡胤-胥胯胱胴胸胼-能脂脅-脊脚-脛脣脩脯脱脳脹脾腆腋腎腐-腑腓-腕腟腥-腦腫腮腰-腱腴腸-腺腿-膀膂-膃膈膊膏膓膕膚膜-膝膠膣-膤膨-膩膰膳膵膸膺膽-臀臂臆臈-臉臍臑臓臘-臚臟-臠臣臥臧-臨自臭至-致臺-臼臾舁-舂舅與-舊舌-舎舐舒舖-舘舛-舜舞-舟舩-般舮舳舵-船艀艇艘-艚艝艟艢艤艦艨艪-艫艮-良艱-色艶-艸艾芋芍芒芙芝芟芥-芦芫-芭芯花芳芸-芹芻芽苅苑-苔苗苙苛-苜苞-苟苡苣若-苧苫英苳-苴苹-苻茂-茆茉茎茖-茘茜茣茨茫茯茱-茲茴-茶茸-茹荀荅草-荊荏-荐荒荘荳荵荷荻-荼莅莇莉-莊莎莓莖莚莞-莠莢莨莪-莫莱莵莽菁菅菊菌菎菓菖菘菜菟-菠菩菫華-菲菴菷菻菽萃-萄萇萋-萎萓萠萢萩-萪萬萱萵萸萼-落葆葉葎著葛葡-董葦葩葫-葯葱葵葷葹-葺蒂蒄蒋蒐蒔蒙蒜蒟蒡蒭蒲蒸-蒹蒻-蒼蒿蓁蓄蓆蓉-蓋蓍蓐-蓑蓖蓙-蓚蓬蓮蓴蓼蓿-蔀蔆蔑蔓-蔕蔗-蔘蔚蔟蔡蔦蔬-蔭蔵蔽蕀-蕁蕃蕈-蕋蕎蕕蕗-蕘蕚蕣蕨-蕪蕭蕷蕾薀薄薇-薈薊薐-薑薔薗薙薛-薜薤薦薨-薬薮-薯薹-薺藁藉藍藏-藐藕藜-藝藤-藥藩-藪藷藹-藻藾蘂蘆-蘇蘊-蘋蘓蘖-蘗蘚蘢蘭蘯-蘰蘿虍-虎虐虔-處虚虜虞-號虧虫虱虹虻蚊-蚌蚓蚕蚣-蚤蚩-蚫蚯-蚰蚶蛄蛆-蛇蛉蛋蛍-蛎蛔蛙蛛蛞-蛟蛤蛩蛬-蛯蛸-蛹蛻蛾蜀蜂-蜃蜆蜈-蜊蜍蜑-蜒蜘蜚蜜蜥蜩蜴蜷蜻蜿蝉蝋-蝌蝎蝓蝕蝗蝙蝟-蝠蝣蝦蝨蝪蝮蝴蝶蝸蝿螂融螟螢螫螯螳螺-螻螽蟀蟄蟆-蟇蟋蟐蟒蟠蟯蟲蟶-蟷蟹蟻蟾蠅蠍-蠏蠑蠕-蠖蠡-蠣蠧蠱蠶蠹蠻血衂衄衆行-衍衒-術街衙衛衝-衞衡-衣表衫衰衲衵衷衽-衿袁-袂袈袋袍袒袖-袗袙袞袢袤被袮袰-袱袴-袵袷袿裁-装裏裔-裕裘-裙補-裝裟裡裨裲-裴裸-裹裼-裾褂褄複褊褌褐褒-褓褝-褞褥褪-褫褶褸褻襁襃-襄襌-襍襖襞-襠襤襦襪襭襯襲襴襷襾-西要覃覆-覈覊-見規覓視-覘覚覡覦-覧覩-親覬覯覲-観覺覽覿-觀角觚觜-觝解触-觧觴觸言訂-訃計訊訌討訐訓訖-記訛訝訟訣訥訪設許訳-訴訶診-証詁詆詈詐-詒詔-評詛詞詠詢-詣試詩詫-詮詰-詳詼誂誄-誅誇誉誌-認誑誓誕誘誚語誠-誡誣-誦誨説-読誰課誹誼調諂諄談請-諍諏諒論諚-諜諞諠-諢諤諦-諧諫諭-諮諱諳諷-諸諺諾謀-謂謄謇謌謎謐謔謖-謗謙-講謝謠-謡謦謨謫-謬謳謹謾譁證譌譎-譏譖識譚-譜譟警譫-譬譯-譲譴護譽讀讃變讌讎讐讒-讓讖讙-讚谷谺谿豁豆豈豊豌豎豐豕豚象-豢豪-豬豸-豺豼貂貅貉-貊貌-貎貔貘貝-貞負-貢貧-貰貲-貴貶-貸費-貽貿-賄資-賈賊賍-賎賑賓賚-賜賞賠賢-賤賦質賭賺-賽贄-贅贇-贈贊-贋贍贏-贐贓-贔贖赤赦-赧赫赭走-赱赳-赴起趁超越趙趣趨足趺趾跂跋-跌跏跖跚-跛距跟跡跣跨跪-跫路跳践跼跿踈-踊踏-踐踝-踟踪踰踴-踵蹂蹄蹇-蹊蹌蹐蹕蹙蹟-蹠蹣-蹤蹲蹴蹶蹼躁躄-躅躇躊-躋躍躑躓-躔躙躡躪-躬躯-躱躾軅-軆軈車-軍軒軛軟転-軣軫軸軻-軾較輅載-輊輌輒-輕輙輛-輝輟輦輩-輪輯輳輸-輹輻輾-輿轂轄-轆轉轌-轎轗轜轟轡-轤辛-辜辞-辟辣辧-辨辭-農辷辺-込辿迂迄-迅迎近返迚迢迥-迦迩-迫迭迯-述迴迷-迺追退-送逃逅-逆逋逍-逑逓-逗這-通逝-連逧逮週-進逵-逶逸-逹逼逾遁-遂遅遇遉-運遍-遖遘-遙遜遞遠-遡遣遥遨-適遭-遯遲遵-選遺遼-遽避-還邇邉-邊邏邑那邦邨邪邯邱邵邸郁郊郎郛郡-郢郤部郭郵郷都鄂鄒鄙鄭鄰鄲酉-酎酒酔酖酘酢-酣酥酩-酪酬酲-酳酵酷-酸醂醇醉醋醍醐醒醗醜醢醤醪-醫醯醴-醵醸醺釀-釁釆-釉釋-金釖釘釛-針釟釡釣釦-釧釵-釶釼釿鈍-鈎鈑鈔-鈕鈞鈩鈬鈴鈷鈿鉄-鉅鉈-鉉鉋鉐鉗鉚-鉛鉞鉢鉤鉦鉱鉾銀銃銅銑銓銕-銖銘銚-銜銭銷銹鋏鋒鋤鋩-鋪鋭鋲-鋳鋸鋺鋼錆錏-錐錘-錚錠錢-錣錦錨錫-錬錮-錯録錵錺-錻鍄鍋鍍鍔鍖鍛-鍜鍠鍬鍮鍵鍼鍾鎌鎔鎖-鎗鎚鎧鎬-鎮鎰鎹鏃鏈鏐-鏑鏖-鏘鏝鏡鏤-鏥鏨鐃鐇鐐鐓-鐔鐘-鐚鐡鐫鐵-鐶鐸鐺鑁鑄鑑-鑓鑚-鑛鑞鑠鑢鑪鑰鑵鑷鑼-鑿钁長門閂-閃閇閉-開閏閑間-閔閖閘-閙閠関-閥閧-閨閭閲閹閻-閼閾闃闇闊闌-闍闔-闖闘關闡-闢闥阜阡阨阪阮-阯防阻阿-陀陂附陋-降陏-限陛-陟院-陦陪陬陰陲-陳陵-陸険陽隅-隆隈隊-隋隍-随隔-隕隗-隙際-障隠隣隧-隨險隰-隲隴隶-隹隻-隼雀-雁雄-雇雉雋-雎雑雕-雖雙雛-雜離-難雨雪-雫雰雲零-雷雹電需霄霆-霈霊霍-霏霑霓霖霙霜霞霤霧霪霰露霸-霹霽-霾靂靄靆靈-靉青靖静靜非靠-面靤靦靨-革靫靭靱靴靹-靺靼鞁鞄-鞆鞋鞍鞏-鞐鞘鞜鞠鞣鞦鞨鞫鞭鞳-鞴韃韆韈韋韓韜韭-韮韲-音韵-韶韻響頁-頃項-順須頌頏-頓頗-領頚頡頤頬-頭頴頷-頸頻-頽顆顋-顏顔-顕願顛類顧顫顯-顱顳-顴風颪颯颱颶飃-飄飆飛-飜食飢飩飫飭-飯飲飴飼-飾餃餅餉-養餌餐餒-餔餘餝-餞餠-餡餤館餬餮餽-餾饂饅饉饋-饌饐-饒饕饗首-香馥馨馬-馮馳-馴馼駁駄-駆駈駐-駒駕駘駛駝駟駢駭-駮駱-駲駸駻駿騁騅騎-騏騒-験騙騨騫騰騷騾驀驂-驃驅驍驕驗驚-驛驟驢驤-驥驩-驫骨骭骰骸骼髀髄髏髑髓-體高髞-髟髢-髣髦髪-髫髭-髯髱髴髷髻鬆鬘鬚鬟鬢-鬣鬥鬧-鬪鬮-鬯鬱-鬲鬻-鬼魁-魅魍-魏魑魔魘魚魯魴鮃鮎鮑-鮓鮖-鮗鮟-鮠鮨鮪-鮫鮭-鮮鮴鮹鯀鯆鯉-鯊鯏鯑-鯒鯔鯖鯛鯡-鯤鯨鯰-鯲鯵鰄鰆鰈-鰊鰌-鰍鰐鰒-鰕鰛鰡鰤-鰥鰭-鰰鰲鰹-鰻鰾鱆-鱈鱒鱗鱚鱠鱧鱶鱸鳥鳧鳩鳫-鳬鳰鳳-鳴鳶鴃鴆-鴉鴎鴒鴕鴛鴟鴣鴦鴨鴪-鴬鴻鴾-鴿鵁鵄鵆鵈鵐-鵑鵙鵜-鵞鵠-鵡鵤鵬鵯鵲鵺鶇鶉鶏鶚鶤鶩鶫鶯鶲鶴鶸鶺-鶻鷁-鷂鷄鷆鷏鷓鷙鷦鷭鷯鷲鷸-鷺鷽鸚-鸛鸞鹵鹸-鹹鹽鹿麁麈麋-麌麑-麓麕麗麝麟麥-麦麩-麪麭麸-麼麾-麿黄黌-黐黒黔默-黙黛-點黠黥黨黯黴黶-黷黹黻-黽鼇-鼈鼎鼓鼕鼠-鼡鼬鼻鼾齊-齋齎-齏齒齔齟-齣齦-齧齪齬齲齶-齷龍龕龜-龝龠])[\u0080-\u009F{pL}]".format(pIsBasicLatin=IsBasicLatin, pL=L, pIsCJKSymbolsandPunctuation=IsCJKSymbolsandPunctuation, pIsHalfwidthandFullwidthForms=IsHalfwidthandFullwidthForms, pIsHiragana=IsHiragana, pIsKatakana=IsKatakana, pIsKatakanaPhoneticExtensions=IsKatakanaPhoneticExtensions))
rxJACorrupt = re.compile(ur"(?i)\?{{4,}}|(?:¡°|¡±|¡­|â€.|¡Ü|¡£|¡¦|¡×|¡¯)|\\'u?[0-9a-f]+|(?![{pIsBasicLatin}{pIsCJKSymbolsandPunctuation}{pIsHalfwidthandFullwidthForms}{pIsHiragana}{pIsKatakana}{pIsKatakanaPhoneticExtensions}一-丁七万-下不-与丐-丑且-丙丞両並个中丱-串丶丸-丹主-丼丿乂-乃久之乍-乏乕-乙九-也乢乱乳乾亀亂亅-了予-二于云-互五-井亘-亙些-亜亞-亢交-亦亨享-亮亰亳亶人什-仂仄仆-仇今-介仍-仏仔-仙仝-仟代-以仭-仮仰仲件-价任企伉-伊伍-休会伜-伝伯-估伴伶伸伺似-伽佃但-佇位-佑体何佗余-佞佩佯-佰佳併-佶佻-佼使侃來侈例侍侏侑侖侘供依侠-価侫侭-侯侵-侶便係-俄俊俎俐-俑俔俗-俘俚-俛保俟信俣-俥修-俯俳俵-俶俸俺俾倅-倆倉個倍倏們-倒倔倖候-倚借倡倣-倦倨-倭倶倹偃假-偉偏-偐偕-偖做停健偬偲側-偶偸偽傀傅傍傑傘-傚催-傭傲-債傷傾僂僅僉-僊働像僑僕-僖僚僞僣僥僧僭-僮僵價僻儀-儂億儉儒儔-儖儘儚償儡優儲儷儺-儼儿-允元-光克-兎児兒兔党兜兢入全-兮共兵-典兼冀冂内-円冉-冊册-再冏-冓冕-冗写冠冢冤-冦冨-冬冰-冷冽凄-准凉凋-凍凖凛-凝几-凡処-凧凩-凪凭凰-凱凵-凶凸-出函-凾刀刃-刄分-刈刊-刋刎刑刔列初判-別刧利-刪刮到刳制-刻剃-剄則削-前剏剔剖剛剞剣-剥剩-剪副-創剽剿劃劇-劉劍劑-劒劔力功-加劣助-劭励労-劵効劼劾勁勃勅勇勉勍勒動勗-務勝-勠勢-勤勦-勧勲-勳勵勸-勺勾-勿匁-匂包-匆匈匍匏-匐匕-北匙-匚匝匠-匡匣匪匯匱匳匸-医匿-十千卅-半卍卑-協南-単博卜卞占卦卩卮-危即-卵卷-卸卻卿厂厄厖厘厚原-厠厥-厦厨-厩厭-厮厰厳厶去参-參又-収叔取-受叙叛叟叡-句叨-右叶-司叺吁吃-各合-向君吝吟-吠否吩含-吮吶吸-吹吻-吾呀呂呆呈-告呎呑呟周呪呰-呱味呵-呷呻-命咀咄咆咋-和咎-咐咒咢咤-咥咨咫-咬咯咲-咳咸咼-咾哀-哂哄哇-哉哘員-哢哥-哦哨-哩哭-哮哲哺哽唄唆-唇唏-唐唔唖售-唯唱唳唸-唹唾啀啄-商啌問啓啖-啗啜-啝啣啻-啼啾喀喃-善喇喉-喋喘-喚喜-喟喧-喬單喰営嗄-嗅嗇嗔嗚嗜嗟嗣-嗤嗷嗹嗽-嗾嘆嘉嘔嘖-嘘嘛嘩嘯嘱-嘲嘴嘶嘸噂噌噎噐噛噤器噪-噬噴噸噺嚀嚆-嚇嚊嚏嚔嚠嚢嚥嚮嚴嚶嚼囀-囃囈囎囑囓囗-囘囚-四回因団囮困囲-図囹-固国囿-圀圃-圄圈-圉國圍圏園-圓圖團圜土圦-在圭地圷-圸圻址坂均坊坎-坑坡坤坦坩-坪坿垂垈-垉型垓垠垢-垤垪垰垳埀埃埆埋城埒-埔埖埜域-埠埣埴執培-基埼堀堂堅-堆堊-堋堕堙堝堡堤堪堯-報場-堵堺堽塀-塁塊-塋塑-塒塔塗-塚塞塢塩填塰塲塵塹塾境墅墓増墜墟墨墫墮墳墸-墻墾壁壅壇壊壌壑壓壕壗-壙壜壞-壟壤-壥士-壬壮-売壷壹-壽夂変-夊夏-夐夕-外夘-夜夢夥大天-央失-夲夷-夸夾奄奇-奉奎-契奔-奕套-奘奚奠奢奥奧-奪奬奮女-奴奸好妁-妄妊妍妓妖妙妛妝妣妥妨妬妲妹妻妾姆姉始姐-姑姓-委姙-姚姜姥-姦姨姪-姫姶姻姿威娃娉娑娘娚娜娟-娠娥娩娯娵-娶娼婀-婁婆婉婚婢婦婪婬婿媒媚-媛媼-媾嫁-嫂嫉嫋-嫌嫐嫖-嫗嫡嫣嫦嫩嫺-嫻嬉嬋-嬌嬖嬢嬪嬬嬰嬲嬶嬾孀孃孅子-孑孔-孕字-存孚-孝孟季-学孩孫孰-孱孳孵學孺宀它宅宇-安宋-宍宏宕宗-宝実客-宦宮宰害-家宸-容宿寂-寇寉富寐寒-寔寛寝-察寡-寢寤-審寫寮寰寳寵-寶寸寺対-寿封-専射-尋對-小少尓尖尚尠尢尤尨尭就尸-屁居-屆屈届-屋屍-屑屓展属屠-屡層-履屬屮-屯山屶屹岌岐-岑岔岡岨-岩岫-岬岱岳岶-岸岻-岼岾峅峇峙峠-峡峨-峪峭峯-峰島峺-峻峽崇崋崎崑崔-崛崟崢崩嵋-嵌嵎嵐嵒嵜嵩嵬嵯嵳嵶嶂嶄嶇嶋-嶌嶐嶝嶢嶬嶮嶷嶺嶼-嶽巉巌-巍巒-巓巖巛川-州巡巣工-巨巫差己-巵巷巻巽-巾市-布帆帋-希帑帖帙-帛帝帥師席帯-帰帳帶-常帽幀幃-幅幇幌幎幔-幕幗幟幡-幤干-并幸-广庁広-庄庇床序底-店庚府庠度-座庫庭庵-庸廁-廃廈-廊廏-廐廓廖廚-廛廝廟-廣廨-廩廬廰-廱廳-廴延-廸建-廼廾-廿弁弃-弄弉-弍式-弑弓-弘弛弟弥-弧弩弭弯弱張強-弸弼弾彁彈彊彌彎彑当彖-彗彙彜-彝彡-形彦彩-彭彰-影彳彷役彼彿-待徇-很徊-後徐-従得-徙從徠-御徨-循徭-微徳-徴徹徼-徽心必忌-忍忖-忙応-忝忠忤快忰-忱念忸忻忽忿怎-怐怒怕-怖怙怛-思怠-怡急-怫怯怱怺恁-恃恆恊-恋恍恐恒恕恙-恚恟-恠恢-恥恨-恭息-恰恵恷悁悃-悄悉悋-悍悒悔悖-悗悚-悛悟-悠患悦-悧悩-悪悲-悶悸悼-悽情-惇惑惓惘惚惜惟-惡惣惧-惨惰-惱想-惴惶-惷惹-惻愀-愁愃愆愈-愉愍-意愕愚-愛感愡愧-愨愬愴愼-愿慂慄慇-慈慊-慎慓慕慘-慚慝慟慢-慣慥慧-慨慫慮-慱慳-慷慾憂憇憊憎憐-憑憔憖憙-憚憤憧憩憫-憬憮憲憶憺憾懃懆-懍懐懣懦懲懴懶-懸懺懼-戀戈-戊戌-戎成-戒戔或戚-戛戝-戟戡戦截戮-戰戲-戴戸戻房-扁扇-扉手才-扎打払托扛扞扠扣扨扮扱扶批扼找-技抂-抄抉-把抑-折抛-抜択披-抬抱抵抹抻-抽拂担-拊拌-拍拏-拔拗-拙招-拝拠-拡括-拯拱拳拵-拷拾-拿持-挂指-按挌挑挙挟挧-挨挫振挺挽-挿捉捌-捍捏-捐捕捗捜捧-捩捫据捲捶-捷捺-捻掀掃授-掉掌掎-掏排掖掘掛掟-掣接控-掬掲掴-掵掻掾揀揃-揄揆揉描-提插揖揚-換握揣揩揮援揶揺搆損搏搓搖-搗搜搦搨搬-搭搴搶携搾摂摎摘摧摩摯摶摸摺撃撈撒-撓撕撚撞撤-撥撩撫播-撮撰撲撹撻-撼擁-擂擅擇操擒擔擘據擠-擣擦-擧擬擯擱-擲擴擶擺擽-擾攀攅攘攜-攝攣-攤攪-攬支攴-改攻放-政故效敍敏救敕-教敝-敞敢-散敦敬数敲整-敵敷-數斂-斃文-斉斌斎斐-斑斗料斛-斜斟斡斤-斥斧斫-断斯-新斷方於-施旁旃-旆旋-旌族旒旗旙旛无-既日-早旬-旭旱旺-旻昂-昃昆-昇昊昌明-昏易-昔昜星-映春昧-昨昭是昴-昶昼昿晁-晄晉晋晏晒晝-晟晢晤晦-晩普-晰晴晶智暁暃-暄暇-暉暎暑暖-暘暝暢暦暫暮暴暸-暹暼暾曁曄曇曉曖曙-曚曜-曝曠曦曩曰曲-曵曷-曹曼-最會月-有朋服朏朔-朗望朝-期朦-木未-朮朱朴朶-朸机朽朿杁杆杉李-村杓杖杙杜杞-来杪杭杯-杳杵杷杼松-板枅枇枉枋-枌析枕林枚果-枝枠-枢枦枩枯枳-枴架-枹柁柄柆柊柎-柑染-柔柘柚柝-柞柢柤柧柩柬柮-柯柱柳-柵査柾-柿栂-栄栓栖-栗栞校-栢栩-栫栲栴核-根格-栽桀-桃框案桍-桎桐-桑桓-桔桙桜-桝桟档桧桴桶-桷桾-桿梁梃梅梍梏梓-梔梗梛條梟-梠梢梦-梨梭梯-梱梳梵-梶梹-梺梼棄棆棉-棋棍棒棔-棕棗-棘棚棟-棡棣棧森-棯棲棹-棺椀-椁椄-椅椈椋-椏椒椙-検椡-椣椥-椦椨椪椰椴椶椹椽椿楊楓-楕楙-楚楜-楞楠-楢楪-楫業-楯楳-極楷-楹楼-楾榁-概榊榎榑榔-榕榛-榜榠榧榮榱-榲榴榻榾-榿槁槃槇槊-槎槐槓様-槙槝-槞槧-槨槫槭槲槹槻槽槿樂樅樊-樌樒-樔樗標樛樞-樟模-樣権-樫樮樵-樶樸-樺樽橄橇-橈橋橘-橙機橡-橢橦橲橸橿-檀檄檍-檎檐檗檜檠檢-檣檪檬檮檳檸檻櫁-櫃櫑櫓櫚-櫛櫞-櫟櫨櫪櫺-櫻欄-欅權欒欖欝欟-次欣欧欲欷-欺欽-款歃歇歉歌歎歐歓-歔歙歛歟歡-此武歩-歪歯歳-歴歸-歹死歿-殀殃-殄殆殉-残殍殕-殖殘殞殤殪-殫殯殱-段殷殺-殼殿-毀毅-毆毋母-毎毒-比毘毛毟毫-毬毯毳氈氏民氓-气気氛氣-氤水氷-永氾汀-求汎汐汕汗汚汝-池汢汨汪汰汲-汳決汽-汾沁-沃沈沌-沍沐沒-沓沖沙-沛没-沢沫沮沱河沸-沿況泄-泅泉-泊泌泓法泗泙泛泝泡-泣泥注泪泯-泱泳洋-洌洒洗洙洛洞-洟津洩-洫洲-洳洵-洶洸活洽-派流浄-浅浙-浚浜浣-浤浦浩-浪浬浮浴海-浹涅消涌涎涓涕涙涛-涜涯液涵涸涼淀淅-淇淋-淌淑-淒淕淘-淙淞淡淤淦淨淪-淬淮深淳淵混淹-添清渇-渋渓渕渙-減渝渟-渡渣-渦温渫-港游渺渾湃湊湍-湎湖湘湛湟湧湫湮-湯湲湶湾-満溂溌溏-源準溘溜-溝溟溢溥溪溯溲溶-溷溺溽滂滄-滅滉滋-滌滑滓-滕滝-滞滬滯滲滴滷-滸滾-滿漁-漂漆漉漏漑漓-漕漠漢-漣漫-漬漱-漲漸漾-漿潁潅潔潘潛-潜潟潤潦潭-潰潴潸潺潼澀-澂澄澆澎澑澗澡澣-澤澪澱澳澹激-濃濆濔-濕濘濛濟-濡濤濫-濬濮-濯濱濳濶濺濾瀁瀉瀋瀏瀑瀕瀘瀚-瀛瀝-瀟瀦-瀧瀬瀰瀲瀾灌灑灘灣火灯-灰灸灼-災炉-炊炎炒炙炬-炯炳炸-為烈烋烏烙烝烟烱烹烽焉焔焙-焚焜無焦然焼煉煌煎煕-煖煙煢煤-照煩煬煮煽熄熈熊熏熔-熕熙熟熨熬熱熹熾燃燈-燉燎燐燒燔-燕燗營-燠燥-燧燬-燮燵燹燻-燼燿爆爍爐爛爨爪爬-爭爰爲爵-父爺-牀牆-版牋-牌牒牘-牙牛牝牟牡-牢牧物牲牴特牽-牾犀-犂犇犒犖犠犢犧犬犯犲状犹狂-狄狆狎狐狒狗狙狛狠-狢狩独-狭狷-狹狼-狽猊猖-猗猛-猝猟猥猩-猫献-猯猴猶-猷猾-猿獄-獅獎-獏獗獣獨獪獰獲獵獸獺-獻玄率玉王玖玩玲-玳玻珀珂珈珊珍-珎珞珠珥珪班-珮珱珸現球琅-理琉琢琥琲-琶琺琿瑁瑕瑙-瑜瑞-瑠瑣-瑤瑩-瑪瑯-瑰瑳瑶瑾璃璋璞璢璧環璽瓊瓏瓔瓜瓠瓢-瓣瓦-瓧瓩瓮瓰-瓲瓶-瓸甃-甅甌-甎甑甓甕甘甚甜甞-生産甥-甦用甫-甬田-申男-甸町-甼畄畆畉-畍畏畑畔留-畝畠畢畤-畧畩-畫畭異畳-畴當-畸畿疂疆-疇疉-疋疎-疏疑疔疚疝疣疥疫疱-疳疵疸-疹疼-疾痂-痃病症痊痍痒痔-痕痘-痙痛痞痢-痣痩痰痲-痴痺痼痾-痿瘁瘉瘋瘍瘟-瘢瘤瘧瘰瘴瘻療癆-癈癌癒癖癘癜癡-癢癧-癪癬癰癲癶癸発-百皀皃-的皆-皈皋皎皐皓皖皙-皚皮皰皴皷-皺皿盂-盃盆盈益盍盒盖-盗盛-盜盞-盟盡監-盥盧盪目盲直相盻盾省眄眇-眉看-県眛眞-眠眤-眦眩眷-眸眺眼着睇睚-睛睡督睥-睦睨睫睹睾-睿瞋瞎瞑瞞瞠瞥瞬-瞭瞰瞳瞶瞹瞻-瞽瞿矇矍矗矚-矜矢-矣知矧矩短-矯石矼砂砌砒研-砕砠砥-砧砲破砺砿硅硝硫-硬硯硲硴硼碁碆-碇碌-碎碑碓碕碗碚碣碧碩-碪碯碵確碼碾磁磅-磆磊-磋磐-磑磔磚磧-磨磬磯磴磽礁礇礎礑-礒礙礦礪-礬示礼社祀-祁祇-祉祐祓祕-祗祚祝-祠祢祥票祭祷祺祿-禁禄-禅禊禍-福禝禦-禧禪禮禰禳禹-禺禽-私秉秋科-秒秕秘租秡秣-秤秦-秧秩秬称移稀稈程稍-税稔稗-稚稜稟-稠種稱-稲稷稻-穀穂-穃穆穉積-穐穗穡-穣穩穫穰穴究穹-空穽穿突窃-窄窈窒-窓窕-窘窟窩-窪窮-窰窶窺窿竃-竅竇-竈竊-立竍竏竒-竓竕站-竚竜-竝竟-竣童-竦竪竭端-竰競竸-竺竿笂笄笆笈笊-笋笏笑笘-笙笛笞笠笥-符笨第笳笵-笶笹筅-筆筈-等筋-筍筏-筒答策筝筥筧筬筮筰-筱筴-筵筺箆-箇箋箍箏箒箔-箕算-箚箜-箝箟管箪箭箱箴箸節-篁範篆-篇築篋-篌篏篝篠篤-篦篩篭篳篶-篷簀簇簍簑-簔簗簟簡簣簧簪-簫簷-簸簽-籀籃籌-籍籏-籐籔籖籘籟-籠籤-籥籬米籵籾粁-粃粉粋粍粐粒粕粗-粘粛粟粡-粢粤-粥粧-粨粫粭-粮粱-粳粹粽-精糀糂糅糊糎糒糖糘糜糞-糠糢糧糯糲糴糶糸糺-系糾紀紂約-紆紊-紋納紐純-紕紗-紜素-索紫-紬紮-細紲-紳紵紹-紺紿終-絆絋-経絎-結絖絛絞絡-絣給絨絮統-絳絵-絶絹絽綉綏經継-綜綟綢-綣綫-網綴-綵綸綺-綻綽-綿緇緊-緋総緑-緒緕緘線緜-緞締-緡緤編-緩緬緯緲練緻縁縄-縅縉-縋縒縛縞-縟縡-縣縦縫縮縱-縲縵縷縹-縻總-績繁繃繆繊-繋繍織-繖繙-繚繝-繞繦-繧繩-繪繭繰繹繻-繽繿纂-纃纈-纉續纎-纐纒-纔纖纛-纜缶缸缺罅罌-罎罐-网罔-罕罘罟-罠罧-罫置罰署罵罷-罹羂-羃羅-羈羊羌美羔羚羝-羞羣-群羨-義羮-羯羲羶羸-羹羽翁翅-翆翊翌習翔-翕翠-翡翦翩翫翰翳翹翻-翼耀-老考-耆耋-而耐耒耕耗-耙耜耡耨耳耶耻耽耿聆聊聒聖聘聚聞-聟聡-聢聨聯-聰聲-聴聶-職聹聽-聿肄-肇肉肋-肌肓肖肘肚-肛肝股-肢肥肩-肪肬-肭肯肱-育肴肺胃-胄胆背胎胖胙-胛胝-胞胡胤-胥胯胱胴胸胼-能脂脅-脊脚-脛脣脩脯脱脳脹脾腆腋腎腐-腑腓-腕腟腥-腦腫腮腰-腱腴腸-腺腿-膀膂-膃膈膊膏膓膕膚膜-膝膠膣-膤膨-膩膰膳膵膸膺膽-臀臂臆臈-臉臍臑臓臘-臚臟-臠臣臥臧-臨自臭至-致臺-臼臾舁-舂舅與-舊舌-舎舐舒舖-舘舛-舜舞-舟舩-般舮舳舵-船艀艇艘-艚艝艟艢艤艦艨艪-艫艮-良艱-色艶-艸艾芋芍芒芙芝芟芥-芦芫-芭芯花芳芸-芹芻芽苅苑-苔苗苙苛-苜苞-苟苡苣若-苧苫英苳-苴苹-苻茂-茆茉茎茖-茘茜茣茨茫茯茱-茲茴-茶茸-茹荀荅草-荊荏-荐荒荘荳荵荷荻-荼莅莇莉-莊莎莓莖莚莞-莠莢莨莪-莫莱莵莽菁菅菊菌菎菓菖菘菜菟-菠菩菫華-菲菴菷菻菽萃-萄萇萋-萎萓萠萢萩-萪萬萱萵萸萼-落葆葉葎著葛葡-董葦葩葫-葯葱葵葷葹-葺蒂蒄蒋蒐蒔蒙蒜蒟蒡蒭蒲蒸-蒹蒻-蒼蒿蓁蓄蓆蓉-蓋蓍蓐-蓑蓖蓙-蓚蓬蓮蓴蓼蓿-蔀蔆蔑蔓-蔕蔗-蔘蔚蔟蔡蔦蔬-蔭蔵蔽蕀-蕁蕃蕈-蕋蕎蕕蕗-蕘蕚蕣蕨-蕪蕭蕷蕾薀薄薇-薈薊薐-薑薔薗薙薛-薜薤薦薨-薬薮-薯薹-薺藁藉藍藏-藐藕藜-藝藤-藥藩-藪藷藹-藻藾蘂蘆-蘇蘊-蘋蘓蘖-蘗蘚蘢蘭蘯-蘰蘿虍-虎虐虔-處虚虜虞-號虧虫虱虹虻蚊-蚌蚓蚕蚣-蚤蚩-蚫蚯-蚰蚶蛄蛆-蛇蛉蛋蛍-蛎蛔蛙蛛蛞-蛟蛤蛩蛬-蛯蛸-蛹蛻蛾蜀蜂-蜃蜆蜈-蜊蜍蜑-蜒蜘蜚蜜蜥蜩蜴蜷蜻蜿蝉蝋-蝌蝎蝓蝕蝗蝙蝟-蝠蝣蝦蝨蝪蝮蝴蝶蝸蝿螂融螟螢螫螯螳螺-螻螽蟀蟄蟆-蟇蟋蟐蟒蟠蟯蟲蟶-蟷蟹蟻蟾蠅蠍-蠏蠑蠕-蠖蠡-蠣蠧蠱蠶蠹蠻血衂衄衆行-衍衒-術街衙衛衝-衞衡-衣表衫衰衲衵衷衽-衿袁-袂袈袋袍袒袖-袗袙袞袢袤被袮袰-袱袴-袵袷袿裁-装裏裔-裕裘-裙補-裝裟裡裨裲-裴裸-裹裼-裾褂褄複褊褌褐褒-褓褝-褞褥褪-褫褶褸褻襁襃-襄襌-襍襖襞-襠襤襦襪襭襯襲襴襷襾-西要覃覆-覈覊-見規覓視-覘覚覡覦-覧覩-親覬覯覲-観覺覽覿-觀角觚觜-觝解触-觧觴觸言訂-訃計訊訌討訐訓訖-記訛訝訟訣訥訪設許訳-訴訶診-証詁詆詈詐-詒詔-評詛詞詠詢-詣試詩詫-詮詰-詳詼誂誄-誅誇誉誌-認誑誓誕誘誚語誠-誡誣-誦誨説-読誰課誹誼調諂諄談請-諍諏諒論諚-諜諞諠-諢諤諦-諧諫諭-諮諱諳諷-諸諺諾謀-謂謄謇謌謎謐謔謖-謗謙-講謝謠-謡謦謨謫-謬謳謹謾譁證譌譎-譏譖識譚-譜譟警譫-譬譯-譲譴護譽讀讃變讌讎讐讒-讓讖讙-讚谷谺谿豁豆豈豊豌豎豐豕豚象-豢豪-豬豸-豺豼貂貅貉-貊貌-貎貔貘貝-貞負-貢貧-貰貲-貴貶-貸費-貽貿-賄資-賈賊賍-賎賑賓賚-賜賞賠賢-賤賦質賭賺-賽贄-贅贇-贈贊-贋贍贏-贐贓-贔贖赤赦-赧赫赭走-赱赳-赴起趁超越趙趣趨足趺趾跂跋-跌跏跖跚-跛距跟跡跣跨跪-跫路跳践跼跿踈-踊踏-踐踝-踟踪踰踴-踵蹂蹄蹇-蹊蹌蹐蹕蹙蹟-蹠蹣-蹤蹲蹴蹶蹼躁躄-躅躇躊-躋躍躑躓-躔躙躡躪-躬躯-躱躾軅-軆軈車-軍軒軛軟転-軣軫軸軻-軾較輅載-輊輌輒-輕輙輛-輝輟輦輩-輪輯輳輸-輹輻輾-輿轂轄-轆轉轌-轎轗轜轟轡-轤辛-辜辞-辟辣辧-辨辭-農辷辺-込辿迂迄-迅迎近返迚迢迥-迦迩-迫迭迯-述迴迷-迺追退-送逃逅-逆逋逍-逑逓-逗這-通逝-連逧逮週-進逵-逶逸-逹逼逾遁-遂遅遇遉-運遍-遖遘-遙遜遞遠-遡遣遥遨-適遭-遯遲遵-選遺遼-遽避-還邇邉-邊邏邑那邦邨邪邯邱邵邸郁郊郎郛郡-郢郤部郭郵郷都鄂鄒鄙鄭鄰鄲酉-酎酒酔酖酘酢-酣酥酩-酪酬酲-酳酵酷-酸醂醇醉醋醍醐醒醗醜醢醤醪-醫醯醴-醵醸醺釀-釁釆-釉釋-金釖釘釛-針釟釡釣釦-釧釵-釶釼釿鈍-鈎鈑鈔-鈕鈞鈩鈬鈴鈷鈿鉄-鉅鉈-鉉鉋鉐鉗鉚-鉛鉞鉢鉤鉦鉱鉾銀銃銅銑銓銕-銖銘銚-銜銭銷銹鋏鋒鋤鋩-鋪鋭鋲-鋳鋸鋺鋼錆錏-錐錘-錚錠錢-錣錦錨錫-錬錮-錯録錵錺-錻鍄鍋鍍鍔鍖鍛-鍜鍠鍬鍮鍵鍼鍾鎌鎔鎖-鎗鎚鎧鎬-鎮鎰鎹鏃鏈鏐-鏑鏖-鏘鏝鏡鏤-鏥鏨鐃鐇鐐鐓-鐔鐘-鐚鐡鐫鐵-鐶鐸鐺鑁鑄鑑-鑓鑚-鑛鑞鑠鑢鑪鑰鑵鑷鑼-鑿钁長門閂-閃閇閉-開閏閑間-閔閖閘-閙閠関-閥閧-閨閭閲閹閻-閼閾闃闇闊闌-闍闔-闖闘關闡-闢闥阜阡阨阪阮-阯防阻阿-陀陂附陋-降陏-限陛-陟院-陦陪陬陰陲-陳陵-陸険陽隅-隆隈隊-隋隍-随隔-隕隗-隙際-障隠隣隧-隨險隰-隲隴隶-隹隻-隼雀-雁雄-雇雉雋-雎雑雕-雖雙雛-雜離-難雨雪-雫雰雲零-雷雹電需霄霆-霈霊霍-霏霑霓霖霙霜霞霤霧霪霰露霸-霹霽-霾靂靄靆靈-靉青靖静靜非靠-面靤靦靨-革靫靭靱靴靹-靺靼鞁鞄-鞆鞋鞍鞏-鞐鞘鞜鞠鞣鞦鞨鞫鞭鞳-鞴韃韆韈韋韓韜韭-韮韲-音韵-韶韻響頁-頃項-順須頌頏-頓頗-領頚頡頤頬-頭頴頷-頸頻-頽顆顋-顏顔-顕願顛類顧顫顯-顱顳-顴風颪颯颱颶飃-飄飆飛-飜食飢飩飫飭-飯飲飴飼-飾餃餅餉-養餌餐餒-餔餘餝-餞餠-餡餤館餬餮餽-餾饂饅饉饋-饌饐-饒饕饗首-香馥馨馬-馮馳-馴馼駁駄-駆駈駐-駒駕駘駛駝駟駢駭-駮駱-駲駸駻駿騁騅騎-騏騒-験騙騨騫騰騷騾驀驂-驃驅驍驕驗驚-驛驟驢驤-驥驩-驫骨骭骰骸骼髀髄髏髑髓-體高髞-髟髢-髣髦髪-髫髭-髯髱髴髷髻鬆鬘鬚鬟鬢-鬣鬥鬧-鬪鬮-鬯鬱-鬲鬻-鬼魁-魅魍-魏魑魔魘魚魯魴鮃鮎鮑-鮓鮖-鮗鮟-鮠鮨鮪-鮫鮭-鮮鮴鮹鯀鯆鯉-鯊鯏鯑-鯒鯔鯖鯛鯡-鯤鯨鯰-鯲鯵鰄鰆鰈-鰊鰌-鰍鰐鰒-鰕鰛鰡鰤-鰥鰭-鰰鰲鰹-鰻鰾鱆-鱈鱒鱗鱚鱠鱧鱶鱸鳥鳧鳩鳫-鳬鳰鳳-鳴鳶鴃鴆-鴉鴎鴒鴕鴛鴟鴣鴦鴨鴪-鴬鴻鴾-鴿鵁鵄鵆鵈鵐-鵑鵙鵜-鵞鵠-鵡鵤鵬鵯鵲鵺鶇鶉鶏鶚鶤鶩鶫鶯鶲鶴鶸鶺-鶻鷁-鷂鷄鷆鷏鷓鷙鷦鷭鷯鷲鷸-鷺鷽鸚-鸛鸞鹵鹸-鹹鹽鹿麁麈麋-麌麑-麓麕麗麝麟麥-麦麩-麪麭麸-麼麾-麿黄黌-黐黒黔默-黙黛-點黠黥黨黯黴黶-黷黹黻-黽鼇-鼈鼎鼓鼕鼠-鼡鼬鼻鼾齊-齋齎-齏齒齔齟-齣齦-齧齪齬齲齶-齷龍龕龜-龝龠])[\u0080-\u009F{pL}]".format(pIsBasicLatin=IsBasicLatin, pL=L, pIsCJKSymbolsandPunctuation=IsCJKSymbolsandPunctuation, pIsHalfwidthandFullwidthForms=IsHalfwidthandFullwidthForms, pIsHiragana=IsHiragana, pIsKatakana=IsKatakana, pIsKatakanaPhoneticExtensions=IsKatakanaPhoneticExtensions))

# ======= FROM DEDUPE SCRIPT
tbl = dict.fromkeys(i for i in xrange(sys.maxunicode) if unicodedata.category(unichr(i)).startswith('P'))
rx_is_segment_blank = re.compile(r'^\s*$', re.U)
rx_invalid_xml_chars = re.compile(r'(?![\r\n\t])[\x00-\x1F]')
rx_numeric = re.compile(r'^\d+$', re.U)
rx_email = re.compile(r'^\s*\S+@\S+\.\S+\s*$', re.U)
rx_email_partial = re.compile(r'[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+')
rx_url_encoded = re.compile(r'^\s*(?:%[0-9A-Fa-f]{2})+\s*$', re.U)
rx_no_letter = re.compile(r'^(?!.*[^\W\d_])', re.U)
rx_url = re.compile(r'^\s*(?:https?|f(?:tp|ile)|gopher|telnet|notes|ms-help):(?://|\\\\)+[\w:#@%/;$()~_?+\-=\\.\x26]*\s*$', re.I | re.U)
rx_url_partial = re.compile(r'(?:https?|f(?:tp|ile)|gopher|telnet|notes|ms-help):(?://|\\\\)+[\w:#@%/;$()~_?+\-=\\.\x26]*', re.I | re.U)
rx_html_entities = re.compile(r'^\s*(?:&#\d+;|&[a-zA-Z\d]+;)+(?:\s+(?:&#\d+;|&[a-zA-Z\d]+;)+)*\s*$', re.U)
rx_too_long = re.compile(r'^\W*\w+(?:\W+\w+){99,}\W*$', re.U) # Equal or more than 100 words segments are filtered out (Edit: 2-Apr-2019)
rx_alphanumeric = re.compile(r'^(?=\D*\d)(?=[\W\d_]*[^\W\d_])\s*[^\W_]+\s*$', re.U) # DO NOT USE FOR APAC!!!
# Combine all except rx_alphanumeric.pattern
rx_irrelevant = re.compile("|".join([rx_is_segment_blank.pattern, rx_invalid_xml_chars.pattern, rx_numeric.pattern, rx_email.pattern, rx_url_encoded.pattern, rx_no_letter.pattern, rx_url.pattern, rx_html_entities.pattern, rx_too_long.pattern]), re.I | re.U | re.S)

def remove_punctuation(text):
	return text.translate(tbl)

def tokenize(seg, mode): # TESTED AT https://ideone.com/SzJLXH
	tokenized = seg.strip()
	if mode == "0": # Fully tokenized punctuation, spaces, case
		tokenized = re.sub(ur"(?u)\s+", u"", remove_punctuation(seg.lower()) ) #nooooooooooooo
	elif mode == "1": # Clean case sensitive (whitespace insensitive)
		tokenized = re.sub(ur"(?u)\s+", u"", seg)
	elif mode == "2" : # Clean case/whitespace insensitive (best with case_feature)
		tokenized = re.sub(ur"(?u)\s+", u"", seg.lower())
	else: # no tokenization (for now, same as 1 (clean case sensitive)
		tokenized = re.sub(ur"(?u)\s+", u"", seg) #nooooooooooo
	hash = hashlib.md5(tokenized.encode('utf-8'))
	return hash.hexdigest()

def is_irrelevant(src_seg, tgt_seg, lang): # TESTED AT https://ideone.com/WFm9T6
	#m = rx_is_segment_blank.search(src_seg) # if source or target is null or whitespace	 #if not m:		 m = rx_is_segment_blank.search(tgt_seg) if m:		  return true
	m = rx_irrelevant.search(src_seg)
	n = rx_irrelevant.search(tgt_seg)
	return m or n
#==============================

possessive_entity = r"&'26;#39;s\b"
html_tags = r"<\s*/\s*[a-zA-Z]\w*\s*>|<\s*(?:(?:a\s*)?href|font|b)\b[^<>\n\r]*(?:>|$)|\b</(?!\S)"
rx_tags_to_protect = re.compile(r"\B(?:&t[A-Z];)+\B", re.U)
rx_wf_ph = re.compile(r"(?:&t[A-Z];)+")
rx_wf_char_ref = re.compile(r"(?i)(?:&(['#])|#)([0-9a-f]{2});|&[a-z]\w*;")
rx_tags = re.compile(ur'(?s)&lt;([a-zA-Z][\w:.-]*)(?:(?!&[lg]t;).)*&gt;(.*?)&lt;/\1&gt;')
rx_excessive_space = re.compile(r'\s+(?:</\B\s*)?', re.U)
#rx_clean = re.compile(ur"(&'([A-Z]|[0-9]{1,4});)+")
rx_trash=re.compile(r"|".join([possessive_entity,html_tags]), re.U)
# ZIP WHOLE FOLDER REC: 7z a -r /Engines/test/NewsCmnts_BPETok.7z /Engines/test/ENRU/*
def rx_wf_char_ref_repl(x):
    if x.group(2):
        if x.group(1) == "'":
            return unichr(int(x.group(2), 16))
        else:
            return unichr(int(x.group(2), 10))
    else:
        m = [i[0] for i in dc if i[1] == x.group()]
        if m:
            return unichr(int(m[0][3:-1], 16)) #print(unichr(int(m[0][3:-1], 16)).encode('utf8')) # prints pound
        else:
            return ' ' # else  x.group() to return as is

def CleanUpLikeInPerlScript(seg):
    seg = re.sub(u'[\u000B\u000C\u000D\u0085\u2028\u2029]+', u' ', seg).strip()
    seg = rx_tags.sub(ur'\2', seg)
    seg = rx_wf_ph.sub(u'', seg)
    seg=rx_wf_char_ref.sub(rx_wf_char_ref_repl, seg)
    seg = rx_trash.sub(u"", seg)
    seg = rx_excessive_space.sub(u" ", seg)
    #if (seg.startswith(r'">&#;')):
    #    seg = seg[5:]
#    seg = rx_email_partial.sub(ur'｟email：EMAIL｠', seg)
#    seg = rx_url_partial.sub(ur'｟url：URL｠', seg)
    return re.sub(r'">&#;\s*', "", seg.strip()).replace(u"'&#;", u"")

#def ProtectTags(src, tgt):#
#	ents = rx_tags_to_protect.findall(src)
#	src = rx_tags_to_protect.sub(ur'｟tag：TAG｠', src)
#	for ent in ents:
#		tgt = tgt.replace(ent, ur'｟tag：TAG｠')
#	return src, tgt

def main(argv):
		if len(argv) < 5:
			print("Five arguments are expected: input WF TM text file, source and target language codes, dedupe mode and protect tag mode. A sixth argument defines the number of segments to be processed before a progress update, and seventh is an extra filtering pattern. An eigth param is whether length and private check is necessary (for TMX converted to WF TXT TM there's no need of that.)")
			exit(-1)
		tm_file = argv[0]
		srclang=argv[1]
		tgtlang=argv[2]
		rx_src_corrupt = None
		rx_tgt_corrupt = None
		if srclang.upper().startswith('ZH'):
			rx_src_corrupt = rxZHCNCorrupt
		elif srclang.upper().startswith('JA'):
			rx_src_corrupt = rxJACorrupt
		elif srclang.upper().startswith('RU'):
			rx_src_corrupt = rxRUCorrupt
		elif srclang.upper().startswith('DE'):
			rx_src_corrupt = rxDECorrupt
		elif srclang.upper().startswith('EN'):
			rx_src_corrupt = rxENCorrupt
		if tgtlang.upper().startswith('ZH'):
			rx_tgt_corrupt = rxZHCNCorrupt
		elif tgtlang.upper().startswith('JA'):
			rx_tgt_corrupt = rxJACorrupt
		elif tgtlang.upper().startswith('RU'):
			rx_tgt_corrupt = rxRUCorrupt
		elif tgtlang.upper().startswith('DE'):
			rx_tgt_corrupt = rxDECorrupt
		elif tgtlang.upper().startswith('EN'):
			rx_tgt_corrupt = rxENCorrupt
		dedupe_mode = argv[3]
		protect_tags = argv[4]
		update_every = 10000 # Minimum amount of segments before progress update
		if len(argv) > 5:
			update_every = int(argv[5])
		rx_filter = None
		if len(argv) > 6 and len(argv[6]) > 0:
			rx_filter = re.compile(argv[6])
		check_len_and_private = True
		if len(argv) > 7:
			check_len_and_private = argv[7]
		if check_len_and_private != "1":
			check_len_and_private = False
		print('TM file is {}'.format(tm_file))
		print('Source language is {}'.format(srclang))
		print('Target language file is {}'.format(tgtlang))
		print('Dedupe mode is {}'.format(dedupe_mode))
		if rx_src_corrupt:
			print(u'Source lang corrupt rule: {}'.format(rx_src_corrupt.pattern))
		else:
			print(u'No source lang corrupt rule')
		if rx_tgt_corrupt:
			print(u'Target lang corrupt rule: {}'.format(rx_tgt_corrupt.pattern))
		else:
			print(u'No target lang corrupt rule')
		if rx_filter:
			print(u"Additional filter pattern: {}".format(rx_filter.pattern))
		else:
			print(u"No additional filter pattern used.")
		fldr = ntpath.dirname(tm_file)
		fname = ntpath.basename(tm_file)
		print('Folder: {}'.format(fldr))
		print('File name: {}'.format(fname))
		rx_private = re.compile(r'^!([0-9])\1{9}$')
		rx_timestamp=re.compile(r'^[0-9]{8}~[0-9]{6}$')
		cnt_total = 0 # Total amount of segments processed
		cnt_unique = 0 # Unique segment count
		corpus = []

		fwWrongSegments = io.open("{}/{}.wrong.log".format(fldr, fname),'w',encoding='utf-8',newline='\n')
		fwPrivate=io.open("{}/{}.private.log".format(fldr, fname),'w',encoding='utf-8',newline='\n')
		src_file="{}/{}.{}".format(fldr, fname, srclang)
		tgt_file="{}/{}.{}".format(fldr, fname, tgtlang)
		fwSrc = io.open("{}.dedupe".format(src_file),'w',encoding='utf-8',newline='\n')
		fwTgt = io.open("{}.dedupe".format(tgt_file),'w',encoding='utf-8',newline='\n')
		fwDNT = io.open("{}.dnt.log".format(src_file), 'w', encoding='utf-8',newline='\n')
		fwDupes = io.open("{}.dupe.log".format(src_file), 'w', encoding='utf-8',newline='\n')
		fwLog = io.open("{}.irrelevant.log".format(src_file), 'w', encoding='utf-8',newline='\n')
		#fwExtra = io.open("{}.extra.log".format(src_file), 'w', encoding='utf-8',newline='\n')
		cnt = 0
		cnt_irr=0
		start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
		start = time.time()

		with io.open(tm_file,'r',encoding='utf-8',newline='\n') as fr:
			try:
				for line in fr:
					if "\t" not in line:
						cnt_irr=cnt_irr+1
						fwWrongSegments.write(u"NO_TAB\t{}".format(line))
						continue
					fields = line.split("\t") # 11 fields
					if check_len_and_private and len(fields) < 7: # != 11:
						cnt_irr=cnt_irr+1
						fwWrongSegments.write(u"CLP_LT7FIELDS\t{}".format(line))
						continue
	                                if not check_len_and_private and len(fields) < 7:
						fwWrongSegments.write(u"NOCLP_LT7FIELDS\t{}".format(line))
                	                        cnt_irr=cnt_irr+1
                        	                continue
					is_private = False # NOTE: passed is the private regex match result: if passed, segment is bad
					if not check_len_and_private:
						is_private = False # Since there is no need checking field count/privates, passed is False
					else:
						if len(fields) > 7: # check the private field if available
							is_private = rx_private.match(fields[7])
						else:
							is_private = False # else, there is no private field, take it
					if rx_timestamp.match(fields[0]) and not is_private:
						cnt = cnt + 1
						timestamp = None
						try:
							timestamp=datetime.strptime(fields[0], '%Y%m%d~%H%M%S')
						except Exception as inst:
							fwWrongSegments.write(u"WRONG_TSTMP\t{}".format(line))
							cnt_irr=cnt_irr+1
							continue
						src = fields[4]
						tgt = fields[6]
#					if protect_tags:
#						src, tgt = ProtectTags(src, tgt)
						try:
							src=CleanUpLikeInPerlScript(src)
							tgt=CleanUpLikeInPerlScript(tgt)
						except Exception as inst2:
							fwWrongSegments.write(u"WRONG_TSTMP\t{}".format(line))
							cnt_irr=cnt_irr+1
							continue
						if src.strip() == tgt.strip():
							fwDNT.write(u"{}\t{}\n".format(src.strip(), tgt.strip()))
							continue
						elif is_irrelevant(src, tgt, ''):
							fwLog.write(u"{}\t{}\n".format(src.strip(), tgt.strip()))
							continue
						elif src.count('>') != tgt.count('>') or src.count('<') != tgt.count('<'):
							fwLog.write(u"{}\t{}\n".format(src.strip(), tgt.strip()))
							continue
						if len(src.split()) > 50:
							fwLog.write(u"{}\t{}\n".format(src.strip(), tgt.strip()))
							continue
						if rx_src_corrupt:
							if rx_src_corrupt.search(src): # Corrupt rule found a match
								fwWrongSegments.write(u"CORRUPT SRC\t{}\t{}\n".format(src.strip(), tgt.strip()))
								continue
						if rx_tgt_corrupt:
							if rx_tgt_corrupt.search(tgt):
								fwWrongSegments.write(u"CORRUPT TGT\t{}\t{}\n".format(src.strip(), tgt.strip()))
								continue
#					elif len(argv) > 5:
#						if rx_filter.search(src.strip()):
#							fwExtra.write(u"{}\t{}\n".format(src.strip(), tgt.strip()))
#							continue
						if dedupe_mode == "0":
							fwSrc.write(u"{}\n".format(src))
							fwTgt.write(u"{}\n".format(tgt))
							cnt_unique += 1
						else:
							src_token = tokenize(src, dedupe_mode)
							tgt_token = tokenize(tgt, dedupe_mode)
							corpus.append(tuple([src_token,tgt_token,src.strip(),tgt.strip(),timestamp]))
						if cnt_total % update_every == 0:
							print("{}: Added {} segments to corpus, continuing...".format(datetime.now().strftime("%d.%b %Y %H:%M:%S"), cnt_total))
						cnt_total += 1
					else:
						fwPrivate.write(u"{}\t{}\n".format(fields[4],fields[6]))
			except Exception as ins1:
				fwLog.write(u"DUPASZ: ".format("Some error occurred: " + str(ins1)))

		fwPrivate.close()
#		print(corpus)
		if dedupe_mode > 0: # Only dedupe  if  dedupe_mode is greater than 0
			print("Finished splitting {} into source and target segments.\nIrrelvant lines: {}. Valid segment count: {}".format(tm_file, cnt_irr, cnt))
			print("{}: The corpus has been read into a list, now sorting it...".format(datetime.now().strftime("%d.%b %Y %H:%M:%S")))
			sorted_corpus = sorted(corpus)
			print("{}: Filtering out duplicate segments...".format(datetime.now().strftime("%d.%b %Y %H:%M:%S")))
			for key, group in groupby(sorted_corpus, lambda source: source[0]):                                        ### Tested  at http://rextester.com/PFMGY80714
				g = list(group) # print ("Group as list: {}".format(list(g)))
				if len(g) == 1: # print("Write to unique as 1 src = 1 tgt")
					for hash_s, hash_t, src, tgt, timestamp in g:
						cnt_unique = cnt_unique + 1
						fwSrc.write(u"{}\n".format(src)) # print('UNIQUE: {} -||- {}'.format(src,tgt))
						fwTgt.write(u"{}\n".format(tgt))
				else: # there are several translations, get the most frequent
					unique_found = False
					for key2, group2 in groupby(sorted(g, key=lambda t: t[4], reverse=True), lambda dt: dt[4]):
						mfs = list(group2)
						if len(mfs) == 1 and not unique_found: # There is only 1 the most recent segment
							fwSrc.write(u"{}\n".format(mfs[0][2]))
							fwTgt.write(u"{}\n".format(mfs[0][3]))
							unique_found = True
							cnt_unique = cnt_unique + 1
						elif len(mfs) > 1 and not unique_found:
							r = sorted(Counter(mfs).most_common(), key=lambda x: (-x[1], x[0]))
							fwSrc.write(u"{}\n".format(r[0][0][2]))
                                        	        fwTgt.write(u"{}\n".format(r[0][0][3]))
	                                                unique_found = True
        	                                        cnt_unique = cnt_unique + 1
						else: # else we need to dump dupes
							for hash_s, hash_t, source, target, timestamp in mfs:
								fwDupes.write(u'{src}\n{tgt}\n'.format(src=source,tgt=target)) # print('DUPES TO REMOVE: {src} -||- {tgt}'.format(src=source,tgt=target))
							# print('DUPES TO REMOVE: {src} -||- {tgt}'.format(src=source,tgt=target))
				#print('--- Group END ---')
		end = time.time()
		end_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
		if dedupe_mode == "0":
			fwLog.write(u"No deduplication occurred as dedupe_mode was set to 0.")
		fwLog.write(u"Processed: {} segments.\nUnique segments: {}.\nDuplicate segments: {}.\nTime spent: {} ({} - {}).".format(cnt_total, cnt_unique, cnt_total - cnt_unique,end - start, start_time, end_time))
		fwDupes.close()
		fwLog.close()
		fwSrc.close()
		fwTgt.close()
		fwWrongSegments.close()
		#fwExtra.close()
		if dedupe_mode == "0":
			print(u"No deduplication occurred as dedupe_mode was set to 0.")
		print("Processed: {} TUs.\nUnique TUs: {}.\nDuplicate TUs: {}.\nTime spent: {} ({} - {}).".format(cnt_total, cnt_unique, cnt_total-cnt_unique,end-start,start_time,end_time))



if __name__ == "__main__":
		main(sys.argv[1:])
