#!/usr/bin/python3
#################################################### SAMPLE USAGE ##############################################
#  Author: Wiktor Stribizew                                                                                    #
#  Date created: April 16, 2018                                                                                #
#  Date updated:                                                                                               #
#  python3  /OpenNMT/tools/replace_LINESEP.py "FILE"                                                           #
#  It replaces \u2028 with space and removed \u200E
################################################################################################################
import codecs, chardet, sys, os

def main(argv):
    file = argv[0]
    file_encoding = 'utf-8'
    bytes = min(32, os.path.getsize(file))
    raw = open(file, 'rb').read(bytes)
    if raw.startswith(codecs.BOM_UTF8):
        file_encoding = 'utf-8-sig'
    elif raw.startswith(codecs.BOM_UTF16_BE):
        file_encoding = 'utf-16-be'
    elif raw.startswith(codecs.BOM_UTF16_LE):
        file_encoding = 'utf-16-le'
    elif raw.startswith(codecs.BOM_UTF16) or raw.startswith(codecs.BOM_UTF16):
        file_encoding = 'utf-16'
    else:
        result = chardet.detect(raw)
        file_encoding = result['encoding']

    if file_encoding=='ascii':
        file_encoding='utf-8'
    print("{}: Guessed {} encoding.".format(file, file_encoding))
    frSrc = codecs.open(file,'r',encoding=file_encoding)
    fwSrc = codecs.open("{}.ln".format(file),'w',encoding="utf-8")
    fwSrc.write(frSrc.read().replace("\u2028", " ").replace("\u200E", ""))
    print("Replaced all LINE SEPARATORS with space in {}.ln.".format(file))

if __name__ == "__main__":
    main(sys.argv[1:])

