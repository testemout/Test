#!/bin/bash
#USAGE: bash /OpenNMT/tools/translateDNT.sh "TEXT" /OpenNMT09/OpenNMT <MODEL_FILE_NAME> <BPE_FILE_NAME> <GPUID> <ATTFILE>
# ATTENTION: -placeholder_constraints true is added to check if tags are preserved during translation
bpe="$4"
att=''
if [ -z "$5" ]; then
  echo "No attention table will be output."
else
  att="$5"
fi
# TRY REMOVING TOKENIZATION: https://regex101.com/r/FylpdK/1
# в(\xef\xbf\xad\xef\xbf\xa8[A-Z]+ |\xef\xbf\xa8[A-Z]| \xef\xbf\xad)?е(\xef\xbf\xad\xef\xbf\xa8[A-Z]+ |\xef\xbf\xa8[A-Z]| \xef\xbf\xad)?с(\xef\xbf\xad\xef\xbf\xa8[A-Z]+ |\xef\xbf\xa8[A-Z]| \xef\xbf\xad)?н(\xef\$
cd "$2"
dnt='Семнадцать мгновений весны'
dntprep=''
if [ -f "${bpe}" ]; then
 echo "Applying BPE to DNT..."
 dntprep="$(echo $dnt | th ./tools/tokenize.lua -mode aggressive -nparallel 6 -segment_numbers -segment_alphabet_change -segment_alphabet {Han,Thai,Katakana,Hiragana} -joiner_annotate -case_feature -bpe_model ${bpe} 2> /dev/null)"
else
 echo "Not applying BPE to DNT."
 dntprep="$(echo $dnt | th ./tools/tokenize.lua -mode aggressive -nparallel 6 -segment_numbers -segment_alphabet_change -segment_alphabet {Han,Thai,Katakana,Hiragana} -joiner_annotate  -case_feature 2> /dev/null)"
fi;
echo "PREPPEDDNT:  ${dntprep}"
#dntprep=$(echo $dntprep | perl -CSD -Mutf8 -pe 's/(\X)(?!$)/$1(\xef\xbf\xad\xef\xbf\xa8[A-Z]+ |\xef\xbf\xa8[A-Z]| \xef\xbf\xad)?/g')

file="$2/tmpfile"
echo "$1" > "${file}"
echo "Translating '$1' using ONMT from '$2' using model '$3' and BPE model '$4'"

if [[ "${bpe}" != "" ]]; then
  th ./tools/tokenize.lua -mode aggressive -nparallel 6 -segment_numbers -segment_alphabet_change \
    -segment_alphabet {Han,Thai,Katakana,Hiragana} -joiner_annotate -case_feature -bpe_model "${bpe}" < "${file}" > "${file}.tok" 2>/dev/null
  echo "Using BPE..."
else
  th ./tools/tokenize.lua -mode aggressive -nparallel 6 -segment_numbers -segment_alphabet_change \
    -segment_alphabet {Han,Thai,Katakana,Hiragana} -joiner_annotate -case_feature < "${file}" > "${file}.tok" 2>/dev/null
  echo "No BPE used."
fi;

# UN-tokenize DNTs: #sed -i -E "s/$dntprep/$dnt/gI"  ${file}.tok
phl='AAAZZZ'  # ǂ/ ｟unk:xxxxx｠
perl -pe "s/\Q${dntprep}\E/${dnt// /${phl}}￨L/ig" ${file}.tok
echo 'see above'
#############perl -i -pe "s/\Q${dntprep}\E/${dnt// /${phl}}￨L/ig" ${file}.tok  # perl -CSD -i -Mutf8 -pe "s/\Q${dntprep}/$dnt/ig")
perl -i -pe "s/\Q${dntprep}\E/ʈɔʈ￨L/ig" ${file}.tok
echo "The tokenized file..."; cat ${file}.tok;

# 1. -lexical_constraints 1 : Force the beam search to apply the translations from the phrase table.
# - The -lexical_constraints option is intended to enforce the presence of the in-vocabulary words. http://forum.opennmt.net/t/lexical-constraints-results/963/3
#   If you want to use your phrase table for OOV replacements, in addition to lexical constraints, you should explicitly ask for it by using the -replace_unk option.
# 2. -limit_lexical_constraints 1 : Prevents producing each lexical constraint more than required.
#th ./translate.lua -txtplaceholder_constraints true -model "$3" -src "${file}.tok" -output "${file}.tok.tgt" -gpuid $5 -replace_unk 1 1> /dev/null
if [ -z "${att}"]; then
  th ./translate.lua -phrase_table "/Engines/logs/Gen_RUEN.pt" -replace_unk 1 \
   -model "$3" -src "${file}.tok" -output "${file}.tok.tgt" -gpuid $5 #  1> /dev/null
else
  th ./translate.lua -phrase_table "/Engines/logs/Gen_RUEN.pt" -replace_unk 1 \
   -save_attention "${att}" -model "$3" -src "${file}.tok" -output "${file}.tok.tgt" -gpuid $5 #  1> /dev/null
fi;
echo "AFTER  TRANS"; cat "${file}.tok.tgt"
sed -i "s/${phl}/ /g" "${file}.tok.tgt"
echo "AFTER TRANS/POST: "; cat "${file}.tok.tgt"
th ./tools/detokenize.lua -case_feature < "${file}.tok.tgt" > "${file}.tok.tgt.detok" 2>/dev/null
cat "${file}.tok.tgt.detok"
rm {"${file}","${file}.tok","${file}.tok.tgt","${file}.tok.tgt.detok"}
