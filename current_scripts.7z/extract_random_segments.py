#!/usr/bin/python3
#from itertools import izip
import os, sys, re, random, io

#--------------------------------------------------------------
# USAGE
# srcpathname=; tgtpathname=; numToExtract=100000; tuCount=$(wc -l < $srcpathname)
# python /OpenNMT/tools/extract_random_segments.py $srcpathname $tgtpathname $numToExtract $tuCount
# TEST: https://rextester.com/RHADP52180
#--------------------------------------------------------------

rx_lbrs = re.compile('[\u000B\u000C\u000D\u0085\u2028\u2029]+')

def main(argv):
#	   print(";".join(argv))
		src_file = argv[0]
		tgt_file = argv[1]
		numToExtract = int(argv[2])
		tuCount = int(argv[3])
		projdir = re.sub(r'(.*)[/\\].*', r'\1', src_file)
		ids = random.sample(range(1, tuCount), numToExtract) # [random.randint(0, tuCount) for _ in range(numToExtract)]
		ids.sort()
		print('Source file is {}'.format(src_file))
		print('Target file is {}'.format(tgt_file))
		print("Segments count to extract: {} from {}.".format(numToExtract, tuCount))

		cnt_ids = 0
		print('Project directory is {}'.format(projdir))

		cnt = 0
		cnt_found=0
		curr = 0

		with io.open("{}.extr".format(src_file),'w',encoding='utf8', newline='\n') as fwSrc:
			with io.open("{}.extr".format(tgt_file),'w',encoding='utf8', newline='\n') as fwTgt:
				with io.open(src_file,'r',encoding='utf8', newline='\n') as frSrc, io.open(tgt_file,'r',encoding='utf8', newline='\n') as frTgt:
					for src, tgt in zip(frSrc, frTgt):
						if cnt % 50000 == 0:
							print("Processed {} segments...".format(cnt))
						cnt += 1
						if cnt == ids[curr]:
							fwSrc.write("{}\n".format(rx_lbrs.sub(' ', src).strip()))
							fwTgt.write("{}\n".format(rx_lbrs.sub(' ', tgt).strip()))
							cnt_found += 1
							curr += 1
							if cnt_found == numToExtract:
								break

		print("Finished extracting random segments")

if __name__ == "__main__":
		main(sys.argv[1:])

