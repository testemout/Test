#!/usr/bin/python3
#################################################### SAMPLE USAGE ##############################################
#  Author: Wiktor Stribizew                                                                                    #
#  Date created: April 10, 2018                                                                                #
#  Date updated:                                                                                               #
#  python3  "convert_to_utf8.py" "FILE"                                                                   #
################################################################################################################
import io, chardet, os, sys, codecs

def main(argv):
    file = argv[0]
    file_encoding = 'utf-8'
    bytes = min(32, os.path.getsize(file))
    raw = open(file, 'rb').read(bytes)
    if raw.startswith(codecs.BOM_UTF8):
        file_encoding = 'utf-8-sig'
    elif raw.startswith(codecs.BOM_UTF16_BE):
        file_encoding = 'utf-16-be'
    elif raw.startswith(codecs.BOM_UTF16_LE):
        file_encoding = 'utf-16-le'
    elif raw.startswith(codecs.BOM_UTF16) or raw.startswith(codecs.BOM_UTF16):
        file_encoding = 'utf-16'
    else:
        result = chardet.detect(raw)
        file_encoding = result['encoding']

    print("{}: Guessed {} encoding.".format(file, file_encoding))
    with io.open(file,'r',encoding=file_encoding, newline='\n') as frSrc:
        with io.open("{}.reencoded".format(file),'w',encoding="utf-8", newline='\n') as fwSrc:
            for line in frSrc:
                fwSrc.write(line)
    print("Encoding {0} to {0}.reencoded finished.".format(file))

if __name__ == "__main__":
    main(sys.argv[1:])

