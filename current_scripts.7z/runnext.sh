#!/bin/bash
#nohup nice bash /OpenNMT/tools/runnext.sh > /dev/null 2>&1 &
nprocs=`ps -ef | grep [l]ua | wc -l`
while [[ $nprocs -gt 0 ]]
do
    sleep 300
    nprocs=`ps -ef | grep [l]ua | wc -l`
done

###run the training script here below using script
#nohup nice bash /Engines/Gen/ENRO/Gen.ENRO_rev.sh > /Engines/Gen/ENRO/Gen.ENRO_rev_process.rpt 2>&1 &
#sed -i '$ s/$/\necho "No LUA processes found"/' /Engines/hola.sh
#nohup nice bash /Engines/Teck/ENES/Teck.ENES.sh > /Engines/Teck/ENES/Teck.ENES_process.rpt 2>&1 &
#nohup nice bash /Engines/Boohoo/ENDE/Boohoo.ENDE.sh > /Engines/Boohoo/ENDE/Boohoo.ENDE_process.rpt 2>&1 &
#nohup nice bash /Engines/CRO/ENKO/CRO.ENKO.sh > /Engines/CRO/ENKO/CRO.ENKO_process.rpt 2>&1 &
#nohup nice bash /Engines/FastRetailing/FastRetailing.JAEN.2.sh > /Engines/FastRetailing/FastRetailing.JAEN_2_process.rpt 2>&1 &
#nohup nice bash /Engines/HugoBoss/HB.ENESNL.sh > /Engines/HugoBoss/HB.ENESNL_process.rpt 2>&1 &
#sed -i "$ s/$/; echo $(date '+%Y-%m-%d')/" /Engines/hola.sh
