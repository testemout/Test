#!/bin/bash

############################################## USAGE
#
# bash /OpenNMT/tools/protranslate3.sh model bpe srclng tgtlng fldr transFile glossFile
# V3: Added log file support
##############################################

# Protect GLOssary terms, translate and post-process
# SETTINGS
model="$1"
bpe="$2"

src="$3"
tgt="$4"
fldr="$5"
mkdir "$fldr/translated"
to_trans="$6"
gloss="$7"
gpuid="$8"
output_file="$fldr/translated/to_trans (translated from $src into $tgt).txt"
log_file="$fldr/trans_log_${to_trans##*/}.rpt"
pred_file="$fldr/pred_${to_trans##*/}.txt"
script=/OpenNMT/tools/prepterm5.py
### PREP ###
python3 "$script" "$to_trans" "$gloss" "prep" "$src" "$tgt"; mv "$to_trans.tmpx" "$to_trans.prep";
### TRANSLATION ###
cd /OpenNMT09/OpenNMT
th ./tools/tokenize.lua -mode aggressive -nparallel 6 -segment_numbers -segment_alphabet_change -segment_alphabet {Han,Thai,Katakana,Hiragana} -joiner_annotate -case_feature -bpe_model "$bpe" < "$to_trans.prep" > "$to_trans.prep.tok"
th translate.lua -model "$model" -src "$to_trans.prep.tok" -output "$to_trans.prep.tok.trans" -gpuid "$gpuid" -log_file ${log_file}  -fallback_to_cpu 1;
th ./tools/detokenize.lua -case_feature < "$to_trans.prep.tok.trans" > "$output_file.trans.detok"
### POST ###
python3 "$script" "$output_file.trans.detok" "$gloss" "post" "$src" "$tgt"
mv "$output_file.trans.detok.tmpx" "$output_file"
#Get meta data and merge files
grep -oP 'PRED SCORE: \K-?\d[\d.]*$' "${log_file}" > "${pred_file}"
paste <(paste -d $'\t' "${to_trans}" "$output_file") "${pred_file}" > "${output_file}.cmp.txt"
avg_pscore=$(awk '{n++;sum+=$0} END {print sum/n}' "${pred_file}")
sed -i "1 iSource\tTarget\tPScore (Avg: $avg_pscore)" "${output_file}.cmp.txt"
