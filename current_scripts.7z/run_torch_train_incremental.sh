#!/bin/bash
# project=Novartis; src=EN; tgts=DE; folder=/Engines/Novartis; restarted=FALSE
# nohup nice bash /OpenNMT/tools/run_torch_train_incremental.sh $project $src $tgts $folder $restarted > ${folder}/${project}_train_process.rpt 2>&1 &

source /OpenNMT/tools/get_model.sh
source /OpenNMT/tools/get_bpe.sh

restart_stopped="$5"

base='/var/www/html/Archive'
src="$2"
tgts="$3"
projname="$1"

for tgt in $tgts; do
	base_model="${base}"/"$(get_model $tgt tgt)"
	base_bpe="${base}"/"$(get_bpe $tgt tgt)"

	# Validity checks
	if [ -f "${base_model}" ]; then
	  echo "Base model: ${base_model}";
	else
	  echo "Base model is not found at ${base_model}, aborting...";
	  exit -1;
	fi;

	if [[ "${base_model##*/}" =~ "$src$tgt" ]]; then
	  echo "Language pair check PASSED: base model - ${base_model##*/} - contains $src$tgt.";
	else
	  echo "Language pair check FAILED: base model - ${base_model##*/} - does NOT contain $src$tgt.";
	  [[ "${base_model##*/}" =~ "$tgt$src" ]] && echo "ERROR: It contains $tgt$src."
	  exit -1;
	fi;
	echo "BPE Model: ${base_bpe}"

	prefix="${projname}_${src}${tgt}"
	fldr="$4"
	modelsdir="models_${src}${tgt}"
	transdir="trans_${src}${tgt}"
	mkdir "${fldr}/${modelsdir}"

	src_test="${fldr}/src-test.txt"
	src_train="${fldr}/src-train.txt"
	src_val="${fldr}/src-val.txt"
	tgt_test="${fldr}/tgt-test.txt"
	tgt_train="${fldr}/tgt-train.txt"
	tgt_val="${fldr}/tgt-val.txt"

	echo -e "Src: ${src}\nTgt: ${tgt}\nSRC Training: ${src_train}\nSRC Validation: ${src_val}\nSRC Testing: ${src_test}\nTGT Training: ${tgt_train}\nTGT Validation: ${tgt_val}\nTGT Testing: ${tgt_test}"

	cd /OpenNMT09/OpenNMT
	# PREPROCESS
	# We are using BPE from the generic model
	if [[ "${restart_stopped}" != "TRUE" ]]; then
		for f in ${fldr}/*.txt; do
			echo "---Tokenizing $f";
			th ./tools/tokenize.lua -mode aggressive -nparallel 6 -segment_numbers -segment_alphabet_change \
				-segment_alphabet {Han,Thai,Katakana,Hiragana} -joiner_annotate -case_feature \
				-bpe_model ${base_bpe} < $f > $f.tok;
		done
		th ./preprocess.lua -src_seq_length 100 -tgt_seq_length 100 \
			-train_src ${src_train}.tok -train_tgt ${tgt_train}.tok -valid_src ${src_val}.tok \
			-valid_tgt ${tgt_val}.tok -save_data ${fldr}/${modelsdir}/${prefix}
	fi;
	pars="" # Network parameters are empty
	if [[ "$src$tgt" == "ENRU" || "$src$tgt" == "RUEN" ]]; then
		pars="-layers 5 -rnn_size 1000 -word_vec_size 600 -encoder_type brnn"
	elif [[ "$src$tgt" == "ENDE" || "$src$tgt" == "DEEN" ]]; then
		pars="-residual -layers 6 -rnn_size 1000 -encoder_type brnn -word_vec_size 700 -max_batch_size 100"
	elif [[ "$src$tgt" == "ENTH" || "$src$tgt" == "THEN" ]]; then
		pars="-residual -layers 2 -rnn_size 600 -encoder_type brnn"
	elif [[ "$src$tgt" == "ENZHCN" ]]; then
		pars="-residual -layers 5 -rnn_size 1000 -encoder_type brnn -word_vec_size 700 -max_batch_size 100"
	elif [[ "$src$tgt" == "ENNL" || "$src$tgt" == "NLEN" ]]; then
		pars="-residual -layers 5 -rnn_size 1000 -word_vec_size 600 -encoder_type brnn -max_batch_size 100"
	elif [[ "$src$tgt" == "ZHCNEN" ]]; then
		pars="-residual -layers 6 -rnn_size 1000 -encoder_type brnn -word_vec_size 700 -max_batch_size 100"
	elif [[ "$src$tgt" == "ENKO" || "$src$tgt" == "KOEN" ]]; then
		pars="-residual -layers 6 -rnn_size 1000 -word_vec_size 600 -encoder_type brnn -max_batch_size 100"
	elif [[ "$src$tgt" == "ENJA" ]]; then
		pars="-residual -layers 5 -rnn_size 1000 -encoder_type brnn -word_vec_size 600 -max_batch_size 80"
	elif [[ "$src$tgt" == "ENFR" || "$src$tgt" == "FREN" || "$src$tgt" == "ENFRCA" || "$src$tgt" == "FRCAEN" ]]; then  # FRCA temporry
		pars="-residual -layers 6 -rnn_size 1000 -word_vec_size 700 -encoder_type brnn -max_batch_size 100"
	elif [[ "$src$tgt" == "ENPL" || "$src$tgt" == "PLEN" ]]; then
		pars="-residual -layers 5 -rnn_size 1000 -encoder_type brnn -word_vec_size 600 -max_batch_size 100"
	elif [[ "$src$tgt" == "ENES" || "$src$tgt" == "ESEN" || "$src$tgt" == "ENESES" || "$src$tgt" == "ESESEN" ]]; then
		pars="-residual -layers 6 -rnn_size 1000 -word_vec_size 700 -encoder_type brnn -max_batch_size 80"
	elif [[ "$src$tgt" == "ENID" || "$src$tgt" == "IDEN" ]]; then
		pars="-layers 3 -rnn_size 800 -encoder_type brnn -word_vec_size 600"
	elif [[ "$src$tgt" == "ENIT" || "$src$tgt" == "ITEN" ]]; then
		pars="-residual -layers 6 -rnn_size 1000 -word_vec_size 700 -encoder_type brnn -max_batch_size 80"
		#base_model="/Engines/Experian/ENIT/models_ENIT/Experian_ENIT_epoch4_2.01.t7"
	elif [[ "$src$tgt" == "JAEN" ]]; then
		pars="-residual -layers 6 -rnn_size 1000 -encoder_type brnn -word_vec_size 600 -max_batch_size 80" # temporary JAEN
	elif [[ "$src$tgt" == "ENPTBR" || "$src$tgt" == "PTBREN" ]]; then
		pars="-residual -layers 6 -rnn_size 1000 -word_vec_size 700 -encoder_type brnn -max_batch_size 80"
	elif [[ "$src$tgt" == "ENNO" || "$src$tgt" == "NOEN" ]]; then
		pars="-layers 4 -rnn_size 800 -word_vec_size 600 -encoder_type brnn"
	fi;
	if [ -z "$pars" ]; then
		echo "There is a problem with defining network parameters! Aborting...";
		exit 1;
	else
		echo "Using the following network: $pars";
	fi;
	if [[ "$restart_stopped" == "TRUE" && "${tgts[0]}" == $tgt ]]; then
		pars="$pars -continue"
	fi;

	# THC_CACHING_ALLOCATOR=0  # ADD IF MEMORY IS LOW  -max_batch_size 80
	# CUDA_VISIBLE_DEVICES=0,1,2,3 # ADD IF 4 CORES ARE AVAILABLE
	# RETAIL ENZHCN:  -layers 3 -rnn_size 800 -encoder_type brnn -word_vec_size 600
	# CRO ENZHCN: -layers 3 -rnn_size 700 -word_vec_size 600

	printf '%s\n' "$pars" | xargs th ./train.lua \
	 -train_from "${base_model}" -src_seq_length 100 -tgt_seq_length 100 -update_vocab merge -data ${fldr}/${modelsdir}/${prefix}-train.t7 \
	 -save_model ${fldr}/${modelsdir}/${prefix} -report_every 1000 -save_every 0 \
	 -save_config ${fldr}/${prefix}_training_cfg.cfg -gpuid 1 -log_file ${fldr}/${modelsdir}/${prefix}_training_log.rpt

	#Remove the initial epoch files (only use if there is enough SPACE ON DISK!!!!
	#rm -r ${fldr}/${modelsdir}/${prefix}_epoch{1..5}_*.t7

	if [ "$(find ${fldr}/${modelsdir} -name ${prefix}_epoch'*.t7' | wc -l)" -gt 0 ]; then
	  log_file="${fldr}/${modelsdir}/${prefix}_training_log.rpt"
	  grep 'Validation perplexity:' "$log_file" | \
	  awk -v max=1000000 'BEGIN{
	   if(max < $6) {
		 print "Epoch "i+1" ("$6") is greater than preceding epoch ("max")";
		 exit 1;
	   }
	   } END {
		 print "Validation PPL scores go down with each epoch, correct.";
	  }'
	  mkdir "${fldr}/${transdir}"
	  th ./tools/tokenize.lua -mode aggressive -nparallel 6 < "${tgt_test}" > "${tgt_test}.defretok"
	  cp "${src_test}.tok" "${fldr}/${transdir}/src-test.txt.tok"
	  cp "${tgt_test}.tok" "${fldr}/${transdir}/tgt-test.txt.tok"
	  # copy tokenized src-test.txt.tok and tgt-test.txt.tok files there AND TRANSLATE WITH BASE MODEL:
	  th translate.lua -model ${base_model} -src ${fldr}/${transdir}/src-test.txt.tok -output ${fldr}/${transdir}/${base_model##*/}_baseline_MT.txt -gpuid 1 1>/dev/null;
	  echo -e "Baseline\tTokenized\t"${base_model##*/}_MT.txt >> ${fldr}/${transdir}/BLEU_scores.txt;
	  th ./tools/detokenize.lua -case_feature < ${fldr}/${transdir}/${base_model##*/}_baseline_MT.txt > ${fldr}/${transdir}/${base_model##*/}_baseline_MT.txt.detok
	  th ./tools/tokenize.lua -mode aggressive -nparallel 6 < ${fldr}/${transdir}/${base_model##*/}_baseline_MT.txt.detok > ${fldr}/${transdir}/${base_model##*/}_baseline_MT.txt.detok.defretok
	  echo -e "Baseline\tTokenized\t"$(perl benchmark/3rdParty/multi-bleu.perl ${fldr}/${transdir}/tgt-test.txt.tok < ${fldr}/${transdir}/${base_model##*/}_baseline_MT.txt) >> ${fldr}/${transdir}/BLEU_scores.txt;
	  echo -e "Baseline\tDefRetok\t"$(perl benchmark/3rdParty/multi-bleu.perl ${tgt_test}.defretok < ${fldr}/${transdir}/${base_model##*/}_baseline_MT.txt.detok.defretok) >> ${fldr}/${transdir}/BLEU_scores.txt;

	  for f in ${fldr}/${modelsdir}/${prefix}*_epoch{6..13}_*.t7
	  do
	   th translate.lua -model $f -src ${fldr}/${transdir}/src-test.txt.tok -output ${fldr}/${transdir}/${f##*/}_MT.txt -gpuid 1 1>/dev/null;
	   echo ${f##*/}_MT.txt >> ${fldr}/${transdir}/BLEU_TOK_scores.txt;
	   th ./tools/detokenize.lua -case_feature < ${fldr}/${transdir}/${f##*/}_MT.txt > ${fldr}/${transdir}/${f##*/}_MT.txt.detok
	   th ./tools/tokenize.lua -mode aggressive -nparallel 6 < ${fldr}/${transdir}/${f##*/}_MT.txt.detok > ${fldr}/${transdir}/${f##*/}_MT.txt.detok.defretok
	   echo ${f##*/}_MT.txt.detok.defretok >> ${fldr}/${transdir}/BLEU_DEFRETOK_scores.txt;
	   perl benchmark/3rdParty/multi-bleu.perl ${fldr}/${transdir}/tgt-test.txt.tok < ${fldr}/${transdir}/${f##*/}_MT.txt >> ${fldr}/${transdir}/BLEU_TOK_scores.txt;
	   perl benchmark/3rdParty/multi-bleu.perl ${tgt_test}.defretok < ${fldr}/${transdir}/${f##*/}_MT.txt.detok.defretok >> ${fldr}/${transdir}/BLEU_DEFRETOK_scores.txt;
	  done
	  #Determine the best epoch based on BLEU
	  best_trans_file=$(awk -v max=0 'BEGIN{RS=")\n\n*";FS="([,[:space:](/]|BLEU = |BP=|ration=)+"}{if($2>max){want=$1; max=$2}}END{print want}' ${fldr}/${transdir}/BLEU_TOK_scores.txt)
	  best_model_file=${best_trans_file%_*}
	  echo "Best model (tokenized) file: ${best_model_file}"
	  best_DEFRETOK_trans_file=$(awk -v max=0 'BEGIN{RS=")\n\n*";FS="([,[:space:](/]|BLEU = |BP=|ration=)+"}{if($2>max){want=$1; max=$2}}END{print want}' ${fldr}/${transdir}/BLEU_DEFRETOK_scores.txt)
	  best_DEFRETOK_model_file=${best_DEFRETOK_trans_file%_*}

	  awk 'BEGIN{RS=")\n\n*";FS="([,[:space:](/]|BLEU = |BP=|ration=)+"}{print $1 "\t" $2}' ${fldr}/${transdir}/BLEU_TOK_scores.txt
	  echo "Tokenized PPL scores:"
	  echo "-----------------------------"
	  sort "${fldr}/${transdir}/BLEU_TOK_scores.txt" | grep '^BLEU =' | awk -F" = |, |/| (|)" -v cnt=0 '{print  "Epoch" (cnt=cnt+1) "\t" $2}'
	  echo "-----------------------------"

	  echo "Best model (default tokenized) file: ${best_DEFRETOK_model_file}"

	  if [[ -z "${best_model_file}" ]]; then
		echo "Error: No best model file could be detected! Aborting..."
	  else
		#mkdir ${fldr}/delivery
		cd /OpenNMT09/OpenNMT
		#Delivery to /var/www/html:
		delivery_fldr="/var/www/html/${projname}_${src}${tgt}_$(date '+%Y-%m-%d')"
		mkdir ${delivery_fldr}
		th ./tools/release_model.lua -model ${fldr}/${modelsdir}/${best_model_file} -output_model ${delivery_fldr}/${best_model_file/.t7/_release.t7} -gpuid 1
		cp "${bpe}" "${delivery_fldr}"
		echo -e "Released model and BPE model files are located at:\n${delivery_fldr}/${best_model_file/.t7/_release.t7}\n${delivery_fldr}/${prefix}_trainall.tok.bpe"
		#Clean up the unnecessary models
		#for f in ${fldr}/${modelsdir}/${prefix}*.t7; do if [ $f != ${fldr}/${modelsdir}/${best_model_file} ]; then rm $f; fi; done
		for f in ${fldr}/${modelsdir}/${prefix}*.t7; do if [ $f != ${fldr}/${modelsdir}/${best_model_file} ]; then echo "I am removing $f"; fi; done
	  fi;
	else
	  echo "No epoch *.t7 files are found in the models directory, exiting…"
	fi;
done;

