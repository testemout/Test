# TUTORIAL: http://www.sqlitetutorial.net/sqlite-python/create-tables/
# USAGE:
# python3.6 /OpenNMT/tools/pivotql.py src1 tgt1 src2 tgt2 output_path_prefix slang tlang
#                                                          
# fldr=/Engines/Gen/JAXX
# script=/OpenNMT/tools/pivotql.py
# src1=$fldr/ENJA/Gen.ENJA.all.EN.dedupe
# tgt1=$fldr/ENJA/Gen.ENJA.all.JA.dedupe
# src2=$fldr/ENZHCN/Gen.ENZHCN.all.EN.dedupe
# tgt2=$fldr/ENZHCN/Gen.ENZHCN.all.ZHCN.dedupe
# outpathprefix=$fldr/JAZHCN.Gen.pivoted
# slang=JA
# tlang=ZHCN
# nohup nice python3.6 ${script} $src1 $tgt1 $src2 $tgt2 $outpathprefix $slang $tlang > $outpathprefix.rpt 2>&1 &
#############################################

import sqlite3, re, hashlib, os, io, datetime, sys
from sqlite3 import Error

DB_FILE_LOCATION = '/Engines/tmp/tempDB.sq3'
#DB_FILE_LOCATION = r'c:\praca\MT\_tools\_Scripts\_test\tempDB.sq3'

def remove_punctuation(text):
    return text.translate(tbl)

def tokenize(seg, mode): # TESTED AT https://ideone.com/SzJLXH
	tokenized = seg.strip()
	if mode == "0": # Fully tokenized punctuation, spaces, case
		tokenized = re.sub(r"\s+", "", remove_punctuation(seg.lower()) ) #nooooooooooooo
	elif mode == "1": # Clean case sensitive (whitespace insensitive)
		tokenized = re.sub(r"\s+", "", seg)
	elif mode == "2" : # Clean case/whitespace insensitive (best with case_feature)
		tokenized = re.sub(r"\s+", "", seg.lower())
	else: # no tokenization (for now, same as 1 (clean case sensitive)
		tokenized = re.sub(r"\s+", "", seg) #nooooooooooo
	hash1 = hashlib.md5(tokenized.encode('utf-8'))
	return hash1.hexdigest()

def create_dedupe_table(conn,table_name):
    """ create a table from the create_table_sql statement
    :param conn: Connection object
    :param table_name: a CREATE TABLE statement
    :return:
    """
    try:
        c = conn.cursor()
        c.execute(""" CREATE TABLE IF NOT EXISTS {} (
                                        id integer PRIMARY KEY,
                                        src_seg TEXT,
                                        tgt_seg TEXT,
                                        tokenized_seg TEXT
                                    ); """.format(table_name))
    except Error as e:
        print(e)


def select_all(conn, table_name):
    """
    Query all rows in the tasks table
    :param conn: the Connection object
    :return:
    """
    cur = conn.cursor()
    cur.execute("SELECT * FROM {}".format(table_name))

    rows = cur.fetchall()

    for row in rows:
        print(row)

def create_connection(db_file):
    """ create a database connection to the SQLite database
        specified by db_file
    :param db_file: database file
    :return: Connection object or None
    """
    try:
        conn = sqlite3.connect(db_file)
        return conn
    except Error as e:
        print(e)

    return None

def main(argv):
    src_file = argv[0]
    tgt_file = argv[1]
    src_file2 = argv[2]
    tgt_file2 = argv[3]
    out_file = argv[4]
    slang = argv[5]
    tlang = argv[6]

    if os.path.isfile(DB_FILE_LOCATION):
        os.remove(DB_FILE_LOCATION)

    mode=2
    #print(DB_FILE_LOCATION)
    # create a database connection
    print("{}: START...".format(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
    conn = create_connection(DB_FILE_LOCATION)
    if conn is not None:
        print("{}: Connection created, creating table...".format(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
        # create projects table CreateDedupeTable
        create_dedupe_table(conn,'TABLE1')
        with conn:       # create a new project, row of data
            cur = conn.cursor()
            print("{}: Reading the first set of files....".format(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
            with io.open(src_file,'r', encoding='utf-8', newline='\n') as frSrc, io.open(tgt_file,'r', encoding='utf-8', newline='\n') as frTgt:
                for src, tgt in zip(frSrc, frTgt):
                    cur.execute(' INSERT INTO TABLE1(src_seg, tgt_seg, tokenized_seg) VALUES(?,?,?) ', (src.strip(), tgt.strip(), tokenize(src, mode)))
            for column_name in ['tokenized_seg']:
                cur.execute(("CREATE INDEX " + "{}_idx1".format(column_name) + " ON TABLE1(" + column_name + ")")) # Indexing

            select_all(conn, 'TABLE1') # prints all rows
            print("{}: Reading second set of files....".format(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
            create_dedupe_table(conn,'TABLE2')
            with io.open(src_file2,'r', encoding='utf-8', newline='\n') as frSrc, io.open(tgt_file2,'r', encoding='utf-8', newline='\n') as frTgt:
                for src, tgt in zip(frSrc, frTgt):
                    cur.execute(' INSERT INTO TABLE2(src_seg, tgt_seg, tokenized_seg) VALUES(?,?,?) ', (src.strip(), tgt.strip(), tokenize(src, mode)))
            for column_name in ['tokenized_seg']:
                cur.execute(("CREATE INDEX " + "{}_idx2".format(column_name) + " ON TABLE2(" + column_name + ")")) # Indexing
            select_all(conn, 'TABLE2') # prints all rows

            print("{}: Joining segments....".format(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
            sql = "SELECT DISTINCT [TABLE1].[tgt_seg], [TABLE2].[tgt_seg] FROM [TABLE1] JOIN [TABLE2] ON [TABLE2].[tokenized_seg] = [TABLE1].[tokenized_seg]"
            cur.execute(sql)
            with io.open("{}.{}".format(out_file, slang),'w', encoding='utf-8', newline='\n') as fwOutSrc:
                with io.open("{}.{}".format(out_file, tlang),'w', encoding='utf-8', newline='\n') as fwOutTgt:
                    for row in cur.fetchall():
                        fwOutSrc.write("{}\n".format(row[0]))
                        fwOutTgt.write("{}\n".format(row[1]))

            print("{}: END.".format(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
            os.remove(DB_FILE_LOCATION)
    else:
        print("Error! cannot create the database connection.")



if __name__ == '__main__':
    main(sys.argv[1:])
    #main([r'c:\praca\MT\_tools\_Scripts\_test\data\src.txt',
    #      r'c:\praca\MT\_tools\_Scripts\_test\data\tgt.txt',
    #      r'c:\praca\MT\_tools\_Scripts\_test\data\src2.txt',
    #      r'c:\praca\MT\_tools\_Scripts\_test\data\tgt2.txt',
    #      r'c:\praca\MT\_tools\_Scripts\_test\data\out',
    #      'ru', 'pl'])

