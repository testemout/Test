#!/usr/bin/python
# -*- coding: utf-8 -*-

import re, sys, hashlib, time, unicodedata, io
from datetime import datetime
from itertools import izip
from itertools import *
from collections import Counter

debug = 0
fwDebug = None

tbl = dict.fromkeys(i for i in xrange(sys.maxunicode) if unicodedata.category(unichr(i)).startswith('P'))
rx_is_segment_blank = re.compile(r'^\s*$', re.U)
rx_invalid_xml_chars = re.compile(r'(?![\r\n\t])[\x00-\x1F]')
rx_numeric = re.compile(r'^\d+$', re.U)
rx_email = re.compile(r'^\s*\S+@\S+\.\S+\s*$', re.U)
rx_url_encoded = re.compile(r'^\s*(?:%[0-9A-Fa-f]{2})+\s*$', re.U)
rx_no_letter = re.compile(r'^(?!.*[^\W\d_])', re.U)
rx_url = re.compile(r'^\s*(?:https?|ftp|gopher|telnet|file|notes|ms-help):(?://|\\\\)+[\w:#@%/;$()~_?+-=\\.\x26]*\s*$', re.I | re.U)
rx_html_entities = re.compile(r'^\s*(?:&#\d+;|&[a-zA-Z\d]+;)+(?:\s+(?:&#\d+;|&[a-zA-Z\d]+;)+)*\s*$', re.U)
rx_too_long = re.compile(r'^\W*\w+(?:\W+\w+){100}$', re.U) # More than 100 words
rx_alphanumeric = re.compile(r'^(?=\D*\d)(?=[\W\d_]*[^\W\d_])\s*[^\W_]+\s*$', re.U) # DO NOT USE FOR APAC!!!
# Combine all except rx_alphanumeric.pattern
rx_irrelevant = re.compile("|".join([rx_is_segment_blank.pattern, rx_invalid_xml_chars.pattern, rx_numeric.pattern, rx_email.pattern, rx_url_encoded.pattern, rx_no_letter.pattern, rx_url.pattern, rx_html_entities.pattern, rx_too_long.pattern]), re.I | re.U | re.S)
rx_nonalnum = re.compile(r"(?u)[^\w_]+")

def remove_punctuation(text):
	return text.translate(tbl)

def tokenize(seg, mode, fwDebug): # TESTED AT https://ideone.com/SzJLXH
#	if debug <> 0:
#                fwDebug.write(u"Mode value in tokenize fn: {}\n".format(mode))
	tokenized = seg
	if mode == "0": # Fully tokenized punctuation, spaces, case
		tokenized = re.sub(ur"(?u)\s+", u"", remove_punctuation(seg.lower()) ) #nooooooooooooo
	elif mode == "1": # Clean case sensitive (whitespace insensitive)
		tokenized = re.sub(ur"(?u)\s+", u"", seg)
	elif mode == "2": # Clean case/whitespace insensitive (best with case_feature)
		tokenized = re.sub(ur"(?u)\s+", u"", seg.lower())
	else: # no tokenization (for now, same as 1 (clean case sensitive)
		tokenized = re.sub(ur"(?u)\s+", u"", seg) #nooooooooooo
#	if debug <> 0:
#		fwDebug.write(u"Token being hashed: {}\nEncoded tokenized seg: no idea\n".format(tokenized))
	hash = hashlib.sha1(tokenized.encode('utf-8'))
	return hash.hexdigest()

def is_irrelevant(src_seg, tgt_seg, lang): # TESTED AT https://ideone.com/WFm9T6
	#m = rx_is_segment_blank.search(src_seg) # if source or target is null or whitespace	 #if not m:		 m = rx_is_segment_blank.search(tgt_seg) if m:		  return true
	m = rx_irrelevant.search(src_seg)
	n = rx_irrelevant.search(tgt_seg)
	return m or n


def main(argv):
	src_file = argv[0]
	tgt_file = argv[1]
	dedupe_mode = argv[2]
	update_every = 1000
	dedupe = "1"
	if len(argv) > 3:
		update_every = int(argv[3])
	if len(argv) > 4:
		if argv[4] in ['0', '1']:
			dedupe = argv[4]
		else:
			print("Dedupe option must be either '0' (no deduplication) or '1' (perform deduplication).")
			quit()
	arr = []
	cnt_total = 0
	cnt_unique = 0
	idx = 0
	corpus = []

	print("====================== DEDUPE/PRUNE ===================================")
	start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
#	if debug <> 0:
#		fwDebug=io.open("{}.debug.log".format(src_file), 'w', encoding='utf8',newline='\n')
	start = time.time()
	fwDNT = io.open("{}.dnt.log".format(src_file), 'w', encoding='utf8',newline='\n')
	fwDupes = io.open("{}.dupe.log".format(src_file), 'w', encoding='utf8',newline='\n')
	with io.open("{}.irrelevant.log".format(src_file), 'w', encoding='utf8',newline='\n') as  fwLog:
		with io.open("{}.dedupe".format(src_file),'w',encoding='utf8',newline='\n') as fwSrc:
			with io.open("{}.dedupe".format(tgt_file),'w',encoding='utf8',newline='\n') as fwTgt:
				with io.open(src_file,'r',encoding='utf8',newline='\n') as frSrc, io.open(tgt_file,'r',encoding='utf8',newline='\n') as frTgt:
					for src, tgt in izip(frSrc, frTgt): # WE MAY PRUNE RIGHT HERE TO AVOID ADDING USELESS SEGMENTS TO LIST
						idx = idx + 1
#						if debug <> 0 and re.search(u'[\u000B\u000C\u000D\u0085\u2028\u2029]+', src):
#							print(u"{}: {}".format("SRC", src))
#						if debug <> 0 and re.search(u'[\u000B\u000C\u000D\u0085\u2028\u2029]+', tgt):
#							print(u"{}: {}".format("TGT", tgt))
                                                src = re.sub(u'[\u000B\u000C\u000D\u0085\u2028\u2029]+', u' ', src).strip()
                                                tgt = re.sub(u'[\u000B\u000C\u000D\u0085\u2028\u2029]+', u' ', tgt).strip()
						if len(src) == 0 or len(tgt) == 0:
							fwLog.write(u"{}\t{}\n".format(src, tgt))
#							print(u"{}:{}:::{}".format(idx, src,tgt))
							continue
						if rx_nonalnum.sub(u"", src) == rx_nonalnum.sub(u"", tgt):
							fwDNT.write(u"{}\t{}\n".format(src, tgt))
							continue
						elif is_irrelevant(src, tgt, ''):
							fwLog.write(u"{}\t{}\n".format(src, tgt))
							continue
#                                                if debug <> 0:
#                                                        fwDebug.write(u"Tokenized src: {}\nTokenized tgt: {}\nDedupe mode: {}\n".format(src,tgt,dedupe_mode))
						src_token = tokenize(src, dedupe_mode,fwDebug)
						tgt_token = tokenize(tgt, dedupe_mode,fwDebug)
#                                                if debug <> 0:
#                                                        fwDebug.write(u"Src token: {}\nTgt token: {}".format(src_token, tgt_token))
#						if "Mikumo!" in src or "Mikumo!" in tgt:
#							print(u"{}:{}:::{}".format(idx, src,tgt))
						corpus.append(tuple([src_token,tgt_token,src,tgt]))
#						if debug <> 0:
#							fwDebug.write(u"{}\t{}\t{}\t{}\n".format(src_token, tgt_token, src, tgt))
						if cnt_total % update_every == 0:
							print("{}: Added {} segments to corpus, continuing...".format(datetime.now().strftime("%d.%b %Y %H:%M:%S"), cnt_total))
						cnt_total = cnt_total + 1
					if dedupe == "0":
						for hash_s,hash_t,src,tgt in corpus:
							fwSrc.write(u"{}\n".format(src))
							fwTgt.write(u"{}\n".format(tgt))
					else:
						print("{}: The corpus has been read into a list, now sorting it...".format(datetime.now().strftime("%d.%b %Y %H:%M:%S")))
#       	                                 with codecs.open("{}.corpus".format(src_file), 'w',encoding='utf8') as fgh2:
#               	                                 for src_token2,tgt_token2,src2,tgt2 in corpus:
#                       	                                 fgh2.write(u"{}\t{}\t{}\t{}\n".format(src_token2,tgt_token2,src2,tgt2))
						sorted_corpus = sorted(corpus)
#						with codecs.open("{}.corpus_sorted".format(src_file), 'w',encoding='utf8') as fgh:
#							for src_token1,tgt_token1,src1,tgt1 in sorted_corpus:
#								fgh.write(u"{}\t{}\t{}\t{}\n".format(src_token1,tgt_token1,src1,tgt1))
						print("{}: Filtering out duplicate segments...".format(datetime.now().strftime("%d.%b %Y %H:%M:%S")))
						for key, group in groupby(sorted_corpus, lambda source: source[0]):
							g = list(group) # print ("Group as list: {}".format(list(g)))
							if len(g) == 1: # print("Write to unique as 1 src = 1 tgt")
								for hash_s,hash_t,src,tgt in g:
									cnt_unique = cnt_unique + 1
									fwSrc.write(u"{}\n".format(src)) # print('UNIQUE: {} -||- {}'.format(src,tgt))
									fwTgt.write(u"{}\n".format(tgt))
							else: # there are several translations, get the most frequent
								r = sorted(Counter(g).most_common(), key=lambda x: (-x[1], x[0]))
								c_tgt = ''
								c_src = ''
								if sum([occ for f, occ in r]) == len(r): # if all second items in list of tuples are different
									c_tgt = r[-1][0][3] # print("All tgts are different, using last: {}".format(r[-1][0][3]))
									c_src = r[-1][0][2]
								else: # else print the most common
									c_tgt = r[0][0][3] # print("The most common tgt is {}".format(r[0][0][3]))
									c_src = r[0][0][2]
								fwSrc.write(u"{}\n".format(c_src)) # print('Most Common: {} -||- {}'.format(key, c_tgt))
								fwTgt.write(u"{}\n".format(c_tgt))
								cnt_unique = cnt_unique + 1
								# removing dupes?
								for hash_s, hash_t, source, target in g:
									if target != c_tgt: # we already took that one out to unique
										fwDupes.write(u'{src}\n{tgt}\n'.format(src=c_src,tgt=c_tgt)) # print('DUPES TO REMOVE: {src} -||- {tgt}'.format(src=source,tgt=target))
										# print('DUPES TO REMOVE: {src} -||- {tgt}'.format(src=source,tgt=target))
							#print('--- Group END ---')
		end = time.time()
		end_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
		fwLog.write(u"Processed: {} segments.\nUnique segments: {}.\nDuplicate segments: {}.\nTime spent: {} ({} - {}).".format(cnt_total, cnt_unique, cnt_total - cnt_unique,end - start, start_time, end_time))
		fwDupes.close()
		fwLog.close()
#		if debug <> 0:
#			fwDebug.close()

		print(u"Processed: {} segments out of {} lines read.".format(cnt_total, idx))
		print(u"Dupe segments: {}.".format(cnt_total-cnt_unique))
		print(u"Unique segments: {}.".format(cnt_unique))
		print(u"Time spent: {} ({} - {}).".format(end - start, start_time, end_time))

	print("====================== DEDUPE/PRUNE END ===============================")

if __name__ == "__main__":
	main(sys.argv[1:])

