#!/usr/bin/python3

###### SHOULD BE RUN ON PLAIN TEXT ALREADY
###### SAMPLE USAGE #########################
# python3 /OpenNMT/tools/shrink2.py srcFile tgtFILE max_segments [src|tgt] [update_value] discarded_output_as_parallel[0|1]
# python3 /OpenNMT/tools/shrink2.py /Engines/Gen/ENKO/${s} /Engines/Gen/ENKO/${t} 8000000 src 1000000 0
# TEST: https://ideone.com/ItAI2i, newest: https://ideone.com/QT8Ayf
##############################################

import io, re, sys, hashlib, time, unicodedata, datetime, random
#from itertools import izip
#from itertools import *
#from collections import Counter

def main(argv):
	src_file = argv[0]
	tgt_file = argv[1]
	max_segments = int(argv[2])
	scope = "src"
	if argv[3] not in ['src','tgt']:
		print("The 5th param should be either 'src' or 'tgt'! Aborting...")
		exit(-1)
		#scope=argv[3]
	update_every = 100000
	if len(argv) > 4:
		update_every = int(argv[4])
	discarded_parallel = False # How we want to output the discarded data
	if len(argv) > 5:
		if (argv[4].isdigit() and int(argv[4]) > 0) or argv[4].lower() == 'true':
			discarded_parallel = True
	cnt_total = 0

	print("====================== SHRINKING CORPORA TO {} SEGMENTS ===================================".format(max_segments))
	print("Source: {}\nTarget: {}\nMax segments: {}\nUpdate Every: {}\nScope: {}".format(src_file,tgt_file,max_segments,update_every,scope))

	import time
	start_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
	start = time.time()
	utable = {} # A new table with seg count: frequencies
	table = {}
	num_wc_tbl = {}
	cnt=0
	with io.open(src_file,'r',encoding='utf8', newline='\n') as frSrc, io.open(tgt_file,'r',encoding='utf8', newline='\n') as frTgt:
		for src, tgt in zip(frSrc, frTgt): # WE MAY PRUNE RIGHT HERE TO AVOID ADDING USELESS SEGMENTS TO LIST
			#cnt_total=cnt_total+1
			#if cnt_total % update_every == 0:
			#	print("Processed {} lines...".format(cnt_total))
			sgt = ''
			if scope == 'src':
				sgt = src
			elif scope == 'tgt':
				sgt = tgt
			sgt_len = len(sgt.strip().split())
			if sgt_len in table:
				table[sgt_len] += 1
				num_wc_tbl[sgt_len].append(cnt)
			else:
				table[sgt_len] = 1
				num_wc_tbl[sgt_len] = [cnt]
			cnt +=1 # ID of segment
	# READ THE FILES
	total = sum(list(table.values())) # total segment count
	print("Total segment count: {}\nTable: {}".format(total,table))
	#ratios = [x/total*100 for x in list(table.values())]
	#print("Ratios: {}".format(ratios))
	scale_out_value = total / max_segments  # we need to shrink by scale_out_value times
	print("Scale-out value: {}".format(scale_out_value))
	for cnt,freq in table.items():
		num_add = 1 if cnt < 51 else 0
		utable[cnt] = int(freq/scale_out_value) or num_add # If output is less than 1, set to extract 1 segment
	print("New segment count: {}\nNew table: {}".format(sum(list(utable.values())), utable))
	########http://rextester.com/PCPDX7393

	cnt_total = 0
	new_total = 0
	fwDiscardSrc = None
	fwDiscardTgt = None
	if discarded_parallel:
		fwDiscardSrc = io.open("{}.discarded".format(src_file), 'w', encoding='utf-8', newline='\n')
		fwDiscardTgt = io.open("{}.discarded".format(tgt_file), 'w', encoding='utf-8', newline='\n')

	take_IDs = [] # Segment IDs to extract
	for x,y in utable.items(): # utable[1]=3, y = max value to extract
		rnd1 = random.sample(num_wc_tbl[x], y) # num_wc_tbl[1] = [1, 4, 7, 8, 9]
		take_IDs.extend(rnd1)
		#print("For {}, {}".format(x, rnd1))

	take_IDs=sorted(take_IDs)
	print("Segment IDs to output: {}".format(take_IDs))
	#idx = take_IDs.pop(0)
	id_cnt = 0
	write_to_discarded=False

	with io.open("{}.filtered".format(src_file), 'w', encoding='utf-8', newline='\n') as  fwFilteredSrc:
		with io.open("{}.filtered".format(tgt_file), 'w', encoding='utf-8', newline='\n') as  fwFilteredTgt:
			with io.open(src_file,'r',encoding='utf8', newline='\n') as frSrc, io.open(tgt_file,'r',encoding='utf8', newline='\n') as frTgt:
				for src, tgt in zip(frSrc, frTgt):
					if cnt_total % update_every == 0:
						print("Processed {} lines...".format(cnt_total))
					#sgt_len = len(sgt.strip().split())
					#tracking_table[sgt_len] += 1 # increment the x-word segment counter
					if write_to_discarded:
						if discarded_parallel:
							fwDiscardSrc.write(src)
							fwDiscardTgt.write(tgt)
					#print("Processing {} of {}, line = '{}'".format(id_cnt, cnt_total, src.strip()))
					elif cnt_total == take_IDs[id_cnt]: #if tracking_table[sgt_len] in skip_table[sgt_len]:
						id_cnt+=1
						if (id_cnt == len(take_IDs)):
							write_to_discarded = True
						fwFilteredSrc.write(src)
						fwFilteredTgt.write(tgt)
						#print("Writing: '{}' ({})".format(src.strip(), cnt_total))
					elif discarded_parallel:
						fwDiscardSrc.write(src)
						fwDiscardTgt.write(tgt)
					cnt_total += 1

	end = time.time()
	end_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
	print("Processed: {} segments.\nNew corpus TUs: {}.\nDiscarded TUs: {}.\nTime spent: {} ({} - {}).".format(cnt_total, id_cnt, cnt_total-id_cnt, end - start, start_time, end_time))
	if discarded_parallel:
		fwDiscardSrc.close()
		fwDiscardTgt.close()

#	print("Processed: {} segments.".format(cnt_total))
#	print("Dupe segments: {}.".format(cnt_total-cnt_unique))
#	print("Unique segments: {}.".format(cnt_unique))
#	print("Time spent: {} ({} - {}).".format(end - start, start_time, end_time))

	print("====================== CORPUS SHRINKING END ===============================")

if __name__ == "__main__":
	main(sys.argv[1:])



