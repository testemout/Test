#!/usr/bin/python3
#################################################### SAMPLE USAGE ##############################################
#  Author: Wiktor Stribizew                                                                                    #
#  Date created: March 15, 2018                                                                                #
#  Date updated: March 16, 2018                                                                                #
# "python.exe" "guesslang3.py" "C:\praca\NLP\LanguageGuessing\2018-03-15\EY_20180311_TEXT" "ProjectName" 500   #
#                                                                                                              #
# PRE-REQUISITES:                                                                                              #
#  1. Python 3                                                                                                 #
#  2. pip install chardet                                                                                      #
#  3. pip install langdetect                                                                                   #
#                                                                                                              #
# TESTING:                                                                                                     #
# Uncomment DEBUG_MODE = True if you need to check how clean-up works                                          #
################################################################################################################
import ntpath, re, sys, io, time, chardet, codecs
from datetime import datetime
from langdetect import DetectorFactory
from langdetect import detect, detect_langs
import os
from os import listdir
from os.path import isfile, join

# Set the DEBUG mode on and off
DEBUG_MODE = False
#DEBUG_MODE = True

def getFiles(foldr):
    # files = os.listdir(foldr) # will get folders and files
    return [join(foldr, f) for f in listdir(foldr) if isfile(join(foldr, f))]
    #for file in files:   print(detect_langs("Otec matka syn."))

def normContents(text): # Regex tested at https://regex101.com/r/6mrNSR/2
    text = re.sub(r"(?im)^(?:Original-Message-ID:\s*<[^>]+>|(?:Recipient|To|Sen(?:t|der)|b?Cc):.*(?:[\r\n]+(?:    |\t).*)*|(?:(?:Subject|From|Date|Final-recipient|Disposition|X-MSExch-Correlation-Key|X-Display-Name|Message-Id):|-------- .* --------).*\s*)", "", text)
    return text.strip()
    #print(text)
    #return re.sub(r"\s+", " ", text).strip()

def main(argv):
    foldr = argv[0]
    update_every = 100
    report_suffix = ntpath.dirname(foldr)
    if len(argv) > 1:
        report_suffix = argv[1]
    if len(argv) > 2:
        update_every = int(argv[2])
    cnt_total = 0

    print("====================== LANGUAGE GUESSING... ===================================")
    start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    start = time.time()
    fwDNT = io.open("{}\\{}_lgreport.txt".format(ntpath.dirname(foldr), report_suffix), 'w', encoding='utf8', newline='\n')
    DetectorFactory.seed = 0 # Language detection algorithm is non-deterministic, which
    # means that if you try to run it on a text which is either too short or too ambiguous,
    # you might get different results everytime you run it. To enforce consistent results,
    # call following code before the first language detection.
    for file in getFiles(foldr):
        cnt_total = cnt_total + 1
        if cnt_total % update_every == 0:
            print("{} files processed...".format(cnt_total))

        file_encoding = 'utf-8'
        bytes = min(32, os.path.getsize(file))
        raw = open(file, 'rb').read(bytes)
        if raw.startswith(codecs.BOM_UTF8):
            file_encoding = 'utf-8-sig'
        else:
            result = chardet.detect(raw)
            file_encoding = result['encoding']
        with io.open(file,'r',encoding=file_encoding, newline='\n') as frSrc:
            contents = frSrc.read()
            ncnts = normContents(contents)
            if len(ncnts) == 0:
                fwDNT.write("{}\t{}\n".format(ntpath.basename(file), "Empty"))
            else:
                if not DEBUG_MODE:
                    fwDNT.write("{}\t{}\n".format(ntpath.basename(file), detect(ncnts)))
            if DEBUG_MODE:
                with io.open("{}\\{}_norm.txt".format(foldr, ntpath.basename(file)), 'w', encoding='utf8', newline='\n') as fwDebug:
                     fwDebug.write(ncnts)
            # fwDNT.write(u"{}\t{}\n".format(ntpath.basename(file), detect(contents)))

    end = time.time()
    end_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print(u"Processed: {} files.\nTime spent: {} ({} - {}).".format(cnt_total, end - start, start_time, end_time))
    fwDNT.close()
    print("====================== LANGUAGE GUESSING COMPLETE. ===================================")

if __name__ == "__main__":
    main(sys.argv[1:])
