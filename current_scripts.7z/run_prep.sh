#!/bin/bash

###### RUN WF TM PREP FOR NMT
# Created by: Wiktor Stribiżew
# Created on: Feb 28, 2019
# Edited:
# History:
# USAGE: nohup nice bash /OpenNMT/tools/run_prep.sh $fldr $file $src $tgt > /Engines/MyProj/MyProj_prep_process.rpt 2>&1 &
#
###############################

fldr="$1"
file="$2"
src="$3"
tgt="$4"

echo "Folder: $fldr"
echo "File: $file"
echo "Src: $src"
echo "Tgt: $tgt"

onmt="/OpenNMT/tools"
wf_tm_prep_script="$onmt"/prep_wf_tm2.py
partition_script="$onmt"/partition.sh

cd "$fldr"
python "${partition_script}" "$fldr/$file"  "$src" "$tgt" 2 0 500000 "" 1
bash "$partition_script" "$file"."$src".dedupe "$file"."$tgt".dedupe 1999
rm *.log


