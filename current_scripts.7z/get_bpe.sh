# $1 = 2 letter lang code, $2 = {src,tgt}
function get_bpe {
  if [[ "$1" == "CZ" ]]; then
    echo "Gen_ENCZ_trainall.tok.bpe";
  elif [[ "$1" == "DE" ]]; then
    echo "Gen_ENDE_trainall.tok.bpe";
  elif [[ "$1" == "ESES" || "$1" == "ES" ]]; then
    echo "Gen_ENESES_trainall.tok.bpe";
  elif [[ "$1" == "ESLA" ]]; then
    echo "Gen_ENESLA_trainall.tok.bpe";
  elif [[ "$1" == "FR" ]]; then
    echo "Gen_ENFR_trainall.tok.bpe";
  elif [[ "$1" == "FRCA" ]]; then
    echo "Gen_ENFR_trainall.tok.bpe"; # TEMPORARY FRCA
  elif [[ "$1" == "IT" ]]; then
    echo "Gen_ENIT_trainall.tok.bpe";
  elif [[ "$1" == "JA" && "$2" == "tgt" ]]; then # ENJA tgt only
    echo "Gen_ENJA_trainall.tok.bpe";
  elif [[ "$1" == "KO" ]]; then
    echo "Gen_ENKO_trainall.tok.bpe";
  elif [[ "$1" == "PL" ]]; then
    echo "Gen_ENPL_trainall.tok.bpe";
  elif [[ "$1" == "PTBR" ]]; then
    echo "Gen_ENPTBR_trainall.tok.bpe";
  elif [[ "$1" == "PTPT" ]]; then
    echo "Gen_ENPTPT_trainall.tok.bpe";
  elif [[ "$1" == "RU" ]]; then
    echo "Gen_ENRU_20181218.tok.bpe"
    #echo "Gen_ENRU_trainall_13_3.85.tok.bpe";
  elif [[ "$1" == "SK" ]]; then
    echo "Gen_ENSK_trainall.tok.bpe";
  elif [[ "$1" == "UK" ]]; then
    echo "Gen_ENUA_trainall.tok.bpe";
  elif [[ "$1" == "ZHCN" ]]; then
    echo "Gen_ENZH_trainall.tok.bpe";
  elif [[  "$1" == "ID" ]]; then
    echo "Generic_ENID_trainall.tok.bpe";
  elif [[ "$1" == "NO" ]]; then
    echo "Gen_ENNO_trainall.tok.bpe"
  elif [[ "$1" == "NL" ]]; then
    echo "Gen_ENNL_trainall.tok.bpe"
  elif [[  "$1" == "DA" ]]; then
    echo "Gen_ENDA_trainall.tok.bpe";
#  elif [[  "$1" == "" ]]; then
#    echo "";
#  elif [[  "$1" == "" && "$2" == "src" ]]; then
#    echo "";
  fi;
}
