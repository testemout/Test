

#!/bin/bash
#HELP: Bash arrays http://www.linuxjournal.com/content/bash-arrays
# This script partitions files into 3 chunks: training, testing, tuning (=validation)
echo "====================== PARTITION START ==================================="
echo "Src file: $1"
echo "Tgt file: $2"
echo "Number of  segments to extract for testing and validation corpora chunks: $3"
NUMTOEXTRACT=$3 # Number of segments to extract from corpus
NUMOFLINES="$(wc -l < $1)" # Here, we have file line count, upper limit, with awk: `awk 'END {print NR,"lines"}' filename`
NUMOFLINESTGT="$(wc -l < $2)"
if [[ $NUMOFLINES -ne $NUMOFLINESTGT ]]; then
        echo "The number of source and target segments differ in $1 and $2!"
        exit
fi
echo  "Number of lines/Segment # to extract: $NUMOFLINES/$NUMTOEXTRACT"
if [[ $NUMOFLINES -le $NUMTOEXTRACT ]]; then
        echo "There are too few segments to extract ${NUMTOEXTRACT} segments from the file (with ${NUMOFLINES} lines)!"
        exit
fi
echo "There are $NUMTOEXTRACT segments in the coprus, proceeding..."
IDSS=$(shuf -i 1-$NUMOFLINES -n $NUMTOEXTRACT| sort -n) # removed  | sort -n from end; an array to store random segment IDs for both testing and training, numbers are unique
# echo QUOTE${IDS[@]}QUOTE # DISABLE!!!!
#PROJDIR="$(cut -d'.' -f2 <<< $1)" # This gets the substring between the 2nd and 3rd . in a string
#echo "The following subdirectory will be created: $PROJDIR"
#mkdir $PROJDIR
#cd $PROJDIR
# The above lines are commented out since the files are already in the right folder
echo "${IDSS[@]}" > ids-bash.log
export mdcList=${IDSS[0]} # https://stackoverflow.com/questions/33829444/passing-bash-array-to-python-list
for i in "${IDSS[@]:1}"; do
   mdcList+=,$i
done
echo "Current directory: ${PWD}"
echo "Number of IDs: ${#IDSS[*]}, passing the array to the Python script..."
python /OpenNMT/tools/splitfile2.py "$1" "$2" "IDSS_DUMMY_VALUE" "${PWD}"
#We pass source, target files, then IDs to split out and the current directory
echo "====================== PARTITION END ==================================="
