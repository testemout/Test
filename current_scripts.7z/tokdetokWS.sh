#!/bin/bash

#echo "1: $1"
#echo "2: $2"
#echo "3: $3"
#echo "4: $4"
#read -p "WOW...."
if [[ $2 == tok ]]; then
        cat $1 | sed 's/ "/ XCSX /g' \
               | sed -E "s,</?STRONG>,,gi" \
               | sed 's/" / XCEX /g' \
               | sed 's/”,/ ”,/g'    \
               | sed 's/\([a-zA-Z0-9]\)“ /\1” /g' \
               | sed 's/ ”\([a-zA-Z0-9]\)/ “\1/g' \
               | sed 's/\([.:;,>!\/”»"\)]\) / \1 /g' \
               | sed 's/ \([<«“"(]\)/ \1 /g' \
               | sed 's/\([.:;,>!\/”»"\)]\)$/ \1/' \
               | sed 's/[[:blank:]][[:blank:]]*/ /g' \
               | sed 's/,”/ &/g' \
               | sed "s/) ,/ ),/g" \
               | sed "s/e\.g \./e\.g\./g" \
               | sed "s/\([a-zA-Z][a-zA-Z][a-zA-Z][a-zA-Z][a-zA-Z]*\)\/\([a-zA-Z][a-zA-Z][a-zA-Z][a-zA-Z][a-zA-Z]*\)/\1 \/ \2/g" \
               | sed "s/( \([0-9]*\) )/(\1)/g" \
               | sed "s/ \([a-zA-Z]\) )/ \1)/g" \
               | sed "s/\?/ \?/g" \
               | sed "s/” \./ ” \./g" \
               | sed "s/XXBARRAXX/\//g" \
               | sed "s/XXINTIXX/?/g" \
               | sed "s/The hotel’s/The hotel/g" \
               | sed "s/^*/* /" \
               | sed "s/\(\&'\([A-Z]\|[0-9]\{1,4\}\);\)\+/ /g" \
                   > $3
        if [[ $4 == CJK ]]; then
                perl -CIOED -p -i -e 's/(?<=[\p{Hiragana}\p{Katakana}\p{Han}\x{0E00}-\x{0E7F}])(?=[\x{0E00}-\x{0E7F}A-Za-z0-9\p{Han}\p{Hiragana}\p{Katakana}])|(?<=[A-Za-z0-9])(?=[\x{0E00}-\x{0E7F}\p{Han}\p{Hiragana}\p{Katakana}])/ /g' $3  # SEE THE REGEX DEMO AT https://regex101.com/r/0VNKOP/1
        fi
else
        cat $1  | sed "s/ \(\&'\([A-Z]\|[0-9]\{1,4\}\);\) /\\1/g" \
                | sed "s/ ?/?/g"                           \
                | sed 's/ \([.:;,>!\/”»")]\)$/\1/'         \
                | sed 's/ \([<«"“\(]\) / \1/g'             \
                | sed 's/ \([.:;,>!\/”»")]\) /\1 /g'       \
                | sed 's/[[:blank:]][[:blank:]]*/ /g'      \
                | sed 's/[[:blank:]],”/,”/g'               \
                | sed 's/[[:blank:]]+”,/”,/g'              \
                | sed 's/",/”,/g'                          \
                | sed "s/ ),/),/g"                         \
                | sed "s/- ((/-((/g"                       \
                | sed 's/ XCSX / "/g'                      \
                | sed 's/ XCEX /" /g'                      \
                | sed "s/ )\./)./g"                        \
                | sed "s/\([a-zA-Z][a-zA-Z][a-zA-Z][a-zA-Z][a-zA-Z]*\) \/ \([a-zA-Z][a-zA-Z][a-zA-Z][a-zA-Z][a-zA-Z]*\)/\1\/\2/g" \
		 > $3
        if [[ $4 == CJK ]]; then
                perl -CIOED -p -i -e 's/(?<=[\p{Hiragana}\p{Katakana}\p{Han}\x{0E00}-\x{0E7F}]) (?=[A-Za-z0-9\x{0E00}-\x{0E7F}\p{Han}\p{Hiragana}\p{Katakana}])|(?<=[A-Za-z0-9]) (?=[\x{0E00}-\x{0E7F}\p{Han}\p{Hiragana}\p{Katakana}])//g' $3
        fi
fi
