#!/usr/bin/python
# -*- coding: utf-8 -*-

import io, re, sys, hashlib, time, unicodedata
from datetime import datetime
from itertools import izip
from itertools import *
from collections import Counter

tbl = dict.fromkeys(i for i in xrange(sys.maxunicode) if unicodedata.category(unichr(i)).startswith('P'))
rx_is_segment_blank = re.compile(r'^\s*$', re.U)
rx_invalid_xml_chars = re.compile(r'(?![\r\n\t])[\x00-\x1F]')
rx_numeric = re.compile(r'^\d+$', re.U)
rx_email = re.compile(r'^\s*\S+@\S+\.\S+\s*$', re.U)
rx_url_encoded = re.compile(r'^\s*(?:%[0-9A-Fa-f]{2})+\s*$', re.U)
rx_no_letter = re.compile(r'^(?!.*[^\W\d_])', re.U)
rx_url = re.compile(r'^\s*(?:https?|ftp|gopher|telnet|file|notes|ms-help):(?://|\\\\)+[\w:#@%/;$()~_?+-=\\.\x26]*\s*$', re.I | re.U)
rx_html_entities = re.compile(r'^\s*(?:&#\d+;|&[a-zA-Z\d]+;)+(?:\s+(?:&#\d+;|&[a-zA-Z\d]+;)+)*\s*$', re.U)
rx_too_long = re.compile(r'^\W*\w+(?:\W+\w+){100}$', re.U) # More than 100 words
rx_alphanumeric = re.compile(r'^(?=\D*\d)(?=[\W\d_]*[^\W\d_])\s*[^\W_]+\s*$', re.U) # DO NOT USE FOR APAC!!!
# Combine all except rx_alphanumeric.pattern
rx_irrelevant = re.compile("|".join([rx_is_segment_blank.pattern, rx_invalid_xml_chars.pattern, rx_numeric.pattern, rx_email.pattern, rx_url_encoded.pattern, rx_no_letter.pattern, rx_url.pattern, rx_html_entities.pattern, rx_too_long.pattern]), re.I | re.U | re.S)

def remove_punctuation(text):
	return text.translate(tbl)

def is_irrelevant(src_seg, tgt_seg, lang): # TESTED AT https://ideone.com/WFm9T6
	#m = rx_is_segment_blank.search(src_seg) # if source or target is null or whitespace	 #if not m:		 m = rx_is_segment_blank.search(tgt_seg) if m:		  return true
	m = rx_irrelevant.search(src_seg)
	n = rx_irrelevant.search(tgt_seg)
	return m or n


def main(argv):
	src_file = argv[0]
	tgt_file = argv[1]
	pattern = argv[2]
	rx = None
	try:
		rx = re.compile(pattern)
	except:
		print("The '{}' pattern is invalid!".format(pattern))
		sys.exit(-1)
	update_every = 1000
	if len(argv) > 3:
		update_every = int(argv[3])
	cnt = 0
	cnt_total = 0

	print("====================== REGEX FILTERING IN PROGRESS ===================================")
	start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
	start = time.time()
	fwDiscard = io.open("{}.discarded".format(src_file), 'w', encoding='utf-8', newline='\n')
	with io.open("{}.filtered".format(src_file), 'w', encoding='utf-8', newline='\n') as  fwFilteredSrc:
		with io.open("{}.filtered".format(tgt_file), 'w', encoding='utf-8', newline='\n') as  fwFilteredTgt:
			with io.open(src_file,'r',encoding='utf8', newline='\n') as frSrc, io.open(tgt_file,'r',encoding='utf8', newline='\n') as frTgt:
				for src, tgt in izip(frSrc, frTgt): # WE MAY PRUNE RIGHT HERE TO AVOID ADDING USELESS SEGMENTS TO LIST
					cnt_total=cnt_total+1
					src = re.sub(u'[\u000B\u000C\u000D\u0085\u2028\u2029]+', u' ', src).strip()
					tgt = re.sub(u'[\u000B\u000C\u000D\u0085\u2028\u2029]+', u' ', tgt).strip()
					if rx.search(src) or rx.search(tgt):
						fwDiscard.write(u"{}\t{}\n".format(src.strip(), tgt.strip()))
					else:
						fwFilteredSrc.write(u"{}\n".format(src))
						fwFilteredTgt.write(u"{}\n".format(tgt))
						cnt=cnt+1

	end = time.time()
	end_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
	print("Processed: {} segments.\nFiltered TUs: {}.\nDiscarded TUs: {}.\nTime spent: {} ({} - {}).".format(cnt_total, cnt, cnt_total-cnt, end - start, start_time, end_time))
	fwDiscard.close()

#	print(u"Processed: {} segments.".format(cnt_total))
#	print(u"Dupe segments: {}.".format(cnt_total-cnt_unique))
#	print(u"Unique segments: {}.".format(cnt_unique))
#	print(u"Time spent: {} ({} - {}).".format(end - start, start_time, end_time))

	print("====================== REGEX FILTERING END ===============================")

if __name__ == "__main__":
	main(sys.argv[1:])

