#!/usr/bin/python3
#################################################### SAMPLE USAGE ##############################################
#  Author: Wiktor Stribizew                                                                                    #
#  Date created: July 19, 2018                                                                                 #
#  Date updated:                                                                                               #
# "python.exe" "filter_by_lang3.py" file_src file_tgt update_value                                             #
#                                                                                                              #
# PRE-REQUISITES:                                                                                              #
#  1. Python 3                                                                                                 #
#  2. pip install chardet                                                                                      #
#  3. pip install langdetect                                                                                   #
#                                                                                                              #
# TESTING:                                                                                                     #
# Uncomment DEBUG_MODE = True if you need to check how clean-up works                                          #
################################################################################################################
import ntpath, re, sys, io, time, codecs
from datetime import datetime
from langdetect import DetectorFactory
from langdetect import detect, detect_langs
import os
from os import listdir
from os.path import isfile, join

# Set the DEBUG mode on and off
DEBUG_MODE = False
#DEBUG_MODE = True

def normContents(text): # Regex tested at https://regex101.com/r/6mrNSR/2
    # text = re.sub(r"(?im)^(?:Original-Message-ID:\s*<[^>]+>|(?:Recipient|To|Sen(?:t|der)|b?Cc):.*(?:[\r\n]+(?:    |\t).*)*|(?:(?:Subject|From|Date|Final-recipient|Disposition|X-MSExch-Correlation-Key|X-Display-Name|Message-Id):|-------- .* --------).*\s*)", "", text)
    text = re.sub(r'[\W_]+', ' ', text)
    return text.strip()

def main(argv):
    src_file = argv[0]
    tgt_file = argv[1]
    srclang =  = argv[2]
    tgtlang =  = argv[3]
    update_every = 1000
    if len(argv) > 4:
        update_every = int(argv[4])
    cnt_total = 0

    print("====================== FILTERING OUT SEGMENTS IN NON-DECLARED LANGUAGES... ===================================")
    start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    start = time.time()
    fwSrcUnsure = io.open("{}.unsure".format(src_file), 'w', encoding='utf8', newline='\n')
    fwTgtUnsure = io.open("{}.unsure".format(tgt_file), 'w', encoding='utf8', newline='\n')
    DetectorFactory.seed = 0 # Language detection algorithm is non-deterministic, which
    # means that if you try to run it on a text which is either too short or too ambiguous,
    # you might get different results everytime you run it. To enforce consistent results,
    # call following code before the first language detection.
    with io.open("{}.sure".format(src_file), 'w', encoding='utf-8', newline='\n') as  fwSureSrc:
        with io.open("{}.sure".format(tgt_file), 'w', encoding='utf-8', newline='\n') as  fwSureTgt:
            with io.open(src_file,'r', encoding='utf8', newline='\n') as frSrc, io.open(tgt_file,'r',encoding='utf8', newline='\n') as frTgt:
                for src, tgt in izip(frSrc, frTgt):
                cnt_total=cnt_total+1
                if cnt_total % update_every == 0:
                    print("Processed {} lines...".format(cnt_total))
                src = re.sub('[\u000B\u000C\u000D\u0085\u2028\u2029]+', ' ', src.replace(u'\u200E', '')).strip()
                tgt = re.sub('[\u000B\u000C\u000D\u0085\u2028\u2029]+', ' ', tgt.replace(u'\u200E', '')).strip()
                #ncnts = normContents(contents)
                src_guessed_lang=detect(src)
                tgt_guessed_lang=detect(tgt)
                if srclang.upper() == src_guessed_lang.upper() and tgtlang.upper() == tgt_sure_lang.upper():
                    fwSureSrc.write("{}\n".format(src))
                    fwSureTgt.write("{}\n".format(tgt))
                else:
                    fwSrcUnsure.write("{}\n".format(src))
                    fwTgtUnsure.write("{}\n".format(tgt))

    end = time.time()
    end_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print(u"Processed: {} files.\nTime spent: {} ({} - {}).".format(cnt_total, end - start, start_time, end_time))
    fwDNT.close()
    print("====================== LANGUAGE FILTERING COMPLETE. ===================================")

if __name__ == "__main__":
    main(sys.argv[1:])
