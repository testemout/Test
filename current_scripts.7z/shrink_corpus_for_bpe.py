#!/usr/bin/python3
#####################################3
#
# python3 /OpenNMT/tools/shrink_corpus_for_bpe.py src tgt 1000000
#
#####################################

import re, sys, hashlib, time, unicodedata, io
from datetime import datetime
from itertools import *
from collections import Counter

debug = 0
fwDebug = None

#https://towardsdatascience.com/implementing-a-trie-data-structure-in-python-in-less-than-100-lines-of-code-a877ea23c1a1
class TrieNode(object):
	"""
	Our trie node implementation. Very basic. but does the job
	"""

	def __init__(self, char: str):
		self.char = char
		self.children = []
		# Is it the last character of the word.`
		self.word_finished = False
		# How many times this character appeared in the addition process
		self.counter = 1


def add(root, word: str):
	"""
	Adding a word in the trie structure
	"""
	node = root
	for char in word:
		added_as_whole_unique_word = False
		found_in_child = False
		# Search for the character in the children of the present `node`
		for child in node.children:
			if child.char == char:
				# We found it, increase the counter by 1 to keep track that another
				# word has it as well
				child.counter += 1
				# And point the node to the child that contains this char
				node = child
				found_in_child = True
				break
		# We did not find it so add a new chlid
		if not found_in_child:
			new_node = TrieNode(char)
			node.children.append(new_node)
			# And then point node to the new child
			node = new_node
			added_as_whole_unique_word = True
	# Everything finished. Mark it as the end of a word.
	if node.word_finished: # If the current node has word_finished as True, it was added as whole word
		added_as_whole_unique_word = False
	else:
		added_as_whole_unique_word = True
		node.word_finished = True
	return added_as_whole_unique_word


def find_prefix(root, prefix: str) -> bool: #Tuple[bool, int]:
	"""
	Check and return
	  1. If the prefix exsists in any of the words we added so far
	  2. If yes then how may words actually have the prefix
	"""
	node = root
	# If the root node has no children, then return False.
	# Because it means we are trying to search in an empty trie
	if not root.children:
		return False, 0
	for char in prefix:
		char_not_found = True
		# Search through all the children of the present `node`
		for child in node.children:
			if child.char == char:
				# We found the char existing in the child.
				char_not_found = False
				# Assign node as the child containing the char and break
				node = child
				break
		# Return False anyway when we did not find a char.
		if char_not_found:
			return False #, 0
	# Well, we are here means we have found the prefix. Return true to indicate that
	# And also the counter of the last node. This indicates how many words have this
	# prefix
	return node.word_finished
	# return True, node.counter

tbl = dict.fromkeys(i for i in range(sys.maxunicode) if unicodedata.category(chr(i)).startswith('P'))
rx_is_segment_blank = re.compile(r'^\s*$')
rx_invalid_xml_chars = re.compile(r'(?![\r\n\t])[\x00-\x1F]')
rx_numeric = re.compile(r'^\d+$')
rx_email = re.compile(r'^\s*\S+@\S+\.\S+\s*$', re.U)
rx_url_encoded = re.compile(r'^\s*(?:%[0-9A-Fa-f]{2})+\s*$')
rx_no_letter = re.compile(r'^(?!.*[^\W\d_])')
rx_url = re.compile(r'^\s*(?:https?|ftp|gopher|telnet|file|notes|ms-help):(?://|\\\\)+[\w:#@%/;$()~_?+-=\\.\x26]*\s*$', re.I)
rx_html_entities = re.compile(r'^\s*(?:&#\d+;|&[a-zA-Z\d]+;)+(?:\s+(?:&#\d+;|&[a-zA-Z\d]+;)+)*\s*$')
rx_too_long = re.compile(r'^\W*\w+(?:\W+\w+){100}$') # More than 100 words
rx_alphanumeric = re.compile(r'^(?=\D*\d)(?=[\W\d_]*[^\W\d_])\s*[^\W_]+\s*$') # DO NOT USE FOR APAC!!!
# Combine all except rx_alphanumeric.pattern
rx_irrelevant = re.compile("|".join([rx_is_segment_blank.pattern, rx_invalid_xml_chars.pattern, rx_numeric.pattern, rx_email.pattern, rx_url_encoded.pattern, rx_no_letter.pattern, rx_url.pattern, rx_html_entities.pattern, rx_too_long.pattern]), re.I | re.U | re.S)
rx_nonalnum = re.compile(r"[^\w_]+")

def remove_punctuation(text):
	return text.translate(tbl)

def is_irrelevant(src_seg, tgt_seg, lang): # TESTED AT https://ideone.com/WFm9T6
	#m = rx_is_segment_blank.search(src_seg) # if source or target is null or whitespace	 #if not m:		 m = rx_is_segment_blank.search(tgt_seg) if m:		  return true
	m = rx_irrelevant.search(src_seg)
	n = rx_irrelevant.search(tgt_seg)
	return m or n


def main(argv):
	src_file = argv[0]
	tgt_file = argv[1]
	update_every = 1000
	if len(argv) > 2:
		update_every = int(argv[2])

	print("Source file: {}\nTarget file: {}\nProgress update each # of segments: {}".format(src_file, tgt_file, update_every))

	words_rx = re.compile(r'\w+')
	src_tokens = TrieNode('*')
	tgt_tokens = TrieNode('*')

	arr = []
	cnt_total = 0
	cnt = 0
	idx = 0
	corpus = []

	print("====================== Start Prep Corpus for BPE ===================================")
	start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
#	if debug <> 0:
#		fwDebug=io.open("{}.debug.log".format(src_file), 'w', encoding='utf8',newline='\n')
	start = time.time()
	fwDNT = io.open("{}.dnt.log".format(src_file), 'w', encoding='utf8',newline='\n')
	with io.open("{}.irrelevant.log".format(src_file), 'w', encoding='utf8',newline='\n') as  fwLog:
		with io.open("{}.for_bpe".format(src_file),'w',encoding='utf8',newline='\n') as fwSrc:
			with io.open("{}.for_bpe".format(tgt_file),'w',encoding='utf8',newline='\n') as fwTgt:
				with io.open(src_file,'r',encoding='utf8',newline='\n') as frSrc, io.open(tgt_file,'r',encoding='utf8',newline='\n') as frTgt:
					for src, tgt in zip(frSrc, frTgt):
						idx = idx + 1
						src = re.sub(u'[\u000B\u000C\u000D\u0085\u2028\u2029]+', u' ', src).strip()
						tgt = re.sub(u'[\u000B\u000C\u000D\u0085\u2028\u2029]+', u' ', tgt).strip()
						if len(src) == 0 or len(tgt) == 0:
							fwLog.write("{}\t{}\n".format(src, tgt))
#							print("{}:{}:::{}".format(idx, src,tgt))
							continue
						if rx_nonalnum.sub("", src) == rx_nonalnum.sub("", tgt):
							fwDNT.write("{}\t{}\n".format(src, tgt))
							continue
						elif is_irrelevant(src, tgt, ''):
							fwLog.write("{}\t{}\n".format(src, tgt))
							continue
						# Start collecting data
						ret = False # Added as whole word at least once
						for word in words_rx.findall(src.lower()):
							ret |= add(src_tokens, word)         # Adding src word to src_tokens TRIE
						for word in words_rx.findall(tgt.lower()):
							ret |= add(tgt_tokens, word)         # Adding src word to tgt_tokens TRIE
						# All words are now in tries
						if ret: # at least one word was a new whole word
							fwSrc.write("{}\n".format(src))
							fwTgt.write("{}\n".format(tgt))
							cnt += 1
						if cnt_total % update_every == 0:
							print(r"{}: Processed {} segments, continuing...".format(datetime.now().strftime("%d.%b %Y %H:%M:%S"), cnt_total))
						cnt_total = cnt_total + 1

		end = time.time()
		end_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

		print("Processed: {} segments out of {} lines read.".format(cnt_total, idx))
		print("Dupe segments: {}.".format(cnt_total))
		print("Unique segments written: {}.".format(cnt))
		print("Time spent: {} ({} - {}).".format(end - start, start_time, end_time))

		fwLog.write("Processed: {} segments.\nSegments with unique words: {}.\nTime spent: {} ({} - {}).".format(cnt_total, cnt, end - start, start_time, end_time))
		fwLog.close()

	print("====================== Prep Corpus for BPE END ===============================")

if __name__ == "__main__":
	main(sys.argv[1:])


