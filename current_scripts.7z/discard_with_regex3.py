#!/usr/bin/python3

###################### USAGE ############################
# python3 /OpenNMT09/OpenNMT/discard_with_regex3.py sfile tfile regex invert[1|0] update[10000] scope=[both|src|tgt]
###################### /USAGE ###########################
import io, re, sys, hashlib, time, unicodedata
from datetime import datetime
from itertools import *
from collections import Counter

tbl = dict.fromkeys(i for i in range(sys.maxunicode) if unicodedata.category(chr(i)).startswith('P'))
rx_is_segment_blank = re.compile(r'^\s*$')
rx_invalid_xml_chars = re.compile(r'(?![\r\n\t])[\x00-\x1F]')
rx_numeric = re.compile(r'^\d+$')
rx_email = re.compile(r'^\s*\S+@\S+\.\S+\s*$')
rx_url_encoded = re.compile(r'^\s*(?:%[0-9A-Fa-f]{2})+\s*$')
rx_no_letter = re.compile(r'^(?!.*[^\W\d_])')
rx_url = re.compile(r'^\s*(?:https?|ftp|gopher|telnet|file|notes|ms-help):(?://|\\\\)+[\w:#@%/;$()~_?+-=\\.\x26]*\s*$', re.I)
rx_html_entities = re.compile(r'^\s*(?:&#\d+;|&[a-zA-Z\d]+;)+(?:\s+(?:&#\d+;|&[a-zA-Z\d]+;)+)*\s*$')
rx_too_long = re.compile(r'^\W*\w+(?:\W+\w+){99,}$') # More than 100 words
rx_alphanumeric = re.compile(r'^(?=\D*\d)(?=[\W\d_]*[^\W\d_])\s*[^\W_]+\s*$') # DO NOT USE FOR APAC!!!
rx_corrupt=re.compile(r'[\u00EB\u00AA\u00A8\u00EB\u00A1\u00EA\u00EC\u00A4\u00EC\u00B6\u2022\u0160\u0153\u0152\u00EA\u00B2\u00A4\u00AC\u2039\u00A5\u00BC\u00A6\u2020\u00B6\u008A]')
# Combine all except rx_alphanumeric.pattern
rx_irrelevant = re.compile("|".join([rx_corrupt.pattern,rx_is_segment_blank.pattern, rx_invalid_xml_chars.pattern, rx_numeric.pattern, rx_email.pattern, rx_url_encoded.pattern, rx_no_letter.pattern, rx_url.pattern, rx_html_entities.pattern, rx_too_long.pattern]), re.I | re.S)

def remove_punctuation(text):
	return text.translate(tbl)

def is_irrelevant(src_seg, tgt_seg, lang): # TESTED AT https://ideone.com/WFm9T6
	#m = rx_is_segment_blank.search(src_seg) # if source or target is null or whitespace	 #if not m:		 m = rx_is_segment_blank.search(tgt_seg) if m:		  return true
	m = rx_irrelevant.search(src_seg)
	n = rx_irrelevant.search(tgt_seg)
	return m or n

USAGE = "USAGE: python3 /OpenNMT09/OpenNMT/discard_with_regex3.py sfile tfile regex invert[1|0] update[10000] scope=[both|src|tgt]"

def main(argv):
	src_file = argv[0]
	tgt_file = argv[1]
	pattern = argv[2]
	reverse=None
	if argv[3].lower() in ['true', '1']:
		reverse=True
		print("Reverse (invert regex results) set to True")
	print("Reverse: {}".format(str(reverse)))
	rx = None
	try:
		rx = re.compile(pattern)
	except:
		print("The '{}' pattern is invalid!".format(pattern))
		print(USAGE)
		sys.exit(-1)
	update_every = 50000
	scope = "both"
	if len(argv) > 4:
		update_every = int(argv[4])
	if len(argv) > 5:
		if argv[5] not in ['both','src','tgt']:
			print("The 5th param should be either 'both', 'src' or 'tgt'! Aborting...")
			print(USAGE)
			exit(-1)
		scope=argv[5]
	print("Scope: {}".format(scope))
	print("Update value: {}".format(update_every))
	cnt = 0
	cnt_total = 0

	print("====================== REGEX FILTERING IN PROGRESS ===================================")
	print("Source: {}\nTarget: {}\nPattern: {}\nUpdate Every: {}\nScope: {}".format(src_file,tgt_file,pattern,update_every,scope))
	start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
	start = time.time()
	fwDiscard = io.open("{}.discarded".format(src_file), 'w', encoding='utf-8', newline='\n')
	with io.open("{}.filtered".format(src_file), 'w', encoding='utf-8', newline='\n') as  fwFilteredSrc:
		with io.open("{}.filtered".format(tgt_file), 'w', encoding='utf-8', newline='\n') as  fwFilteredTgt:
			with io.open(src_file,'r',encoding='utf8', newline='\n') as frSrc, io.open(tgt_file,'r',encoding='utf8', newline='\n') as frTgt:
				for src, tgt in zip(frSrc, frTgt): # WE MAY PRUNE RIGHT HERE TO AVOID ADDING USELESS SEGMENTS TO LIST
					cnt_total=cnt_total+1
					if cnt_total % update_every == 0:
						print("Processed {} lines...".format(cnt_total))
					src = re.sub('[\u000B\u000C\u000D\u0085\u2028\u2029]+', ' ', src.replace('\u200E', '')).strip()
					tgt = re.sub('[\u000B\u000C\u000D\u0085\u2028\u2029]+', ' ', tgt.replace('\u200E', '')).strip()
					if not reverse:
						if (scope in ['both', 'src'] and rx.search(src)) or (scope in ['both','tgt'] and rx.search(tgt)): # or is_irrelevant(src, tgt, ""):
							fwDiscard.write("{}\t{}\n".format(src.strip(), tgt.strip()))
							print("Discarded: {}\t{}\n".format(src.strip(), tgt.strip()))
						else:
							fwFilteredSrc.write("{}\n".format(src))
							fwFilteredTgt.write("{}\n".format(tgt))
							cnt=cnt+1
					else: # reverse
						if (scope in ['both', 'src'] and not rx.search(src)) or (scope in ['both','tgt'] and not rx.search(tgt)): # or is_irrelevant(src, tgt, ""):
							fwDiscard.write("{}\t{}\n".format(src.strip(), tgt.strip()))
							print("Discarded: {}\t{}\n".format(src.strip(), tgt.strip()))
						else:
							fwFilteredSrc.write("{}\n".format(src))
							fwFilteredTgt.write("{}\n".format(tgt))
							cnt=cnt+1

	end = time.time()
	end_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
	print("Processed: {} segments.\nFiltered TUs: {}.\nDiscarded TUs: {}.\nTime spent: {} ({} - {}).".format(cnt_total, cnt, cnt_total-cnt, end - start, start_time, end_time))
	fwDiscard.close()

#	print("Processed: {} segments.".format(cnt_total))
#	print("Dupe segments: {}.".format(cnt_total-cnt_unique))
#	print("Unique segments: {}.".format(cnt_unique))
#	print("Time spent: {} ({} - {}).".format(end - start, start_time, end_time))

	print("====================== REGEX FILTERING END ===============================")

if __name__ == "__main__":
	main(sys.argv[1:])


