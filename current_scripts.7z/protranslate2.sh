#!/bin/bash

############################################## USAGEł
#
# bash /OpenNMT/tools/protranslate.sh model bpe srclng tgtlng fldr transFile glossFile
#
##############################################

# Protect GLOssary terms, translate and post-process
# SETTINGS
model="$1"
bpe="$2"

src="$3"
tgt="$4"
fldr="$5"
mkdir "$fldr/translated"
to_trans="$6"
gloss="$7"
gpuid="$8"
output_file="$fldr/translated/to_trans (translated from $src into $tgt).txt"
script=/OpenNMT/tools/prepterm5.py
### PREP ###
python3 "$script" "$to_trans" "$gloss" "prep" "$src" "$tgt"; mv "$to_trans.tmpx" "$to_trans.prep";
### TRANSLATION ###
cd /OpenNMT09/OpenNMT
th ./tools/tokenize.lua -mode aggressive -nparallel 6 -segment_numbers -segment_alphabet_change -segment_alphabet {Han,Thai,Katakana,Hiragana} -joiner_annotate -case_feature -bpe_model "$bpe" < "$to_trans.prep" > "$to_trans.prep.tok"
th translate.lua -model "$model" -src "$to_trans.prep.tok" -output "$to_trans.prep.tok.trans" -gpuid "$gpuid" -fallback_to_cpu 1> "$fldr/trans_log_${to_trans##*/}.rpt";
th ./tools/detokenize.lua -case_feature < "$to_trans.prep.tok.trans" > "$output_file.trans.detok"
### POST ###
python3 "$script" "$output_file.trans.detok" "$gloss" "post" "$src" "$tgt"
mv "$output_file.trans.detok.tmpx" "$output_file"
