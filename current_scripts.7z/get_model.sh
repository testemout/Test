# $1 = 2 letter lang code, $2 = {src,tgt}
function get_model {
  if [[ "$1" == "IT" && "$2" == "tgt" ]]; then    # IT
    echo "Gen_ENIT_epoch13_2.72.t7";
  elif [[  "$1" == "IT" && "$2" == "src" ]]; then
    echo "Gen_ITEN_epoch13_2.91.t7"
  elif [[  "$1" == "ES" && "$2" == "tgt" ]]; then # ESES
    echo "Gen_ENESES_epoch13_2.44.t7";
  elif [[  "$1" == "ES" && "$2" == "src" ]]; then
    echo "Gen_ESESEN_epoch13_2.81.t7"
  elif [[  "$1" == "ESES" && "$2" == "tgt" ]]; then
    echo "Gen_ENESES_epoch13_2.44.t7";
  elif [[  "$1" == "ESES" && "$2" == "src" ]]; then
    echo "Gen_ESESEN_epoch13_2.81.t7"
  elif [[  "$1" == "ESLA" && "$2" == "tgt" ]]; then
    echo "Gen_ENESLA_epoch13_2.05.t7";
  elif [[  "$1" == "FR" && "$2" == "tgt" ]]; then   # FR
    echo "Gen_ENFR_epoch13_2.89.t7"
  elif [[  "$1" == "FRCA" && "$2" == "tgt" ]]; then # FRCA TEMPORARY
    echo "Gen_ENFR_epoch13_2.89.t7"
  elif [[  "$1" == "FR" && "$2" == "src" ]]; then
    echo "Gen_FREN_epoch13_3.45.t7";
  elif [[  "$1" == "FRCA" && "$2" == "src" ]]; then # FRCA TEMPORARY
    echo "Gen_FREN_epoch13_3.45.t7";
  elif [[  "$1" == "DE" && "$2" == "tgt" ]]; then   # DE
    echo "Gen_ENDE_epoch15_4.22.t7"
  elif [[  "$1" == "DE" && "$2" == "src" ]]; then
    echo "Gen_DEEN_epoch15_2.94.t7";
  elif [[  "$1" == "PTBR" && "$2" == "tgt" ]]; then # PTBR
    echo "Gen_ENPTBR_epoch13_2.21.t7"
  elif [[  "$1" == "PTBR" && "$2" == "src" ]]; then
    echo "Gen_PTBREN_epoch13_2.30.t7";
  elif [[  "$1" == "NO" && "$2" == "tgt" ]]; then   # NO
    echo "Gen_ENNO_epoch13_2.68.t7"
  elif [[  "$1" == "NO" && "$2" == "src" ]]; then
    echo "Gen_NOEN_epoch13_2.55.t7";
  elif [[  "$1" == "PL" && "$2" == "tgt" ]]; then  # PL
    echo "Gen_ENPL_epoch4_3.57.t7"
  elif [[  "$1" == "PL" && "$2" == "src" ]]; then
    echo "Gen_PLEN_epoch13_3.80.t7";
  elif [[  "$1" == "NL" && "$2" == "tgt" ]]; then  # NL
    echo "Gen_ENNL_epoch13_2.49.t7"
  elif [[  "$1" == "NL" && "$2" == "src" ]]; then
    echo "Gen_NLEN_epoch13_2.47.t7";
  elif [[  "$1" == "AR" && "$2" == "tgt" ]]; then    # AR
    echo "Gen_ENAR_epoch13_3.89.t7"
  elif [[  "$1" == "AR" && "$2" == "src" ]]; then
    echo "Gen_AREN_epoch13_3.32.t7";
  elif [[  "$1" == "RU" && "$2" == "tgt" ]]; then    # RU
    echo "Gen_ENRU_epoch13_3.85.t7"
  elif [[  "$1" == "RU" && "$2" == "src" ]]; then
    echo "Gen_RUEN_epoch13_3.89.t7";
  elif [[  "$1" == "ZHCN" && "$2" == "tgt" ]]; then   # ZHCN
    echo "Gen_ENZHCN_epoch2_2.96.t7"
  elif [[  "$1" == "ZHCN" && "$2" == "src" ]]; then
    echo "Gen_ZHCNEN_epoch13_3.87.t7";
  elif [[  "$1" == "JA" && "$2" == "tgt" ]]; then   # JA
    echo "Gen_ENJA_epoch4_2.31.t7"
  elif [[  "$1" == "JA" && "$2" == "src" ]]; then    # JAEN SRC
    echo "Gen_JAEN_epoch13_3.82.t7";
  elif [[  "$1" == "KO" && "$2" == "tgt" ]]; then    # KO
    echo "Gen_ENKO_epoch13_3.38.t7"
  elif [[  "$1" == "KO" && "$2" == "src" ]]; then
    echo "Gen_KOEN_epoch13_3.01.t7";
  elif [[  "$1" == "DA" && "$2" == "tgt" ]]; then
    echo "Gen_ENDA_epoch13_2.61.t7"
#  elif [[  "$1" == "" && "$2" == "tgt" ]]; then
#    echo ""
#  elif [[  "$1" == "" && "$2" == "src" ]]; then
#    echo "";
  fi;
}
