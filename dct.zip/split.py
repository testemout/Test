#!/usr/bin/python
import io, os, sys, re

def main(argv):
		if len(argv) < 2:
			print("USAGE: python split.py <file> <split_by_number_of_lines>")
		src_file = argv[0]
		by=int(argv[1])
		print("Source file is {}".format(src_file))
		print("Split by {} lines".format(by))
		cnt = 0
		id = 0
		fw = None
		with io.open(src_file,'r',encoding='utf8',newline="\n") as fr:
			for line in fr:
				line = re.sub(u'[\u000B\u000C\u000D\u0085\u2028\u2029]+', u' ', line).strip()
				if cnt == by or id == 0:
					cnt = 0
					if id > 0:
						fw.close()
					id = id + 1
					fw = io.open("{}.{}".format(src_file,id),'w',encoding='utf8',newline='\n')
				fw.write(u"{}\n".format(line))
				cnt = cnt+1

		#os.rename("{}/{}".format(os.path.dirname(projdir),src_file), "{}/{}".format(projdir, src_file) )
		#os.rename("{}/{}".format(os.path.dirname(projdir),tgt_file), "{}/{}".format(projdir, tgt_file) )
		#print("Moving {} to {}.... Check duplicate segmnents there.".format("{}/{}.log".format(os.path.dirname(projdir),src_file), "{}/{}.log".format(projdir, src_file)))
		#bname = re.sub(r'[^.]+$|(/)[^/]+/(?=[^/]*$)', r'\1', '{}/{}'.format(projdir, src_file))
		#os.rename("{}irrelevant.log".format(bname), "{}/{}.irrelevant.log".format(projdir, src_file) )
		#os.rename("{}dupe.log".format(bname), "{}/{}.dupe.log".format(projdir, src_file) )

if __name__ == "__main__":
		main(sys.argv[1:])


