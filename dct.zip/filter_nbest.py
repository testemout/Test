#!/usr/bin/python
# -*- coding: utf-8 -*-

import re, sys, time, unicodedata, io
from itertools import islice

def main(argv):
	if len(argv) < 5:
		print("USAGE: python filter_nbest.py -src_file -tgt_file -rule_file -nbest_value -output_file")
		sys.exit(-1)
	src_file = argv[0]
	print("Source file: {}".format(src_file))
	tgt_file = argv[1]
	print("Target file: {}".format(tgt_file))
	rule_file = argv[2]
	print("Rule file: {}".format(rule_file))
	nbest = int(argv[3])
	print("Nbest: {}".format(nbest))
	output_file = argv[4]
	print("Output file: {}".format(output_file))
	terms = {}
	cnt_total = 0
	cnt_unique = 0
	sources = []
	translations = []
#	print("====================== Filtering against dictionary ===================================")
	with io.open(src_file, "r", encoding="utf-8", newline="\n") as frS:
		sources = frS.readlines()
	with io.open(tgt_file, "r", encoding="utf-8", newline="\n") as f:
		while True:
			next_n_lines = list(islice(f, nbest))
			if not next_n_lines:
				break
			translations.append(next_n_lines)
	with io.open(rule_file, "r", encoding="utf-8", newline="\n") as frTerms:
		for line in frTerms:
			(key,val) = line.strip().split('#')
			terms[key] = val

#	print(terms)
#	print(translations)
#	print(sources)
	fwBestTrans = io.open(output_file, 'w', encoding='utf-8', newline='\n')
	for i in range(len(sources)):
		cur_src_terms = {}
		for src_term,tgt_term in terms.iteritems():  #get all source terms present in source
			if src_term in sources[i]:
				cur_src_terms[src_term] = tgt_term
		best_trans=translations[i][0].rstrip() # set the best trans to the first trans
#		print(u"Setting best translation to {}".format(best_trans.strip()))
		if len(cur_src_terms) > 0: # if we have source terms in source segment
#			print(u"{} src terms detected: {}".format(len(cur_src_terms.keys()),", ".join(cur_src_terms)))
			cur_score=0
			prev_score=0
			for tgt in translations[i]: # Iterate over the current set of nbest translations
#				print(u"Checking tgt terms in {}...".format(tgt.strip()))
				for srcTerm, tgtTerm in cur_src_terms.iteritems():
#					print(u"Checking {}-{} terms in {}...".format(srcTerm, tgtTerm, tgt.strip()))
					if tgtTerm in tgt: # If tgt term is present in the translation
#						print(u"Tgt {} term is found in {}...".format(tgtTerm, tgt.strip()))
						cur_score=cur_score+1
#						print(u"Score is now set to {}".format(cur_score))
				if cur_score > prev_score:
					prev_score = cur_score
					best_trans=tgt.rstrip()
#					print(u"{} is best".format(best_trans))
				cur_score = 0
			print(u"'{}' is the best translation for '{}' with {} score.".format(best_trans.strip(), sources[i].strip(), prev_score))

#		print(u"'{}' is the best translation for '{}'.".format(best_trans.strip(), sources[i].strip()))
		fwBestTrans.write(u"{}\n".format(best_trans))
	fwBestTrans.close()
#	print(u"Processed: {} segments.".format(cnt_total))
#	print(u"Unique segments: {}.".format(cnt_unique))
#	print(u"Time spent: {} ({} - {}).".format(end - start, start_time, end_time))
#	print("====================== Filtering against dictionary END ===============================")

if __name__ == "__main__":
	main(sys.argv[1:])


