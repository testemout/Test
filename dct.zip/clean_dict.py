#!/usr/bin/python
import codecs, string
import os, sys, re

# Remove /.../, (...)
rx_remove=re.compile(r"\([^)\r\n]*\)|/[^\r\n/]*/")
rx_see = re.compile(r'^\s*see\s+', re.U|re.I)
rx_split_tgt_items=re.compile(r'(?:^|\s*(?<![^\W\d_])[;.,\u2014\u2013-]+)[\s0-9]*|[^\w\s]+$', re.U)
rx_punct_end = re.compile("[{}]+$".format("".join([re.escape(x) for x in set(string.punctuation)])))

def processEntry(line):
		terms =  line.split('\t', 1) #clean up, split
		if len(terms) != 2:
			return 'error'
		srcs = []
		if ',' in terms[0]: # we have source synonyms
			srcs = terms[0].split(',')
		else:
			srcs = [ terms[0] ]
		tgts = [x.strip() for x in filter(None, rx_split_tgt_items.split(rx_remove.sub('', terms[1])))]
		res = []
		for src in srcs:
			for tgt in tgts:
				res.append([src, tgt])
		return res

def main(argv):
		entries = []
		src_file = argv[0]
		print 'Source file is {}'.format(src_file)
		cnt = 0
		allcnt = 0
		refs = []
		with codecs.open("{}.clean".format(src_file),'w',encoding='utf8') as fw:
			with codecs.open(src_file,'r',encoding='utf8') as fr:
				for line in fr:
					if not line or line.strip().startswith('[') and  line.strip().endswith(']'):
						continue
					allcnt =allcnt + 1
					result = processEntry(line.strip())
					if result == 'error':
						continue
#					entries.extend([x for x in result if not x[1].lower().strip().startswith("see ")])
					for entry in result:
						if entry[1].strip().lower().startswith("see "): # it is a reference
							refs.append(entry)
							print("REF ENTRY: {}\t{}".format(entry[0], rx_punct_end.sub(u'', entry[1])))
						else:
							entries.append(entry)
							fw.write(u"{} @ {}\n".format(entry[0], rx_punct_end.sub(u'', entry[1])))
							cnt = cnt + 1
			print("Processing refs....")
			for entryRef in refs:
				m = [x[1] for x in result if x[0].lower().strip() == rx_see.sub(r'', entryRef[0]).lower().strip()]
				if m:
					fw.write(u"{}\t{}\n".format(entryRef[0], m[0]))
					cnt = cnt + 1
		print("Total valid lines read: {}\nEntries added: {}".format(allcnt, cnt))

if __name__ == "__main__":
		main(sys.argv[1:])


