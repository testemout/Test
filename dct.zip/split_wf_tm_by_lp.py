#!/usr/bin/python
# -*- coding: utf-8 -*-

# BEFORE RUNNING THIS SCRIPT, MAKE SURE THE TM FILES ARE IN UTF8!!!
# python /OpenNMT/tools/convert_to_utf8.py <file>
# for f in *.txt; do python /OpenNMT/tools/convert_to_utf8.py $f; done
#  python /OpenNMT/tools/split_wf_tm_by_lp.py "EN,EN-US,EN-GB" "RU,RU-RU"
import io, re, sys

def main(argv):
	file = argv[0]
	src_code = argv[1].lower()
	tgt_code = argv[2].lower()
	if ',' in tgt_code:
		tgt_code = tgt_code.split(',')
	if ',' in src_code:
		src_code = src_code.split(',')
	print('Src code: {}'.format(src_code))
	print('Tgt code: {}'.format(tgt_code))
	cnt_skipped = 0
	cnt = 0

	with io.open("{}.{}{}".format(file, re.sub(r',.*', '', argv[1]), re.sub(r",.*", "", argv[2])), 'w', encoding='utf-8', newline='\n') as fwSrcTgt:
		with io.open("{}.{}{}".format(file, re.sub(r",.*", "", argv[2]), re.sub(r",.*", "", argv[1])), 'w', encoding='utf-8', newline='\n') as fwTgtSrc:
			with io.open(file,'r',encoding='utf8', newline='\n') as frTm:
				for line in frTm:
					fields = re.sub(u'[\u000B\u000C\u000D\u0085\u2028\u2029]+', u' ', line).strip().split("\t")
					if len(fields) < 7: # skip it
						cnt_skipped = cnt_skipped + 1
						continue
					actual_src_code=fields[3].lower()
					actual_tgt_code=fields[5].lower()
					if actual_src_code in src_code and actual_tgt_code in tgt_code: # it coincides with the declared src
						fwSrcTgt.write(line)
					elif actual_src_code in tgt_code and actual_tgt_code in src_code:
						fwTgtSrc.write(line)
					cnt = cnt + 1

	print("Processed: {} written, {} skipped.".format(cnt, cnt_skipped))

if __name__ == "__main__":
	main(sys.argv[1:])


