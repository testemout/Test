#!/usr/bin/python
from itertools import izip
import os, sys, re, random, io

def main(argv):
#	   print(";".join(argv))
		src_file = argv[0]
		tgt_file = argv[1]
		num = int(argv[2])
		seg_cnt = int(argv[3])
		projdir = re.sub(r'(.*)[/\\].*', r'\1', src_file)
		ids = [random.randint(0, seg_cnt) for _ in range(num)]
		print 'Source file is {}'.format(src_file)
		print 'Target file is {}'.format(tgt_file)
		print "Segments count to extract: {}".format(num)

		cnt_ids = 0
		print 'Project directory is {}'.format(projdir)

		cnt = 0

		with io.open("{}.extr".format(src_file),'w',encoding='utf8', newline='\n') as fwSrc:
			with io.open("{}.extr".format(tgt_file),'w',encoding='utf8', newline='\n') as fwTgt:
				with io.open(src_file,'r',encoding='utf8', newline='\n') as frSrc, io.open(tgt_file,'r',encoding='utf8', newline='\n') as frTgt:
					for src, tgt in izip(frSrc, frTgt):
						src = re.sub(u'[\u000B\u000C\u000D\u0085\u2028\u2029]+', u' ', src).strip()
						tgt = re.sub(u'[\u000B\u000C\u000D\u0085\u2028\u2029]+', u' ', tgt).strip()
						cnt = cnt + 1
						if cnt in ids:
							fwSrc.write(src.replace("\r", ""))
							fwTgt.write(tgt.replace("\r", ""))

		print("Finished extracting random segments")
		#os.rename("{}/{}".format(os.path.dirname(projdir),src_file), "{}/{}".format(projdir, src_file) )
		#os.rename("{}/{}".format(os.path.dirname(projdir),tgt_file), "{}/{}".format(projdir, tgt_file) )
		#print("Moving {} to {}.... Check duplicate segmnents there.".format("{}/{}.log".format(os.path.dirname(projdir),src_file), "{}/{}.log".format(projdir, src_file)))
		#bname = re.sub(r'[^.]+$|(/)[^/]+/(?=[^/]*$)', r'\1', '{}/{}'.format(projdir, src_file))
		#os.rename("{}irrelevant.log".format(bname), "{}/{}.irrelevant.log".format(projdir, src_file) )
		#os.rename("{}dupe.log".format(bname), "{}/{}.dupe.log".format(projdir, src_file) )

if __name__ == "__main__":
		main(sys.argv[1:])

