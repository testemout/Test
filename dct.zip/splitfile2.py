#!/usr/bin/python
import os, sys, re, io

def main(argv):
#	   print(";".join(argv))
		src_file = argv[0]
		tgt_file = argv[1]
		if "mdcList" in os.environ:
			ids = [int(x) for x in re.split(r'\W+', os.getenv('mdcList'))]
		else:
			print('ERROR: The list of segment IDs is not defined. Aborting...')
			exit(-1)
		projdir = argv[3]

		print('Source file is {}'.format(src_file))
		print('Target file is {}'.format(tgt_file))
#	   print 'IDs: {}'.format("; ".join(ids))
		ids = set(ids)
		print("Segments count to extract: {}".format(len(ids)))
		if len(ids) / 2 < 1000:
				print("WARNING: The amount of segments to use in testing/validation corpus chunks is less than 1K. Consider using a bigger threashold.")

		cnt_ids = 0
		#with codecs.open("ids.log", "w", encoding='utf8') as idsLog: # NO NEED, IT WORKS CORRECTLY NOW
		#	   for id in ids:
		#			   cnt_ids = cnt_ids + 1
		#			   idsLog.write("{}: {}\n".format(cnt_ids, id))

		print('Project directory is {}'.format(projdir))

		cnt = 0
		write_to_test = False

		with io.open("{0}/src-train.txt".format(projdir),'w',encoding='utf8', newline='\n') as fwSrcTrain:
				with io.open("{0}/src-val.txt".format(projdir),'w',encoding='utf8', newline='\n') as fwSrcVal:
						with io.open("{0}/src-test.txt".format(projdir),'w',encoding='utf8', newline='\n') as fwSrcTest:
								with io.open("{}/{}".format(projdir,src_file),'r',encoding='utf8', newline='\n') as fr:
										for line in fr:
												cnt = cnt + 1
												if cnt in ids:
														if write_to_test:
																fwSrcTest.write(line)
														else:
																fwSrcVal.write(line)
														write_to_test = not write_to_test
												else:
														fwSrcTrain.write(line)
		cnt = 0
		write_to_test = False
		with io.open("{0}/tgt-train.txt".format(projdir),'w',encoding='utf8', newline='\n') as fwTgtTrain:
				with io.open("{0}/tgt-val.txt".format(projdir),'w',encoding='utf8', newline='\n') as fwTgtVal:
						with io.open("{0}/tgt-test.txt".format(projdir),'w',encoding='utf8', newline='\n') as fwTgtTest:
								with io.open("{}/{}".format(projdir,tgt_file),'r',encoding='utf8', newline='\n') as fr:
										for line in fr:
												cnt = cnt + 1
												if cnt in ids:
														if write_to_test:
																fwTgtTest.write(line)
														else:
																fwTgtVal.write(line)
														write_to_test = not write_to_test
												else:
														fwTgtTrain.write(line)

		#os.rename("{}/{}".format(os.path.dirname(projdir),src_file), "{}/{}".format(projdir, src_file) )
		#os.rename("{}/{}".format(os.path.dirname(projdir),tgt_file), "{}/{}".format(projdir, tgt_file) )
		#print("Moving {} to {}.... Check duplicate segmnents there.".format("{}/{}.log".format(os.path.dirname(projdir),src_file), "{}/{}.log".format(projdir, src_file)))
		#bname = re.sub(r'[^.]+$|(/)[^/]+/(?=[^/]*$)', r'\1', '{}/{}'.format(projdir, src_file))
		#os.rename("{}irrelevant.log".format(bname), "{}/{}.irrelevant.log".format(projdir, src_file) )
		#os.rename("{}dupe.log".format(bname), "{}/{}.dupe.log".format(projdir, src_file) )

if __name__ == "__main__":
		main(sys.argv[1:])

