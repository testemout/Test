#!/usr/bin/python
# -*- coding: utf-8 -*-

# http://rextester.com/OZCFGL98669
# python realign_discard.py /Engines/Media/ENID/OpenSubtitles2016.en-id.en /Engines/Media/ENID/OpenSubtitles2016.en-id.id
# python realign_discard.py /tmp/txt/os2018_200_en.txt  /tmp/txt/os2018_200_id.txt

import io, re, sys, hashlib, time, unicodedata
from datetime import datetime
from itertools import izip
from itertools import *
from collections import Counter
from collections import defaultdict

Pe=ur'\u0029\]\u007D\u0F3B\u0F3D\u169C\u2046\u207E\u208E\u2309\u230B\u232A\u2769\u276B\u276D\u276F\u2771\u2773\u2775\u27C6\u27E7\u27E9\u27EB\u27ED\u27EF\u2984\u2986\u2988\u298A\u298C\u298E\u2990\u2992\u2994\u2996\u2998\u29D9\u29DB\u29FD\u2E23\u2E25\u2E27\u2E29\u3009\u300B\u300D\u300F\u3011\u3015\u3017\u3019\u301B\u301E\u301F\uFD3E\uFE18\uFE36\uFE38\uFE3A\uFE3C\uFE3E\uFE40\uFE42\uFE44\uFE48\uFE5A\uFE5C\uFE5E\uFF09\uFF3D\uFF5D\uFF60\uFF63'
Ps=ur'\u0028\u005B\u007B\u0F3A\u0F3C\u169B\u201A\u201E\u2045\u207D\u208D\u2308\u230A\u2329\u2768\u276A\u276C\u276E\u2770\u2772\u2774\u27C5\u27E6\u27E8\u27EA\u27EC\u27EE\u2983\u2985\u2987\u2989\u298B\u298D\u298F\u2991\u2993\u2995\u2997\u29D8\u29DA\u29FC\u2E22\u2E24\u2E26\u2E28\u2E42\u3008\u300A\u300C\u300E\u3010\u3014\u3016\u3018\u301A\u301D\uFD3F\uFE17\uFE35\uFE37\uFE39\uFE3B\uFE3D\uFE3F\uFE41\uFE43\uFE47\uFE59\uFE5B\uFE5D\uFF08\uFF3B\uFF5B\uFF5F\uFF62'
Zs=ur'\u0020\u00A0\u1680\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000'
Zl=ur'\u2028'
pM=ur'\u0300-\u036F\u0483-\u0489\u0591-\u05BD\u05BF\u05C1\u05C2\u05C4\u05C5\u05C7\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06DC\u06DF-\u06E4\u06E7\u06E8\u06EA-\u06ED\u0711\u0730-\u074A\u07A6-\u07B0\u07EB-\u07F3\u0816-\u0819\u081B-\u0823\u0825-\u0827\u0829-\u082D\u0859-\u085B\u08E3-\u0903\u093A-\u093C\u093E-\u094F\u0951-\u0957\u0962\u0963\u0981-\u0983\u09BC\u09BE-\u09C4\u09C7\u09C8\u09CB-\u09CD\u09D7\u09E2\u09E3\u0A01-\u0A03\u0A3C\u0A3E-\u0A42\u0A47\u0A48\u0A4B-\u0A4D\u0A51\u0A70\u0A71\u0A75\u0A81-\u0A83\u0ABC\u0ABE-\u0AC5\u0AC7-\u0AC9\u0ACB-\u0ACD\u0AE2\u0AE3\u0B01-\u0B03\u0B3C\u0B3E-\u0B44\u0B47\u0B48\u0B4B-\u0B4D\u0B56\u0B57\u0B62\u0B63\u0B82\u0BBE-\u0BC2\u0BC6-\u0BC8\u0BCA-\u0BCD\u0BD7\u0C00-\u0C03\u0C3E-\u0C44\u0C46-\u0C48\u0C4A-\u0C4D\u0C55\u0C56\u0C62\u0C63\u0C81-\u0C83\u0CBC\u0CBE-\u0CC4\u0CC6-\u0CC8\u0CCA-\u0CCD\u0CD5\u0CD6\u0CE2\u0CE3\u0D01-\u0D03\u0D3E-\u0D44\u0D46-\u0D48\u0D4A-\u0D4D\u0D57\u0D62\u0D63\u0D82\u0D83\u0DCA\u0DCF-\u0DD4\u0DD6\u0DD8-\u0DDF\u0DF2\u0DF3\u0E31\u0E34-\u0E3A\u0E47-\u0E4E\u0EB1\u0EB4-\u0EB9\u0EBB\u0EBC\u0EC8-\u0ECD\u0F18\u0F19\u0F35\u0F37\u0F39\u0F3E\u0F3F\u0F71-\u0F84\u0F86\u0F87\u0F8D-\u0F97\u0F99-\u0FBC\u0FC6\u102B-\u103E\u1056-\u1059\u105E-\u1060\u1062-\u1064\u1067-\u106D\u1071-\u1074\u1082-\u108D\u108F\u109A-\u109D\u135D-\u135F\u1712-\u1714\u1732-\u1734\u1752\u1753\u1772\u1773\u17B4-\u17D3\u17DD\u180B-\u180D\u18A9\u1920-\u192B\u1930-\u193B\u1A17-\u1A1B\u1A55-\u1A5E\u1A60-\u1A7C\u1A7F\u1AB0-\u1ABE\u1B00-\u1B04\u1B34-\u1B44\u1B6B-\u1B73\u1B80-\u1B82\u1BA1-\u1BAD\u1BE6-\u1BF3\u1C24-\u1C37\u1CD0-\u1CD2\u1CD4-\u1CE8\u1CED\u1CF2-\u1CF4\u1CF8\u1CF9\u1DC0-\u1DF5\u1DFC-\u1DFF\u20D0-\u20F0\u2CEF-\u2CF1\u2D7F\u2DE0-\u2DFF\u302A-\u302F\u3099\u309A\uA66F-\uA672\uA674-\uA67D\uA69E\uA69F\uA6F0\uA6F1\uA802\uA806\uA80B\uA823-\uA827\uA880\uA881\uA8B4-\uA8C4\uA8E0-\uA8F1\uA926-\uA92D\uA947-\uA953\uA980-\uA983\uA9B3-\uA9C0\uA9E5\uAA29-\uAA36\uAA43\uAA4C\uAA4D\uAA7B-\uAA7D\uAAB0\uAAB2-\uAAB4\uAAB7\uAAB8\uAABE\uAABF\uAAC1\uAAEB-\uAAEF\uAAF5\uAAF6\uABE3-\uABEA\uABEC\uABED\uFB1E\uFE00-\uFE0F\uFE20-\uFE2F' #XRegExp 3.2.0

unicode_category = defaultdict(list)
for c in map(unichr, range(sys.maxunicode + 1)):
	unicode_category[unicodedata.category(c)].append(c)

Lu=u"".join(unicode_category['Lu'])

rx_sentence_boundary=re.compile(ur"""[.…?!\u3002\u0964\u0DF4\u06D4]+[{pPe}”’"']*[{pZs}]+[{pPs}“‘"']*[{pLu}\d]|[{pZl}\r\n]+[{pZs}]*[{pPs}“‘"']*[{pLu}\d]""".format(pPe=Pe,pPs=Ps, pZs=Zs, pLu=Lu, pZl=Zl), re.U)
rx_camels_words_with_punctuation_tokenize = re.compile(r"Yahoo\!|eChannel|eBay|iP[oa]d|iOS|iMovie|iMessage|iMac|iLife|eSATA|vSphere|vMotion|iDisk|iDVD|iPhoto|iPhone|iTunes|iWork|iWeb|iSight|xTuple|iTinerary");
rx_norm_segstr=re.compile(ur"\.{3,}|[-…—–]")
rx_spacesReg = re.compile(ur"\s", re.U)
rx_tokenize = re.compile(ur"(?:(?![.{0}])\W)*(?:$|\s|^)+(?:(?![.{0}])\W)*".format(pM), re.U)

def SegmentWordCount(segstr, lang): # P3: http://rextester.com/SDU6949
	if not segstr or not lang:  # P2: http://rextester.com/LYWC69461
		return 0
	if lang.lower().startswith("th") or lang.lower().startswith("ja") or lang.lower().startswith("th") or "chinese" in lang.lower() or "japanese" in lang.lower() or "thai" in lang.lower():
		return len(rx_spacesReg.sub('', segstr));
	return len(filter(None, rx_tokenize.split(segstr)))

def SegmentSentenceCount(segstr):
		if rx_camels_words_with_punctuation_tokenize.search(segstr):
			return len(rx_sentence_boundary.findall(rx_camels_words_with_punctuation_tokenize.sub("Word", segstr))) + 1;
		if rx_sentence_boundary.search(segstr):
			return len(rx_sentence_boundary.findall(segstr)) + 1
		else:
			return 1

def main(argv):
		if len(argv) < 4:
			print("Usage: realign_discard.py SRC_TXT_CORPUS TGT_TXT_CORPUS SRC_LANG TGT_LANG")
			sys.exit(-1)
		src_file = argv[0]
		tgt_file = argv[1]
		src_lang = argv[2]
		tgt_lang = argv[3]
		print 'Source file is {}'.format(src_file)
		print 'Target file is {}'.format(tgt_file)

		cnt_good = 0
		cnt = 0
		#write_to_bad = False
		print("====================== DISCARD SENETENCE COUNT MISMATCH SEGMENTS AND NEXT ONES ===================================")
		start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
		start = time.time()

		fwBadSrc = io.open("{}.bad".format(src_file), 'w', encoding='utf8', newline='\n')
		fwGoodSrc = io.open("{}.good".format(src_file), 'w', encoding='utf8', newline='\n')
		fwBadTgt = io.open("{}.bad".format(tgt_file), 'w', encoding='utf8', newline='\n')
		fwGoodTgt = io.open("{}.good".format(tgt_file), 'w', encoding='utf8', newline='\n')

		with io.open(src_file,'r',encoding='utf8') as frSrc, io.open(tgt_file,'r',encoding='utf8', newline='\n') as frTgt:
			for src, tgt in izip(frSrc, frTgt):
				src = re.sub(u'[\u000B\u000C\u000D\u0085\u2028\u2029]+', u' ', src).strip()
				tgt = re.sub(u'[\u000B\u000C\u000D\u0085\u2028\u2029]+', u' ', tgt).strip()
				cnt=cnt+1
				if cnt % 1000000 == 0:
					print("{}: Processed {} segments...".format(datetime.now().strftime("%d.%b %Y %H:%M:%S"), cnt))
				src_sent_cnt = SegmentSentenceCount(src.replace(u"...", u"").replace(u"…", u""))
				tgt_sent_cnt = SegmentSentenceCount(tgt.replace(u"...", u"").replace(u"…", u""))
				src_wc = SegmentWordCount(src, src_lang);
				tgt_wc = SegmentWordCount(tgt, tgt_lang);
				if src_wc ==0 or tgt_wc == 0:
					continue
#                                print(u"{}\t{}\t{}\t{}\t{}".format(src,tgt,cnt,src_sent_cnt, tgt_sent_cnt))
				src_tgt_ratio = 0 # http://rextester.com/LDPR84305
				if src_wc > tgt_wc:
					src_tgt_ratio=(tgt_wc * 1.0) / src_wc * 100
				else:
					src_tgt_ratio=(src_wc * 1.0) / tgt_wc * 100
				if src_sent_cnt != tgt_sent_cnt or src_tgt_ratio < 50.0: # sentence count not the same, write 2 segments to bad
					#write_to_bad = not write_to_bad
					fwBadSrc.write(u"{}\n".format(src.strip()))
					fwBadTgt.write(u"{}\n".format(tgt.strip()))
				else:
					fwGoodSrc.write(u"{}\n".format(src.strip()))
					fwGoodTgt.write(u"{}\n".format(tgt.strip()))
					cnt_good=cnt_good+1

#end
		end = time.time()
		end_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
		fwBadSrc.close()
		fwBadTgt.close()
		fwGoodSrc.close()
		fwGoodTgt.close()

		print(u"Processed: {} segments.".format(cnt))
		print(u"Bad (poorly aligned) segments: {}.".format(cnt-cnt_good))
		print(u"Good (well-aligned) segments: {}.".format(cnt_good))
		print(u"Time spent: {} ({} - {}).".format(end - start, start_time, end_time))

		print("====================== REALIGN BY DISCARDING TRASH END ===============================")


if __name__ == "__main__":
		main(sys.argv[1:])
